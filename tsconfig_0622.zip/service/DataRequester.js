var https = require('https');
var http = require('http');
var DOMParser = require('./xmldom').DOMParser;
/**
 * Convert xml to json
 * @param xml need convert
 * @returns converted json
 */
function xmlToJson(xml) {
    var result = {};
    const NODE_ELEMENT_TYPE = 1;
    const NODE_TEXT_TYPE = 3;
    if (xml.nodeType === NODE_ELEMENT_TYPE) { // if xml node type is element
        if (xml.attributes.length > 0) {
            result['@attributes'] = {};
            for (var j = 0; j < xml.attributes.length; j++) {
                var attribute = xml.attributes.item(j);
                result['@attributes'][attribute.nodeName] = attribute.nodeValue;
            }
        }
    } else if (xml.nodeType === NODE_TEXT_TYPE) { // if xml node type is text
        result = xml.nodeValue;
    }

    // do children
    // If just one text node inside
    if (xml.hasChildNodes() && xml.childNodes.length === 1 && xml.childNodes[0].nodeType === NODE_TEXT_TYPE) {
        result = xml.childNodes[0].nodeValue;
    }
    else if (xml.hasChildNodes()) {
        for(var i = 0; i < xml.childNodes.length; i++) {
            var item = xml.childNodes.item(i);
            var nodeName = item.nodeName;
            if (typeof(result[nodeName]) === 'undefined') {
                result[nodeName] = xmlToJson(item);
            } else {
                if (typeof(result[nodeName].push) === 'undefined') {
                    var old = result[nodeName];
                    result[nodeName] = [];
                    result[nodeName].push(old);
                }
                result[nodeName].push(xmlToJson(item));
            }
        }
    }
    return result;
};

/**
 * Implement the HTTP GET
 * @param host of requested API
 * @param endpoint of requested API
 * @param successCallback
 */
function performHttpsRequest(host, endpoint, successCallback) {
	console.log('host : ' + host + ', endpoint : ' + endpoint);
	var options = {
			host: host,
			port : 443,
	        path : endpoint,
	        method : 'GET'
	};
	var req = https.request(options, function(res) {
		console.log('status code: ' + res.statusCode);

		res.setEncoding('utf-8');
		var responseString = '';

		res.on('data', function(data) {
			responseString += data;
		});

		res.on('end', function() {
            var parser = new DOMParser();
            var responseXml = parser.parseFromString(responseString, 'text/xml');
			var responseJson = xmlToJson(responseXml);
			successCallback(responseJson);
		});
	});
	req.end();
	req.on('error', function(e){
		// console.log('Error: ' + e.message);
    });
}

function performHttpRequest(host, port, endpoint, successCallback) {
	var options = {
			host: host,
        	port : port,
	        path : endpoint,
	        method : 'GET'
	};
	http.get(options);
}

exports.performHttpsRequest = performHttpsRequest;
exports.performHttpRequest = performHttpRequest;

function log(msg) {
    performHttpRequest('192.168.0.110', 1913, '/log_' + msg);
}
