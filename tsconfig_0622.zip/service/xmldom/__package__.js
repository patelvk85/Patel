this.addScript('dom.js',['DOMImplementation','XMLSerializer']);
this.addScript('dom-parser.js',['DOMHandler','DOMParser'],
		['DOMImplementation','XMLReader']);
this.addScript('sax.js','XMLReader');