const DataRequester = require('./DataRequester');
const FANTASY_ZONE_GAME_ID = '888888888';
const RED_ZONE_GAME_ID = '999999999';
const MESG_PORT_NAME = 'FOREGROUND_APP_PORT';
var localPort = '';
var timeoutId;

function log(msg) {
    // DataRequester.performHttpRequest('192.168.0.110', 1913, '/log_' + encodeURIComponent(msg));
}

function setPreviewData(data) {
    try {
        log('setPreviewData' + JSON.stringify(data));
        webapis.preview.setPreviewData(JSON.stringify(data),
            function () {
                log('setPreviewData_SuccessCallback');
                // please terminate service after setting preview data
                tizen.application.getCurrentApplication().exit();
            },
            function (e) {
                log('setPreviewData_FailedCallback' + e.message);
            }
        );
    } catch (e) {
        log('setPreviewData_Failed' + e.message);
    }
}

function convertToPreviewFormat(data) {

    var gamechips = data.gamechips;
    var config = data.config;
    var tiles = {
        'sections': [
            {
                'title': 'This Week Games',
                'position': 0,
                'tiles': [
                    {
                        subtitle: 'Fantasy Zone',
                        image_ratio: '16by9',
                        image_url: [config.imageBaseUrl, '/fan', '.', config.imageExt].join(''),
                        action_data: JSON.stringify({
                            gameId: FANTASY_ZONE_GAME_ID
                        }),
                        is_playable: false,
                        position: 0
                    },
                    {
                        subtitle: 'Red Zone',
                        image_ratio: '16by9',
                        image_url: [config.imageBaseUrl, '/red', '.', config.imageExt].join(''),
                        action_data: JSON.stringify({
                            gameId: RED_ZONE_GAME_ID
                        }),
                        is_playable: false,
                        position: 1
                    }

                ]
            }
        ]
    };

    for (var i = 0; i < gamechips.length; i++) {
        if (gamechips[i].awayName && gamechips[i].homeName && gamechips[i].awayTeamClubCode && gamechips[i].homeTeamClubCode && gamechips[i].phase) {
            var tile = {
                title: gamechips[i].awayName + '  vs  ' + gamechips[i].homeName,
                subtitle: '',
                image_ratio: '16by9',
                image_url: [config.imageBaseUrl, '/', gamechips[i].awayTeamClubCode, 'vs', gamechips[i].homeTeamClubCode, '.', config.imageExt].join(''),
                action_data: JSON.stringify({
                    gameId: gamechips[i].gameId
                }),
                position: i,
                is_playable: false
            };
            if (gamechips[i].phase === 'Pregame') {
                tile.subtitle = gamechips[i].kickoffDateTime;
            } else if (gamechips[i].phase.toLowerCase().indexOf('final') > -1 || gamechips[i].phase === 'Halftime') {
                tile.subtitle = gamechips[i].phase;
            } else {
                tile.subtitle = gamechips[i].awayTeamScore + ' - ' + gamechips[i].homeTeamScore;
            }
            tiles.sections[0].tiles.push(tile);
        }

    }
    return tiles;
}

function onReceived(data) {
    clearTimeout(timeoutId);
    log('onReceived');
    //console.log('onReceived : ' + JSON.stringify(data) + ' remotePort : ' + remotePort);
    data.forEach(function (item) {
        //console.log('item : ' + JSON.stringify(item));
        if (item.key === 'METADATA') {
            setPreviewData(convertToPreviewFormat(JSON.parse(item.value)))
        }
    });
}

function initMessagePort() {
    try {
        log('request local message port ' + MESG_PORT_NAME);
        localPort = tizen.messageport.requestLocalMessagePort(MESG_PORT_NAME);
    } catch (e) {
        log('request message port error : ' + e.message);
    }


}

//Mandatory Callbacks for Service application
//onStart Callback
module.exports.onStart = function () {
    log('Start_Callback');
    initMessagePort();
    timeoutId = setTimeout(function () {
        log('Timeout_kill');
        tizen.application.getCurrentApplication().exit();
    }, 20000)
};

//onRequest Callback
module.exports.onRequest = function () {
    log('onRequestk');
    try {
        log('addMessagePortListener');
        localPort.addMessagePortListener(onReceived);
    } catch (e) {
        log('add message port listener error : ' + e.message);
    }
};

//onExit Callback
module.exports.onExit = function () {
    log('Exit Callback');
};
