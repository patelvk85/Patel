#!/bin/bash


npm run build

TV_IP="192.168.0.103:26101"
PACKAGE_NAME="1UdGgDvVAK.TizenNFL"
PROJECT_FOLDER="./dist"
WGT_FILE_NAME="TizenNFL.wgt"
SIGNATURE_NAME="Samsung"

#tizen trust-anchor set -c /Users/anhtuan/SamsungCertificate/NewTV/author.p12 -s true -- $PROJECT_FOLDER
tizen clean -- $PROJECT_FOLDER
tizen build-web -opt -- $PROJECT_FOLDER
tizen package -t wgt -s $SIGNATURE_NAME -- $PROJECT_FOLDER
tizen uninstall -s $TV_IP -p $PACKAGE_NAME
tizen install -s $TV_IP -n $WGT_FILE_NAME -- $PROJECT_FOLDER
tizen run -p $PACKAGE_NAME -s $TV_IP