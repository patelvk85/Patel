const ENVIRONMENT = process.env.NODE_ENV;
console.log('ENVIRONMENT %s', ENVIRONMENT);
module.exports = ENVIRONMENT == "production" ? require('./config/webpack.prod.js') : require('./config/webpack.dev.js');
