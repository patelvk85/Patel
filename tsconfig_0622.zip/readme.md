#Application NFL - Tizen OS - Smart TV

## Tizen 2.4 SDK, Angular 2.4.8
* [Tizen 2.4 SDK](http://developer.samsung.com/tv/develop/tools/tizen-studio)
* [Angular 2](https://angular.io)
* Unit tests with [Karma](https://karma-runner.github.io/)
  * [Jasmine](https://github.com/jasmine/jasmine)
  * [TypeScript](http://www.typescriptlang.org/)
  * Gulp, Sass, Autoprefixer, and css-lint support
  * Following the [best practices](https://angular.io/styleguide).

# How to start

**Note** this seed project requires node v4.x.x or higher and npm 2.14.7, but for full functionality we **strongly recommend node >= 6.3.1 and npm >= 4.2.0**

## Project Installation

```bash
# install the project's dependencies
$ npm install

# to start deving with livereload site and coverage as well as continuous testing
$ npm run start

# prod build
$ npm run build

# Tizen Installation and Import
Download tizen studio 1.2 [here](http://download.tizen.org/sdk/Installer/tizen-studio_1.2/)
Follow installation instructions accordingly  [here](http://developer.samsung.com/tv/develop/getting-started/essentials-for-beginner)

## Import Tizen project
Before importing, do a `npm run build` to create the project `dist` folder


In Tizen Studios, import the project by:

1. Select `File > Import`
2. Select `Tizen > Tizen Project`
3. Click `Browse` and select location of `dist`
4. Then select `tv-samsung` and `2.4` or `3.0`
5. Finish


#run application in browser with `http://localhost:8080`

```

# Directory Structure

```
.
├── dist               				 					<- production code
├── README.md
├── package.json               					<- dependencies of the project
├── src                        					<- source code of the application
│      ├── app  							 
│      │   ├── common 				 					<- common components, layout, services, constants, models
│      │   │   ├── components
│      │   │   ├── models
│      │   │   |    ├── video.model.ts
│      │   │   |    ├── gamechip.model.ts
│      │   │   ├── constants
│      │   │   ├── services
│      │   │   |    ├── api.service.ts
│      │   │   ├── layout
│      │   │   ├── common.module.ts
│      │   │   └── index.ts
│      │   ├── pages           					<- main pages in our project: login, homepage, carousel, video
│      │   │   └── home
│      │   │        ├── home.component.scss
│      │   │        ├── home.component.html
│      │   │        ├── home.component.spec.ts
│      │   │        └── home.component.ts
│      │   ├── services        					<- the services for main pages if any
│      │   │   ├── video.service.ts
│      │   │   └── gamechip.service.ts
│      │   ├── app.component.html
│      │   ├── app.component.ts        	<- main component in the project
│      │   ├── app.module.ts
│      │   └── app.router.ts
│      │   └── index.html
│      ├── scss
│      │    │── app.scss
│      │    │── common.scss      				<- common style reuse of the application
│      │    └── variables.scss   				<- define all variable style of the application
│      ├── fonts
│      ├── images
│      ├── main.ts
│      ├── vendor.ts
├── config                      				<- configuration of the application
│      ├── tizen  											<- configuration of tizen
│      │   │── icon.png
│      │   └── config.xml
│      │   
│      ├── webpack.common.js
│      ├── webpack.config.js
│      ├── webpack.dev.js               <- development env configuation
│      └── webpack.prod.js 							<- production env configuation
├── eslintrc 														<- eslint configuration
├── tsconfig.json 											<- typescript configuration
└── webpack.config.js 									<- webpack configuration
```

### Note
**Can not install node-sass on windows, run the following command first:**
 $ npm install --global --production windows-build-tools
 $ npm install --global node-gyp
 
 ## Setting TV for App Deployment
 
 - Connect the TV and your Computer on same network.
 - Check TV IP address: Network status, IP Settings
 - Open Apps and type 12345 to go into Developer mode.
 - Developer mode screen: Enter IP address.
 - Turn TV Off and Then turn it On.
 - Open Connection Explorer (Windows > Show View > Connection Explorer)
 - Open Remote Device Manager and Scan for TV.
 - Connect to TV.
 
 ## Set up TV Certificate
 - In Tizen Studio, go to Tools > Certificate Manager.
 - Follow the steps to create a new certificate for TV. (Will need Samsung Account).
 - Please Select Partner Profile instead of Public Profile while generating this certificate.
 - Once Certificate is created, right click on the Connected TV and Click Permit to install application.
 - Separate Certificate needs to be created for different TV or the DDUI of TV needs to be included in the selected Certificate.

 


