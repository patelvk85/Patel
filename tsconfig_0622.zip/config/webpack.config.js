const path = require('path')

module.exports = {
    'prod': {
        'env': 'production',
        'outputPath': path.join(__dirname, '..', 'dist'),
        'publicPath': '',
        'outputFile': 'js/[name].bundle.js',
        'resolvePath': [path.resolve('./src'), 'node_modules', 'app', 'sass', 'images', 'vendor', 'fonts', 'app/../'],
        'sourceMap': 'eval-source-map'
    },
    'dev': {
        'env': 'development',
        'port': 3000,
        'outputPath': path.join(__dirname, '..', 'dev'),
        'publicPath': '',
        'outputFile': 'js/[name].bundle.js',
        'autoOpenBrowser': false,
        'assetsSubDirectory': 'static',
        'assetsPublicPath': '/',
        'sourceMap': 'eval-source-map'
    }
}