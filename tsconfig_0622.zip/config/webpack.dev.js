var webpack = require('webpack');
var webpackMerge = require('webpack-merge');
var commonConfig = require('./webpack.common.js');
var path = require('path');
var config = require('./webpack.config');
console.log("DEV EVIRONMENT");
module.exports = webpackMerge(commonConfig, {
    devtool: config.dev.sourceMap,
  /*output: {
        path: config.dev.outputPath,
        filename: config.dev.outputFile,
        publicPath: config.dev.publicPath
    },*/
    module: {
        rules: [
            {
                enforce: 'pre',
                test: /\.ts?$/,
                exclude: path.resolve(__dirname, "node_modules"),
                loader: 'tslint-loader',
                options: {
                    emitWarning: true
                }
            }
        ]
    }

});
