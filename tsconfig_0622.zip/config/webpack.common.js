var webpack = require('webpack'),
    HtmlWebpackPlugin = require('html-webpack-plugin'),
    ExtractTextPlugin = require('extract-text-webpack-plugin'),
    CopyWebpackPlugin = require('copy-webpack-plugin'),
    config = require('./webpack.config'),
    path = require('path');

// const ENV  = process.env.NODE_ENV = 'development';
// const HOST = process.env.HOST || 'localhost';
// const PORT = process.env.PORT || 8080;

function root(__path) {
    return path.join(__dirname, __path);
}

module.exports = {
    entry: {
        'vendor': './src/vendor.ts',
        'src': './src/main.ts'
    },

    devServer: {
        clientLogLevel: 'none'
    },

    output: {
        path: config.prod.outputPath,
        filename: config.prod.outputFile,
        publicPath: config.prod.publicPath
    },

    resolve: {
        extensions: ['.ts', '.js'],
    },

    devtool: config.prod.sourceMap,

    node: {
        net: 'empty'
    },

    module: {
        rules: [
            // {
            //   enforce: 'pre',
            //   test: /\.ts?$/,
            //   exclude: path.resolve(__dirname, "node_modules"),
            //   loader: 'tslint-loader',
            //   options: {
            //     emitWarning: true
            //   }
            // },
            {
                test: /\.ts/,
                loader: ['awesome-typescript-loader', 'angular2-template-loader'],
                exclude: path.resolve(__dirname, "node_modules")
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            },
            {
                test: /\.scss$/,
                use: ['raw-loader']
            },
            {
                test: /\.html$/,
                loader: 'html-loader',
                query: {
                    minimize: false
                }
            },
            {
                test: /\.scss$/,
                use: ExtractTextPlugin.extract({
                    fallback: 'style-loader',
                    use: [{
                        loader: 'css-loader',
                        options: {
                            sourceMap: true,
                            minimize: false
                        }
                    },
                    {
                        loader: 'sass-loader',
                        options: {
                            sourceMap: true
                        }
                    }],
                    publicPath: '../'
                }),
                exclude: [/node_modules/]
            },
            {
                test: /\.(woff|woff2|ttf|otf|eot|svg|png|gif|ico|jpg)($|\?)/,
                loader: 'file-loader?name=assets/[name].[ext]'
            }
        ]
    },

    plugins: [
        new ExtractTextPlugin({ 'filename': 'css/style.css', 'allChunks': true }),
        new webpack.optimize.CommonsChunkPlugin({
            name: 'vendor',
            filename: 'js/vendor.bundle.js'
        }),

        // Takes care of warnings described at https://github.com/angular/angular/issues/11580
        new webpack.ContextReplacementPlugin(
            // The (\\|\/) piece accounts for path separators in *nix and Windows
            /angular(\\|\/)core(\\|\/)(esm(\\|\/)src|src)(\\|\/)linker/,
            path.join(__dirname, './src') // location of your src
        ),

        new HtmlWebpackPlugin({
            filename: 'index.html',
            template: 'src/app/index.html',
            inject: true
        }),

        new webpack.LoaderOptionsPlugin({
            minimize: true,
            debug: false
        }),

        new webpack.optimize.UglifyJsPlugin({
            minimize: true,
            sourceMap: false
        }),

        new CopyWebpackPlugin([
            { from: path.join('config', 'tizen') },
            /*   {from: path.join('data'), to: 'data'},*/
            { from: path.join('src/app/shim.js'), to: 'shim.js' },
            { from: path.join('src/app/aws-sdk-2.796.0.min.js'), to: 'aws-sdk-2.796.0.min.js' },
            { from: path.join('src/app/RaptorHelper.js'), to: 'RaptorHelper.js' },
            { from: path.join('src/images/team_logo'), to: 'assets/team_logo' },
            { from: path.join('src/images/icons'), to: 'assets' },
            { from: path.join('src/fonts'), to: 'assets' },
            { from: path.join('service'), to: 'service' },
            { from: path.join('src/images/buttons'), to: 'assets/buttons' },
            { from: path.join('src/app/AppMeasurement.js'), to: 'AppMeasurement.js' },
            { from: path.join('src/app/m3u8-parser.js'), to: 'm3u8-parser.js' }
        ]),

        new webpack.HotModuleReplacementPlugin(),

        new webpack.NoEmitOnErrorsPlugin()
    ]
}
