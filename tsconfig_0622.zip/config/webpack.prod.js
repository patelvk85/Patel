var webpack = require('webpack');
var webpackMerge = require('webpack-merge');
var commonConfig = require('./webpack.common.js');
console.log("PROD EVIRONMENT");

module.exports = webpackMerge(commonConfig, {
    devtool: '',
    //  plugins: [
    // 	new webpack.DefinePlugin({
    // 		'process.env.NODE_ENV': JSON.stringify('production')
    // 	})
    // ]
});
