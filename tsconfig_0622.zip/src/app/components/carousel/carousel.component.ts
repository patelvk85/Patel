import {ChangeDetectorRef, Component, ElementRef, Input, ViewChild} from '@angular/core';
import {BaseComponent} from '../../common/components/base.component';
import {
    FocusService,
    KeyboardService,
    LoggerService,
    TvInfoService,
    ErrorService,
    EnvironmentService
} from '../../common/services';
import {LoginService} from '../../services/login.service';
import {GamechipService} from '../../services/gamechip.service';
import {GamechipModel} from '../../models/gamechip.model';
import {HighlightsComponent, SettingsComponent} from '../';
import {CarouselConstants, LoginConstants} from '../../common/constants';
import {TeamInfo} from '../../models/team-info.model';
import {SubscriptionLike} from 'rxjs';
import {ApplicationService} from '../../services/application.service';
import {VideoModel} from '../../models/vcns/video.model';
import {JsonConvert, ValueCheckingMode} from 'json2typescript';
import {HighlightVideoModel} from '../../models/highlight.video.model';
import {TrackingService} from '../../services/tracking.service';
import * as _ from 'lodash';
import {GuideComponent} from '../guide/guide.component';
import {GuideService} from '../../common/services/guide.service';
import { VoiceService } from '../../services/voice.service';

@Component({
    selector: 'nfl-carousel',
    templateUrl: 'carousel.component.html',
    styleUrls: ['carousel.component.scss'],
})

export class CarouselComponent extends BaseComponent {

    /**
     * Event bus name
     * @type {string}
     */
    keyboardEventBusName = 'drawer';

    @ViewChild('highlight', {static: false})
    private highlightElement: ElementRef;
    @ViewChild('gamechipsWrapper', {static: false})
    private gamechipsWrapperElement: ElementRef;
    @ViewChild('gamechipsContainer', {static: false})
    private gamechipsContainerElement: ElementRef;
    @ViewChild('settings', {static: false})
    private settings: SettingsComponent;
    @ViewChild('highlights', {static: false})
    private highlights: HighlightsComponent;
    @ViewChild('guideComponent', {static: false})
    private guideComponent: GuideComponent;

    private applicationVisibilitySubscription: SubscriptionLike;
    private applicationSmartHubSubscription: SubscriptionLike;
    private authenticateSubscription: SubscriptionLike;

    private readonly expandClearance: number = 305;
    private readonly moveStep: number = 126;

    /**
     * Flag to show or hide drawer
     * @type {boolean}
     */
    private showDrawer: boolean = false;

    /**
     * Flag to expand or collapse panel below gamechip
     * @type {boolean}
     */
    private isGamechipExpanded: boolean = false;

    /**
     * Gamechip list, include setting gamechip
     * @type {GamechipModel[]}
     */
    private gamechips: Array<GamechipModel> = [];

    /**
     * Game auth list, include setting gamechip
     * @type {any[]}
     */
    private gameAuths: Array<any> = [];

    /**
     * NFL team info
     * @private
     * @type {Array<TeamInfo>}
     */
    public teamInfos: Array<TeamInfo> = [];

    /**
     * Use to generate transform gamchip list position animation
     * @type {number}
     * @private
     */
    private _distance: number = 0;

    /**
     * Contain list of blacklist gamechip ID
     * @type {string[]}
     */
    private blackListData = ['233115', '233117', CarouselConstants.GAMECHIP_REDZONE_ID];

    /**
     * Contain list of authorizations failure codes:
     * 0013 - Live streaming will be available X minutes before kickoff.
     * 0014 - Game local backout.
     * 0015 - Game already finished.
     * 0016 - Game not part of Sunday Ticket.
     * 0017 - Game not available outside US.
     * 0019 - Stadium blackout.
     * @type {string[]}
     */
    private gameAuthFailureCodes: Array<String> = ['0014', '0016', '0017'];

    /**
     *
     * @param {number} value
     */
    private set distance(value: number) {
        this._distance = value;
        this.getTransform(value);
    }

    /**
     *
     * @returns {number}
     */
    private get distance(): number {
        return this._distance;
    }

    private updateGamechipDataProcessId;

    private updateGameAuthProcessId;

    /**
     * type of logged in user
     * @type {string}
     */
    private userType: string = this._loginService.getLoggedInUserType();

    @Input()
    public onSelected: (gamechip: GamechipModel) => void;

    @Input()
    public onHighlightSelected: (videoUrls: VideoModel) => void;

    @Input()
    public onDrawerClosed: () => void;

    private readonly CarouselConstants = CarouselConstants;

    private retryLoadGameScoreCount = 0;

    /**
     *
     * @param {KeyboardService} _keyboardService
     * @param {FocusService} _focusService
     * @param {ChangeDetectorRef} _changeDetectorRef
     * @param {LoginService} _loginService
     * @param {TvInfoService} _tvInfoService
     * @param {GamechipService} _gamechipService
     * @param {ApplicationService} _applicationService
     * @param {EnvironmentService} _environmentService
     * @param {ErrorService} _errorService
     * @param {TrackingService} _trackingService
     */
    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                _changeDetectorRef: ChangeDetectorRef,
                private _loginService: LoginService,
                private _tvInfoService: TvInfoService,
                private _gamechipService: GamechipService,
                private _applicationService: ApplicationService,
                private _environmentService: EnvironmentService,
                private _errorService: ErrorService,
                private _trackingService: TrackingService,
                private _guideService: GuideService) {
        super(_keyboardService, _focusService, _changeDetectorRef);

    }

    /**
     * Modify gamechip data
     * Start to update gamechip metadata
     * Highlight default gamechip
     */
    ngAfterViewInit() {
        super.ngAfterViewInit();

        this.authenticateSubscription = this._loginService.on(this._loginService.userAuthenticateEventName).subscribe(isAuth => {
            if (isAuth) {
                this.updateGamechipsScore();
                this.updateGameAuthorizations();
            }
        });

        this.applicationVisibilitySubscription = this._applicationService.on(this._applicationService.documentVisibilityEventName).subscribe(isHidden => {
            if (isHidden) {
                this.clearUpdateGameChipTimeout();
                this.clearUpdateGameAuthTimeout();
            }
        });

        this.applicationSmartHubSubscription = this._applicationService.on(this._applicationService.smartHubRequestEventName).subscribe(this.onSmartHubRequest.bind(this));

        const isDev = false;
        if (!isDev) {
            this.gamechips = this.modifyGamechip(this._loginService.userInfo.games.GameAuthInfo);
            this.updateGameAuthorizations();
            this.updateGamechipsScore();
            this.highlightDefaultGamechip();
        } else {
            this._gamechipService.fakeGamechip().then(gamechips => {
                this.gamechips = this.modifyGamechip(gamechips);
                this.updateGamechipsFakeScore();
                this.highlightDefaultGamechip();
            });
        }

        this._gamechipService.getTeamInfo().then((data) => {
            this.teamInfos = data;
            this.gamechips.forEach(gamechip => {
                const homeTeam = this.teamInfos.find(team => team.nflCode === gamechip.homeTeamCode || team.directvCode === gamechip.homeTeamCode);
                const awayTeam = this.teamInfos.find(team => team.nflCode === gamechip.awayTeamCode || team.directvCode === gamechip.awayTeamCode);
                if (homeTeam && awayTeam) {
                    gamechip.homeTeamColor = homeTeam && homeTeam.homeColor || '#232629';
                    gamechip.awayTeamColor = awayTeam && awayTeam.homeColor || '#232629';
                    gamechip.homeName = homeTeam && homeTeam.name || '';
                    gamechip.awayName = awayTeam && awayTeam.name || '';
                }
            });
        });
    }

    ngOnDestroy() {
        super.ngOnDestroy();
        this.clearUpdateGameChipTimeout();
        this.clearUpdateGameAuthTimeout();
        this.authenticateSubscription.unsubscribe();
        this.applicationVisibilitySubscription.unsubscribe();
        this.applicationSmartHubSubscription.unsubscribe();
    }

    private onSmartHubRequest(gameId: string) {
        let gamechip: GamechipModel = null;
        let gamechipIndex: number = -1;
        this.gamechips.forEach((game, index) => {
            if (game.gameId.toString() === gameId.toString()) {
                gamechip = game;
                gamechipIndex = index;
            }
        });
        if (gamechip) {
            this.setSelectedGamechip(gamechip);
            setTimeout(() => {
                if (this.isStillFocused() && gamechipIndex > -1) {
                    this.addAllInvisibleItemToDomTree();
                    this._focusService.refresh(null, gamechipIndex, 0);
                    this.scrollTo(this._focusService.currentFocusEl);
                }
            }, 500);

        }
    }

    /**
     * Highlight default gamechip
     * Default gamechip index is FantasyZone
     */
    private highlightDefaultGamechip() {
        const defaultIndex = this.gamechips.findIndex((gamechip) => {
            return gamechip.gameId === CarouselConstants.GAMECHIP_FANTASY_ID;
        });
        if (this.userType === LoginConstants.MAX_USER) {
            const defaultGamechip = this.gamechips[defaultIndex];
            this._trackingService.channelOnPageLoad(defaultGamechip.gameId);
            this.setSelectedGamechip(defaultGamechip);
        }
        this.setHighlightGamechip(defaultIndex);
    }

    /**
     * Set highlight state to gamechip
     * @param {number} index
     */
    private setHighlightGamechip(index: number) {
        this.gamechips.forEach((gamechip) => {
            gamechip.isHighlighted = false;
            gamechip.isNextToHighlighted = false;
        });
        this.gamechips[index].isHighlighted = true;
    }

    /**
     * Add setting gamechip to array
     * @param {Array<GamechipModel>} gamechips
     * @returns {Array<GamechipModel>}
     */
    private modifyGamechip(gamechips: Array<GamechipModel>) {

        const games = [];
        gamechips.forEach(gamechip => {
            const imagePath = 'assets/team_logo/';
            const imageExt = '.png';

            gamechip.homeTeamClubImg = `${imagePath}${gamechip.homeTeamCode.toLowerCase()}${imageExt}`;
            gamechip.awayTeamClubImg = `${imagePath}${gamechip.awayTeamCode.toLowerCase()}${imageExt}`;

            const jsonConvert: JsonConvert = new JsonConvert();
            jsonConvert.valueCheckingMode = ValueCheckingMode.ALLOW_NULL;
            try {
                games.push(jsonConvert.deserializeObject(gamechip, GamechipModel));
            } catch (e) {
                console.log(e.message);
            }

        });

        const settingGamechip = new GamechipModel();
        settingGamechip.gameId = CarouselConstants.GAMECHIP_SETTINGS_ID;
        settingGamechip.homeTeamName = CarouselConstants.GAMECHIP_SETTINGS_ID;
        games.splice(0, 0, settingGamechip);
        return games;
    }

    /**
     * Update gamechip statuses
     * @param {Promise} promise
     */
    private executeGamechipPromise(promise: Promise<any>) {
        promise.then(data => {
            const scoreGamechips = [];
            const gameSnapShots = data.GameSnapShot;
            const gameAuths = this.gameAuths || this._loginService.userInfo.games.GameAuthInfo;
            this.gamechips.forEach((gamechip: GamechipModel) => {
                if (gamechip.gameId !== CarouselConstants.GAMECHIP_SETTINGS_ID) {

                    const gamechipData = gameSnapShots.find((game) => {
                        return game.gameId === gamechip.gameId;
                    });

                    if (gamechipData) {
                        gamechip.progress = gamechipData.yardLine;
                        gamechip.preGame = gamechipData.phase === CarouselConstants.GAMECHIP_PREGAME_STATUS;
                        gamechip.finalGame = gamechipData.phase.toLowerCase().indexOf('final') > -1;
                        gamechip.checkGamechipScoring(gamechipData);

                        if (gamechip.touchDown || gamechip.fieldGoal || gamechip.safety) {
                            scoreGamechips.push(gamechip);
                        }

                        if (gamechip.progress) {
                            gamechip.progress <= 10 && (gamechip.progress = 10);
                        } else {
                            gamechip.preGame = true;
                        }

                        gamechip.isFantasyZone = gamechip.gameId === CarouselConstants.GAMECHIP_FANTASY_ID;
                        gamechip.isRedZone = gamechip.gameId === CarouselConstants.GAMECHIP_REDZONE_ID;

                        if (gamechip.isRedZone || gamechip.isFantasyZone) {
                            gamechip.preGame = false;
                            gamechip.finalGame = false;
                        }

                        for (const field of Object.keys(gamechipData)) {
                            gamechip[field] = gamechipData[field];
                        }

                        gamechipData.awayTeamName = gamechip.awayTeamName;
                        gamechipData.homeTeamName = gamechip.homeTeamName;
                        gamechipData.homeName = gamechip.homeName;
                        gamechipData.awayName = gamechip.awayName;
                        gamechipData.imageBaseUrl = this._environmentService.config.topShelfBasePath.endsWith("/") ? this._environmentService.config.topShelfBasePath.substring(0, this._environmentService.config.topShelfBasePath.length - 1) : this._environmentService.config.topShelfBasePath; // 'http://192.168.0.103:8887/'; //
                        gamechipData.imageExt = this._environmentService.config.topShelfFileExtension;
                        gamechipData.kickoffDateTime = gamechip.formattedKickOffFullDate + ' ' + gamechip.formattedKickOffTime; // this._environmentService.config.topShelfFileExtension;

                        // check gamechip blackout
                        const gameAuth = gameAuths.find(game => game.gameId === gamechip.gameId);
                        if (gameAuth) {
                            // Need to check if this is the game infos from authentication manager (gameAuth.blackout)
                            if (gameAuth.blackout == 'true' || (gameAuth.streamable == 'false' && this.gameAuthFailureCodes.indexOf(gameAuth.failureCode) > -1)) {
                                gamechip.blackout = 'true';
                            } else {
                                gamechip.blackout = 'false';
                            }
                        }
                    }
                }
            });
            if (scoreGamechips.length > 0) {
                scoreGamechips.forEach(gamechip => gamechip.setGameState(CarouselConstants.GAME_SCORE_START));
                // Collapse scoring layer after 5 seconds
                setTimeout(() => {
                    scoreGamechips.forEach(gamechip => gamechip.setGameState(CarouselConstants.GAME_SCORE_END));
                    // Need to wait after scoring animation had ended, then turn the scoring layer back to the beginning position
                    setTimeout(() => {
                        scoreGamechips.forEach(gamechip => gamechip.setGameState(CarouselConstants.GAME_SCORE_DEFAULT));
                    }, 550);
                }, 5650);
            }

            this.updateGamechipDataProcessId && this.clearUpdateGameChipTimeout();
            this.updateGamechipDataProcessId = setTimeout(this.updateGamechipsScore.bind(this), data.refresh * 1000);

            const edenData = gameSnapShots.map(snapshot => {
                return {
                    awayTeamName: snapshot.awayTeamName,
                    homeTeamName: snapshot.homeTeamName,
                    homeName: snapshot.homeName,
                    awayName: snapshot.awayName,
                    kickoffDateTime: snapshot.kickoffDateTime,
                    awayTeamScore: snapshot.awayTeamScore,
                    homeTeamScore: snapshot.homeTeamScore,
                    awayTeamClubCode: snapshot.awayTeamClubCode,
                    homeTeamClubCode: snapshot.homeTeamClubCode,
                    gameId: snapshot.gameId,
                    phase: snapshot.phase,
                    clock: snapshot.clock,
                };
            });

            const setEdenData = () => {
                this._applicationService.startBackgroundService({
                    gamechips: edenData,
                    config: {
                        imageBaseUrl: this._environmentService.config.topShelfBasePath.endsWith("/") ? this._environmentService.config.topShelfBasePath.substring(0, this._environmentService.config.topShelfBasePath.length - 1) : this._environmentService.config.topShelfBasePath,
                        imageExt: this._environmentService.config.topShelfFileExtension
                    }
                });
            };

            if (edenData.length > 2) {
                if (edenData[2] && edenData[2].awayName && edenData[2].homeName) {
                    setEdenData();
                }
            } else {
                setEdenData();
            }

            // this.updateGamechipDataProcessId = setTimeout(this.updateGamechipsFakeScore.bind(this), data.refresh * 1000);
        }, (error) => {
            LoggerService.logTrace(error);
            // this.isDrawerOpened() && this._errorService.showError(ErrorMessages.APP_SERVER_CONNECTION_FAILURE);
            this.updateGamechipDataProcessId = window.setTimeout(this.updateGamechipsScore.bind(this), 30 * 1000);
        });
    }

    /**
     * Update gamechip authorizations
     * Re-call getBatchGameAuthServiceUrl fn of GamechipService after a period to get new metadata
     */
    private updateGameAuthorizations() {
        this._gamechipService.getBatchGameAuthServiceUrl().then((data) => {
            if (data && data.status === 'success') {
                this.gameAuths = data.gameAuthorizations.gameAuthorization;
                this.updateGameAuthProcessId && this.clearUpdateGameAuthTimeout();
                this.updateGameAuthProcessId = setTimeout(this.updateGameAuthorizations.bind(this), data.refresh * 1000);
            } else {
                this.updateGameAuthProcessId = setTimeout(this.updateGameAuthorizations.bind(this), 50 * 1000);
            }
        }, (error) => {
            LoggerService.logTrace(error);
            // this.isDrawerOpened() && this._errorService.showError(ErrorMessages.APP_SERVER_CONNECTION_FAILURE);
            this.updateGameAuthProcessId = setTimeout(this.updateGameAuthorizations.bind(this), 300 * 1000);
        });
    }

    /**
     * Stop update game authorizations metadata after a period
     */
    private clearUpdateGameAuthTimeout() {
        clearTimeout(this.updateGameAuthProcessId);
    }

    /**
     * Update gamechip metadata
     * Re-call getGamechipScore fn of GamechipService after a period to get new metadata
     */
    private updateGamechipsScore() {
        this.executeGamechipPromise(this._gamechipService.getGamechipScore());
    }

    /**
     * Stop update gamechip metadata after a period
     */
    private clearUpdateGameChipTimeout() {
        clearTimeout(this.updateGamechipDataProcessId);
    }

    /**
     * Update gamechip fake metadata after a period
     * Re-call updateGamechipsFakeScore fn of GamechipService after a period to get new metadata
     */
    private updateGamechipsFakeScore() {
        this.executeGamechipPromise(this._gamechipService.fakeScore());
    }

    /**
     * Get gamechip by game id
     * @param {string} gameId
     * @returns {GamechipModel}
     */
    public getGamechip(gameId: string): GamechipModel {
        return this.gamechips.find(gamechip => gamechip.gameId === gameId);
    }

    /**
     * Close drawer when Left key Pressed
     * @param {KeyboardEvent} event
     */
    public onLeftPressed(event: KeyboardEvent) {
        this.closeDrawer();
    }

    /**
     * Open drawer
     * Get current focused gamechip
     * Scroll to focused gamechip element
     */
    public openDrawer(actionAfterOpen?: string, startGameId?: string) {
        this.showDrawer = true;
        if (this.gamechips.length) {
            this.addAllInvisibleItemToDomTree();
            this.gamechips = this.gamechips.sort((a: GamechipModel, b: GamechipModel) => {
                return parseInt(a.chipOrder) - parseInt(b.chipOrder);
            });
        }
        this._changeDetectorRef.detectChanges();
        setTimeout(() => {
            const highlightedIndex = this.gamechips.findIndex((gamechip) => {
                if (startGameId != null) {
                    return gamechip.gameId === startGameId;
                }
                return gamechip.isHighlighted;
            });
            this.resetGamechipSize();
            this._focusService.refresh('.gamechip-item', highlightedIndex < 0 ? 0 : highlightedIndex, 0);
            this.updateGamechipSize();
            this.scrollTo(this._focusService.currentFocusEl);
            if (actionAfterOpen === CarouselConstants.OPEN_HIGHLIGHT_ACTION) {
                setTimeout(() => {
                    this.openHighlightPanel(null, this.gamechips[highlightedIndex]);
                }, 300);
            } else if (actionAfterOpen === CarouselConstants.OPEN_SMART_HUB_ACTION) {
                const requestedGamechip = this.gamechips.find(game => {
                    return game.gameId === startGameId;
                });
                requestedGamechip && this.setSelectedGamechip(requestedGamechip);
            }

        }, 100);
        // Make sure focus is in drawer, we can refresh focus later
        this.setFocus();
        this._guideService.showHideGuide([
            {text: 'Watch', icon: 'watch'},
            {text: 'Close', icon: 'close-guide'},
            {text: 'View Highlights', icon: 'view-highlights'}
        ]);
    }

    private resetGamechipSize() {
        this.gamechips.forEach(game => {
            game.isHighlighted = game.isNextToHighlighted = false;
        });
    }

    public setFocusToCarousel(focusRow: number, focusCol: number) {
        this.setFocus('.gamechip-item', focusRow, focusCol);
    }

    /**
     * Close drawer
     * Set focus back to previous component
     */
    public closeDrawer() {
        this.showDrawer = false;
        this._focusService.back();
        this._guideService.showHideGuide([
            {text: 'Show Games', icon: 'show-games'},
            {text: 'Video Controls', icon: 'video-controls'},
            {text: 'Dismiss', icon: 'dismiss'}
        ]);
    }

    public isDrawerOpened(): boolean {
        return this.showDrawer;
    }

    /**
     * Scroll gamechip list to focused element
     * @param {KeyboardEvent} event
     */
    public onUpPressed(event: KeyboardEvent) {
        event['focusEl'] && (this.distance += this.moveStep);
    }

    /**
     * Scroll gamechip list to focused element
     * @param {KeyboardEvent} event
     */
    public onDownPressed(event: KeyboardEvent) {
        event['focusEl'] && (this.distance -= this.moveStep);
    }

    private onBackPressed() {
        this.closeDrawer();
    }

    /**
     * Update gamechip size
     */
    private updateGamechipSize() {
        const currentHighlightIndex = this.gamechips.findIndex(gamechip => {
            return gamechip.isHighlighted;
        });

        if (currentHighlightIndex !== this._focusService.pointer.row && this.isStillFocused()) {
            [currentHighlightIndex - 1, currentHighlightIndex, currentHighlightIndex + 1].forEach(index => {
                if (this.gamechips[index]) {
                    this.gamechips[index].isHighlighted = false;
                }
            });
            this.gamechips[this._focusService.pointer.row] && (this.gamechips[this._focusService.pointer.row].isHighlighted = true);
        }
    }

    private onExpandedPanelClosed(gamechip) {
        return new Promise(resolve => {
            this.isGamechipExpanded = gamechip.isExpanded = !gamechip.isExpanded;
            this.distance += this.expandClearance;
            this._guideService.showHideGuide([
                {text: 'Watch', icon: 'watch'},
                {text: 'Close', icon: 'close-guide'},
                {text: 'View Highlights', icon: 'view-highlights'}
            ]);
            setTimeout(resolve, 200);
        });
    }

    /**
     * Expand panel below gamechip if needed
     * Set gamechip selected state
     * @param {GamechipModel} gamechip
     */
    private openExpandPanel(gamechip: GamechipModel) {
        if (gamechip.gameId === CarouselConstants.GAMECHIP_SETTINGS_ID) {
            requestAnimationFrame(() => {
                this.isGamechipExpanded = gamechip.isExpanded = !gamechip.isExpanded;
                this._changeDetectorRef.detectChanges();
                if (this.isGamechipExpanded) {
                    this.distance -= this.expandClearance;
                    this._guideService.showHideGuide([]);
                    this.settings.open(this.onExpandedPanelClosed.bind(this, gamechip));
                }
            });
        } else {
            this._trackingService.channelOnClickInstances(gamechip);
            this.setSelectedGamechip(gamechip);
        }
    }

    /**
     * Expand highlight panel below gamechip if needed
     * Set gamechip selected state
     * @param {GamechipModel} gamechip
     */
    private openHighlightPanel(event: KeyboardEvent, gamechip: GamechipModel) {
        event && event.stopPropagation();
        if (gamechip.gameId !== CarouselConstants.GAMECHIP_SETTINGS_ID) {
            requestAnimationFrame(() => {
                this.isGamechipExpanded = gamechip.isExpanded = !gamechip.isExpanded;
                this._changeDetectorRef.detectChanges();
                if (this.isGamechipExpanded) {
                    this.distance -= this.expandClearance;
                    this._guideService.showHideGuide([]);
                    this.highlights.open(this.onExpandedPanelClosed.bind(this, gamechip));
                }
            });
        }
    }

    /**
     * Set isSelected attr of gamechip
     * Call onSelected callback
     * @param {GamechipModel} gamechip
     */
    private setSelectedGamechip(gamechip: GamechipModel) {
        this.gamechips.forEach(gamechip => {
            gamechip.isSelected = false;
        });
        gamechip.isSelected = true;
        this.onSelected && this.onSelected(gamechip);
    }

    /**
     * Change transform style to move gamechip list up or down
     * @param {number} distance
     */
    private getTransform(distance: number) {
        this.addVisibleItem();
        requestAnimationFrame(() => {
            this.gamechipsWrapperElement.nativeElement.style.transform = ['translateY(', this.distance, 'px)', ' translateZ(0)'].join('');
            requestAnimationFrame(() => {
                this.updateGamechipSize();
                this.removeInvisibleItem();
                this.gamechipsContainerElement.nativeElement.scrollTop = 0;
            });
        });
    }

    /**
     * Calculate distance for moving gamechip on the fly
     * @param {HTMLElement} element
     */
    private scrollTo(element: HTMLElement) {
        this.gamechipsContainerElement.nativeElement.scrollTop = 0;
        this.distance = this.highlightElement.nativeElement.offsetTop - element.offsetTop;
    }

    private invisibleItems: Array<HTMLElement> = [];
    private visibleRange: number = 4;

    private removeInvisibleItem() {
        if (this.isStillFocused()) {
            const currentIndex = this._focusService.pointer.row;
            const minIndex = currentIndex - this.visibleRange;
            const maxIndex = currentIndex + this.visibleRange;

            this._focusService.focusMatrix.forEach((row, index) => {
                if (index < minIndex || index > maxIndex) {
                    if (!this.invisibleItems[index]) {
                        const el = row[0].firstElementChild;
                        if (el) {
                            this.invisibleItems[index] = el;
                            row[0].removeChild(el);
                        }
                    }
                }
            });
        }
    }

    private addVisibleItem() {
        if (this.isStillFocused()) {
            const currentIndex = this._focusService.pointer.row;
            const minIndex = currentIndex - this.visibleRange;
            const maxIndex = currentIndex + this.visibleRange;

            if (this.invisibleItems[minIndex]) {
                this._focusService.focusMatrix[minIndex][0].insertAdjacentElement('afterbegin', this.invisibleItems[minIndex]);
                this.invisibleItems[minIndex] = undefined;
            }

            if (this.invisibleItems[maxIndex]) {
                this._focusService.focusMatrix[maxIndex][0].insertAdjacentElement('afterbegin', this.invisibleItems[maxIndex]);
                this.invisibleItems[maxIndex] = undefined;
            }
        }
    }

    private addAllInvisibleItemToDomTree() {
        this.invisibleItems.forEach((item, index) => {
            const el = this.gamechipsWrapperElement.nativeElement.querySelector(`div[data-focus-row="${index}"]`);
            if (el && item) {
                el.insertAdjacentElement('afterbegin', item);
            }
        });
        this.invisibleItems = [];
    }

    public playHighlightVideo(video: HighlightVideoModel) {
        this.onHighlightSelected && this.onHighlightSelected(video);
        this.closeDrawer();
    }

    private voiceSpeak(item: GamechipModel) {
        VoiceService.speak(this.getTTS(item));
    }

    private getTTS(item: GamechipModel) {
        let tts = '';
        if (item.isSelected && !this._tvInfoService.isTizen2016()) {
            tts += 'Now Selected, ';
        }
        if (item.gameId === CarouselConstants.GAMECHIP_FANTASY_ID) {
            tts += 'Fantasy Zone';
        } else if (item.gameId === CarouselConstants.GAMECHIP_REDZONE_ID) {
            tts += 'Red Zone';
        } else if (item.gameId === CarouselConstants.GAMECHIP_SETTINGS_ID && !this._tvInfoService.isTizen2016()) {
            tts = 'SETTINGS';
        } else if (item.awayTeamName && item.homeTeamName) {
            tts += `${item.awayTeamName}, vs, ${item.homeTeamName}`;
            if (!this._tvInfoService.isTizen2016()) {
                if (item.phase === CarouselConstants.GAME_PHASE_PREGAME) {
                    // gamechip.formattedKickOffDate + ' ' + gamechip.formattedKickOffTime
                    tts += ` , on ${item.formattedKickOffFullDate}, at ${item.formattedKickOffTime}`;
                } else {
                    tts += `, ${item.awayTeamScore}, ${item.homeTeamScore}`;
                    if (item.phase === CarouselConstants.GAME_PHASE_FINAL
                        || item.phase === CarouselConstants.GAME_PHASE_HALFTIME
                        || item.phase === CarouselConstants.GAME_PHASE_FINAL_OT) {
                        tts += `, ${item.phase}`;
                    } else {
                        tts += `, ${item.phase}, ${item.clock}`;
                    }
                }

                if (item.isBlackedOut) {
                    tts += `, ${CarouselConstants.BLACKED_OUT}`;
                }
            }
        }
        return tts;
    }
}
