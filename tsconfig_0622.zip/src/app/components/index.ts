export * from './login/login.component';
export * from './video/video.component';
export * from './home/home.component';
export * from './carousel/carousel.component';
export * from './settings/settings.component';
export * from './highlights/highlights.component';
export * from './app-alert/app-alert.component';
export * from './app-version/app-version.component';
