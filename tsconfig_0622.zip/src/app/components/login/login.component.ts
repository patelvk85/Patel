import { AfterViewInit, Component, ElementRef, ViewChild, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../../services/login.service';
import { BaseComponent } from '../../common/components/base.component';
import { EnvironmentService, FocusService, KeyboardService, LoadingService, ErrorService } from '../../common/services';
import { SubscriptionLike } from 'rxjs';
import { ApplicationService } from '../../services/application.service';
import { ErrorMessages, LoginConstants } from '../../common/constants';
import { TrackingService } from '../../services/tracking.service';
import { VoiceService } from '../../services/voice.service';
import { AppDialogComponent } from '../app-dialog/app-dialog.component';

@Component({
    selector: 'nfl-login',
    templateUrl: 'login.component.html',
    styleUrls: ['./login.component.scss']
})

export class LoginComponent extends BaseComponent implements AfterViewInit {

    @ViewChild('username', { static: false })
    private username: ElementRef;

    @ViewChild('password', { static: false })
    private password: ElementRef;

    @ViewChild('signin', { static: false })
    private signin: ElementRef;

    @ViewChild('goToSignInBtn', { static: false })
    private goToSignInBtn: ElementRef;

    @ViewChild('appDialogComponent', { static: false })
    private appDialogComponent: AppDialogComponent;

    private isEnvDialogOpened: boolean = false;
    private loginErrorMessage: string = '';
    private isRememberMe: boolean = true;
    private selectedEnv: { name, configUrl };
    private environmentList = [];
    private routeSub: SubscriptionLike;
    private graphicUrl: string = '';
    private showingSignup: boolean = false;
    private keyboardVisible: boolean = false;

    keyboardEventBusName = 'login';

    private readonly LoginConstants = LoginConstants;
    private readonly VoiceService = VoiceService;

    constructor(_keyboardService: KeyboardService,
        _focusService: FocusService,
        _changeDetectorRef: ChangeDetectorRef,
        private _environmentService: EnvironmentService,
        private _loginService: LoginService,
        private _loadingService: LoadingService,
        private _errorService: ErrorService,
        private router: Router,
        private route: ActivatedRoute,
        private _applicationService: ApplicationService,
        private _trackingService: TrackingService) {
        super(_keyboardService, _focusService, _changeDetectorRef);
        this.environmentList = this._environmentService.environments;
        this.selectedEnv = this._environmentService.currentEnvironment;
    }

    ngAfterViewInit() {
        super.ngAfterViewInit();

        const savedUserCredentials = this._loginService.getSavedUserCredentials();
        const isRememberMe = this.isRememberMe = this._loginService.isRememberMe();
        if (isRememberMe) {
            this.username.nativeElement.value = savedUserCredentials.username || this.username.nativeElement.value || '';
        }
        this.routeSub = this.route.queryParams.subscribe(params => {
            if (params.statusCode === '005') {
                this.showPreseason();
            } else if (params.error) {
                this.showErrorMessage(params.error);
            }
        });
        this._trackingService.loginForm();
        this.username.nativeElement.onfocus = (event) => {
            event.preventDefault();
            event.stopImmediatePropagation();
            this.username.nativeElement.onfocus = null;
            setTimeout(() => {
                VoiceService.speak(LoginConstants.SIGN_IN_VOICE_TEXT, {
                    onEnd: () => {
                        this._focusService.currentFocusEl === this.username.nativeElement && this._focusService.refresh();
                    }
                });
            }, 200);
        };
        this.setFocusToLoginForm();
    }

    ngOnDestroy() {
        super.ngOnDestroy();
        this.routeSub.unsubscribe();
    }

    private enableInput(element: HTMLInputElement) {

        if (element.readOnly) {
            element.blur();
            element.readOnly = false;
            element.focus();
        }
        this.keyboardVisible = true;
    }

    private onCancelPressed() {
        this.username.nativeElement.readOnly = true;
        this.password.nativeElement.readOnly = true;
        this.keyboardVisible = false;
    }

    private onBackPressed() {
        if (this.isEnvDialogOpened) {
            this.closeEnvSelection();
        } else {
            this._errorService.showDialog(LoginConstants.EXIT_APP, 'OK', 'Cancel', this.onDialogConfirmed.bind(this));
        }
    }

    private onDonePressed(event) {
        if (!this.isEnvDialogOpened) {
            const usernameInputFocusing = this._focusService.currentFocusEl === this.username.nativeElement;
            const passwordInputFocusing = this._focusService.currentFocusEl === this.password.nativeElement;
            usernameInputFocusing && (this.password.nativeElement.readOnly = false);
            if (passwordInputFocusing) {
                const signInButtonFocusRow = parseInt(this.signin.nativeElement.dataset.focusRow);
                this._focusService.setFocus(signInButtonFocusRow, 0);
            } else {
                this._focusService.down();
            }
        }
    }

    public onPlayPausePressed(event) {
        // this.openEnvSelection(event);
    }

    private toggleRememberMe() {
        this._loginService.toogleRememberMe(this.isRememberMe = !this.isRememberMe);
        VoiceService.speak(this.isRememberMe ? "checked" : "not checked");
    }

    private setFocusToLoginForm() {
        this.setFocus('.signin .focusable');
    }

    private openEnvSelection(event) {
        this.isEnvDialogOpened = true;
        const focusRow = this._environmentService.environments.findIndex((env) => {
            return env.name === this.selectedEnv.name;
        });
        this.setFocus('.env-selection .focusable', focusRow || 0, 0);
    }

    private closeEnvSelection() {
        this.isEnvDialogOpened = false;
        this._focusService.back();
    }

    private setEnvironment(env) {
        this._loadingService.push();
        this._environmentService.setEnvironment(env.name).then(config => {
            this.selectedEnv = env;
            this._loadingService.pop();
            this.closeEnvSelection();
        }, error => {
            this._loadingService.pop();
            this._errorService.showError(ErrorMessages.APP_SERVER_CONNECTION_FAILURE);
        });
    }

    private login() {
        const username = this.username.nativeElement.value;
        const password = this.password.nativeElement.value;
        if (username !== '' && password !== '') {
            this._loadingService.push();
            this._loginService.login(username, password, this.isRememberMe).then(user => {
                this._trackingService.videoKeepAlive();
                this._trackingService.loginSuccess();
                this.router.navigate(['/home'], { relativeTo: this.route });
                this._loadingService.pop();
            }, error => {
                this._loadingService.pop();
                if (error.statusCode === '005') {
                    this.showPreseason();
                } else {
                    this.showErrorMessage(error.statusMessage || error.message);
                }
                this._trackingService.loginError(error.statusCode, error.statusMessage);
            });
        } else {
            this.showErrorMessage(ErrorMessages.LOGIN_WRONG_ACCOUNT);
        }
    }

    signup() {
        this.showingSignup = true;
        var mess = (LoginConstants.SIGN_UP_HIGHLIGHT + LoginConstants.SIGN_UP_MESS + LoginConstants.SIGN_UP_LEGAL).replace("NFLST", "NFL sunday ticket");

        setTimeout(() => {
            this.setFocus('.signup .focusable');
        }, 100);
        if (this.goToSignInBtn) {
            VoiceService.speakMsgAndFocusedElement(mess,
                this.goToSignInBtn.nativeElement, this._focusService);
        }
    }

    goToSignin() {
        this.showingSignup = false;
        setTimeout(() => {
            this.setFocus('.signin .focusable');
        }, 100);
    }

    private showPreseason() {
        this.graphicUrl = this._environmentService.config.preseasonGraphicURL;
        this.setFocus();
    }

    private showErrorMessage(message: string) {
        this.loginErrorMessage = message;
        this._changeDetectorRef.detectChanges();
        VoiceService.speak(message);
    }

    onDialogConfirmed() {
        this._applicationService.exitApplication();
    }

    private focusOnTextBox(text: string) {
        VoiceService.speak(text);
    }

    private focusOnCheckbox() {
        VoiceService.speak(LoginConstants.REMEMBER_ME + (this.isRememberMe ? ", checked" : ", not checked"));
    }
}
