'use strict';

import {Component, ChangeDetectorRef, OnDestroy} from '@angular/core';

@Component({
    selector: 'nfl-spinner',
    templateUrl: 'spinner.component.html',
    styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnDestroy {

    constructor(private _changeDetectorRef: ChangeDetectorRef) {
    }

    ngOnDestroy() {
        this._changeDetectorRef.detach();
    }

}
