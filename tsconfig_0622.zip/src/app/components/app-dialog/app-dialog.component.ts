import {Component, ChangeDetectorRef, ElementRef, ViewChild} from '@angular/core';
import { BaseComponent } from '../../common/components/base.component';
import {KeyboardService, FocusService, ErrorService} from '../../common/services';
import { VoiceService } from '../../services/voice.service';

@Component({
    selector: 'nfl-app-dialog',
    templateUrl: './app-dialog.component.html',
    styleUrls: ['./app-dialog.component.scss']
})
export class AppDialogComponent extends BaseComponent {
    @ViewChild('negativeBtn', {static: false})
    private negativeBtn: ElementRef;
    private readonly VoiceService = VoiceService;

    keyboardEventBusName: 'confirm-dialog';

    private confirmMessage: string = '';
    private positiveButton: string;
    private negativeButton: string;
    private agreeCallback: any;

    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                _changeDetectorRef: ChangeDetectorRef,
                private _errorService: ErrorService) {
            super(_keyboardService, _focusService, _changeDetectorRef);
            this._errorService.on('push-dialog').subscribe(this.openDialog.bind(this));
        }

    openDialog(data) {
        this.positiveButton = data.agreeText;
        this.negativeButton = data.cancelText;
        this.confirmMessage = data.message;
        this.agreeCallback = data.agreeCallback;
        this.setFocus('.confirm-dialog .focusable', 0,  1);
        if (this.negativeBtn) {
            VoiceService.speakMsgAndFocusedElement(this.confirmMessage, 
                this.negativeBtn.nativeElement, this._focusService);
        }
    }

    negativeBtnOnclick() {
        this.closeDialog();
        this.agreeCallback = null;
    }

    positiveBtnOnclick() {
        this.closeDialog();
        this.agreeCallback();
        this.agreeCallback = null;
    }

    onBackPressed() {
        if (this.confirmMessage !== '') {
            this.closeDialog();
            this.agreeCallback = null;
        }
    }

    closeDialog() {
        this.confirmMessage = '';
        this.positiveButton = '';
        this.negativeButton = '';
        this._focusService.back();
    }
}
