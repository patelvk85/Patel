import {Component, ElementRef, Input, ViewChild, ChangeDetectorRef} from '@angular/core';
import {BaseComponent} from '../../common/components/base.component';
import {FocusService, KeyboardService} from '../../common/services';
import {GamechipModel} from '../../models/gamechip.model';
import {VCNSService} from '../../services/vcns.service';
import {GamechipHighlightModel} from '../../models/vcns/gamechip.highlight.model';
import {ClipModel} from '../../models/vcns/clip.model';
import {CarouselConstants, ErrorMessages} from '../../common/constants';
import {VideoModel} from '../../models/video.model';
import {HighlightVideoModel} from '../../models/highlight.video.model';
import { VoiceService } from '../../services/voice.service';

@Component({
    selector: 'nfl-highlights',
    templateUrl: 'highlights.component.html',
    styleUrls: ['./highlights.component.scss']
})

export class HighlightsComponent extends BaseComponent {

    keyboardEventBusName = 'highlights-gamechip';

    @Input()
    public gamechip: GamechipModel;
    @Input()
    public onSelected: (videoUrls: VideoModel) => void;
    @ViewChild('highlightsWrapper', {static: false})
    private highlightsWrapper: ElementRef;

    private onClosed: Function;
    private _videos: Array<ClipModel> = [];
    private errorMsg: string = '';

    private readonly margin: number = 48;

    private isShowLoading: boolean = false;

    private get videos(): Array<ClipModel> {
        return this._videos;
    }

    private set videos(videos: Array<ClipModel>) {
        this._videos = videos;
        this.calculateWidthOfVideoList();
    }

    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                _changeDetectorRef: ChangeDetectorRef,
                private hostElement: ElementRef,
                private _VCNSService: VCNSService) {
        super(_keyboardService, _focusService, _changeDetectorRef);

    }

    public open(onClosed: Function) {
        VoiceService.speak("loading");
        this.isShowLoading = true;
        this.onClosed = onClosed;
        this.videos = [];
        this.setFocus();

        if (this.gamechip.gameKey === CarouselConstants.GAMECHIP_REDZONE_ID || this.gamechip.gameKey === CarouselConstants.GAMECHIP_FANTASY_ID) {
            this.gamechip.gameKey = '';
        }
        this._VCNSService.getHighlightContents(this.gamechip.gameKey).then((data: GamechipHighlightModel) => {

            if (data.count > 0 && this.isStillFocused()) {
                setTimeout(() => {
                    this.errorMsg = '';
                    this.videos = data.clips;

                    this._changeDetectorRef.detectChanges();
                    let focusCol = 0;
                    if (this._VCNSService.selectedHighlight && this._VCNSService.selectedHighlight.gamechipId === this.gamechip.gameId) {
                        focusCol = this.videos.findIndex((v) => {
                            return v.id === this._VCNSService.selectedHighlight.highlightId;
                        });
                    }

                    setTimeout(() => {
                        if (this.isStillFocused()) {
                            this.preventNativeScroll();
                            this._focusService.refresh('.gamechip-highlights .video-item', 0, focusCol < 0 ? 0 : focusCol);
                            this.getTransform();
                            this.isShowLoading = false;
                        }
                    }, 500);

                    if (this._VCNSService.selectedHighlight && this._VCNSService.selectedHighlight.destroyAfterView) {
                        this._VCNSService.selectedHighlight = null;
                    }

                }, 500);
            } else {
                this.errorMsg = ErrorMessages.HIGHLIGHT_NOT_AVAILABLE;
                this.isShowLoading = false;
            }
        }, err => {
            this.errorMsg = ErrorMessages.HIGHLIGHT_NOT_AVAILABLE;
            this.isShowLoading = false;
        });

    }

    public close() {
        if (this.onClosed instanceof Function) {
            this.onClosed().then(() => this._focusService.back());
        } else {
            this._focusService.back();
        }
    }

    public onBackPressed() {
        this.close();
    }

    public onLeftPressed(event) {
        this.getTransform();
    }

    public onRightPressed(event) {
        this.getTransform();
    }

    private calculateWidthOfVideoList() {
        const itemWidth = 405;
        const width = this.videos.length * (itemWidth + this.margin);
        if (this.highlightsWrapper) {
            this.highlightsWrapper.nativeElement.style.width = width + 'px';
        }
    }
    
    private currentItemIndex: number = 0;
    private totalItem: number = 0;

    private calculateDistance() {
        // Prevent Native scroll
        this.preventNativeScroll();
        const pageSize = 3;

        const currentFocusEl = this._focusService.currentFocusEl;
        const videoItemEls = this.hostElement.nativeElement.querySelectorAll('.video-item');
        const itemWidth = currentFocusEl ? currentFocusEl.getBoundingClientRect().width + this.margin : 0;
        const index = Array.prototype.indexOf.call(videoItemEls, currentFocusEl);
        const currentPage = Math.floor(index / pageSize);
        this.currentItemIndex = index;
        this.totalItem = videoItemEls.length ;
        return currentPage * itemWidth * pageSize;
    }

    /**
     * Change transform style to move highlight list left or right
     * @param {number} distance
     */
    private getTransform() {
        const distance = this.calculateDistance();
        requestAnimationFrame(() => {
            this.preventNativeScroll();
            this.highlightsWrapper.nativeElement.style.transform = ['translateX(-', distance, 'px)'].join('');
        });
    }

    /**
     * Open a highlight video
     */
    private openHighlightVideo($event, index: number) {
        $event.stopPropagation();
        const videos: Array<VideoModel> = [];
        const teamsName = [this.gamechip.awayTeamCode, ' vs ', this.gamechip.homeTeamCode].join('');
        this.setSelectedHighlight(new HighlightVideoModel(this.videos[index].id, this.videos[index].title, this.videos[index].url, teamsName, this.gamechip.gameId));
    }

    /**
     * Call onSelected callback
     * @param {Array<string>} videos
     */
    private setSelectedHighlight(video: VideoModel) {
        this._VCNSService.selectedHighlight = {
            destroyAfterView: false,
            highlightId: this.videos[this._focusService.pointer.col].id,
            gamechipId: this.gamechip.gameId
        };
        this.close();
        this.onSelected && this.onSelected(video);
    }

    private preventNativeScroll() {
        const videoContainerEl = <HTMLElement> this.hostElement.nativeElement.querySelector('.video-list');
        videoContainerEl && (videoContainerEl.scrollLeft = 0);
    }

    private voiceSpeak(title: string) {
        VoiceService.speak(title);
    }
}
