import { Component, ViewChild, ChangeDetectorRef } from '@angular/core';
import { BaseComponent } from '../../common/components/base.component';
import { ErrorService, FocusService, KeyboardService } from '../../common/services';
import { CarouselComponent, VideoComponent } from '../';
import { GamechipService } from '../../services/gamechip.service';
import { LoginService } from '../../services/login.service';
import { SubscriptionLike, from } from 'rxjs';
import {
    APIErrorCodes,
    CarouselConstants,
    ErrorMessages,
    KeyCode,
    LoginConstants,
    VideoConstants
} from '../../common/constants';
import { VCNSService } from '../../services/vcns.service';
import { GamechipModel } from '../../models/gamechip.model';
import { GamechipShortcutModel } from '../../models/vcns/gamechip.shortcut.model';
import { PlayerService } from '../../services/player.service';
import { ApplicationService } from '../../services/application.service';
import { VideoModel } from '../../models/video.model';
import { ShortcutVideoModel } from '../../models/shortcut.video.model';
import { AppAlertComponent } from '../../components';
import { NotificationService } from '../../services/notification.service';
import { AlertModel } from '../../models/alert.model';
import * as _ from 'lodash';
import { GuideComponent } from '../guide/guide.component';
import { constants, REPORT_TITLE_SUFFIX } from '../../common/constants/constants';
import { RaptorService } from '../../raptor.service';

/**
 *
 * @export
 * @class HomeComponent
 * @extends {BaseComponent}
 */
@Component({
    selector: 'nfl-home',
    templateUrl: 'home.component.html',
    styleUrls: ['./home.component.scss']
})

export class HomeComponent extends BaseComponent {

    keyboardEventBusName = 'home-page';

    @ViewChild('videoComponent', { static: false })
    private videoComponent: VideoComponent;

    @ViewChild('carouselComponent', { static: false })
    private carouselComponent: CarouselComponent;

    @ViewChild('appAlertComponent', { static: false })
    private appAlertComponent: AppAlertComponent;

    @ViewChild('guideComponent', { static: false })
    private guideComponent: GuideComponent;

    private loggedInUserType: string = this._loginService.getLoggedInUserType();
    private authenticateSubscription: SubscriptionLike;
    private applicationSubscription: SubscriptionLike;
    private notificationSubscription: SubscriptionLike;
    private gamechipSubscription: SubscriptionLike;
    private hasSplash: boolean = true;
    private currentSelectedGamechip: GamechipModel;
    private selectedGamechipBeforeGoBg: GamechipModel;
    private playingVideoType: string = '';
    private showingConfirmDialog: boolean;

    constructor(_keyboardService: KeyboardService,
        _focusService: FocusService,
        _changeDetectorRef: ChangeDetectorRef,
        private _gamechipService: GamechipService,
        private _loginService: LoginService,
        private _VCNSService: VCNSService,
        private _playerService: PlayerService,
        private _applicationService: ApplicationService,
        private _notificationService: NotificationService,
        private _errorService: ErrorService,
        private _raptorService: RaptorService) {
        super(_keyboardService, _focusService, _changeDetectorRef);

        [
            KeyCode.ArrowDown
        ].forEach(keyCode => {
            this.functionMapping[keyCode.toFixed()] = 'cancelAlertIfNeeded';
        });

        this._applicationService.onForceLogout.subscribe(mess => {
            this.showingConfirmDialog = true;
            this._errorService.showError(mess, 'Close');
        });
    }

    ngAfterViewInit() {
        super.ngAfterViewInit();
        this.setFocus();
        this.hasSplash = true;
        this.authenticateSubscription = this._loginService.on(this._loginService.userAuthenticateEventName).subscribe(isAuth => {
            if (isAuth && this.currentSelectedGamechip) {
                this.playGamechip(this.currentSelectedGamechip);
            }
        });
        this.applicationSubscription = this._applicationService.on(this._applicationService.documentVisibilityEventName).subscribe(isHidden => {
            if (isHidden) {
                if (this.currentSelectedGamechip) {
                    this.selectedGamechipBeforeGoBg = this.currentSelectedGamechip;
                }
                this._notificationService.disconnectServer();
            } else {
                if (this.selectedGamechipBeforeGoBg) {
                    this.currentSelectedGamechip = this.selectedGamechipBeforeGoBg;
                }
                this._notificationService.connectServer();
            }
        });
        this._raptorService.initialize();
    }

    /**
     * Display the drawer and play video after view rendered
     */
    private viewRendered() {
        this.loggedInUserType === LoginConstants.BASIC_USER && this.videoComponent.stopVideoPlayBack();
        /** Set highlight gamechip */
        const gameIdFromSmartHub = this._applicationService.getAppLaunchData();
        if (!gameIdFromSmartHub) {
            this.openGamechipDrawer();
        } else {
            this.openGamechipDrawer(CarouselConstants.OPEN_SMART_HUB_ACTION, gameIdFromSmartHub);
        }
        this._notificationService.connectServer();
        this.notificationSubscription = this._notificationService
            .on(this._notificationService.appAlertEventName)
            .subscribe((alert: AlertModel) => this.onReceiveInAppAlert(alert));
    }

    ngOnDestroy() {
        super.ngOnDestroy();
        this._notificationService.disconnectServer();
        this.notificationSubscription && this.notificationSubscription.unsubscribe();
        this.authenticateSubscription && this.authenticateSubscription.unsubscribe();
        this.applicationSubscription && this.applicationSubscription.unsubscribe();
        this.gamechipSubscription && this.gamechipSubscription.unsubscribe();
    }

    /**
     * Play the video from the selected gamechip
     *
     * @param {GamechipModel} gamechip
     * @memberof HomeComponent
     */
    public playGamechip(gamechip: GamechipModel) {
        this.videoComponent && this.videoComponent.stopVideoPlayBack();
        if (this.gamechipSubscription && !this.gamechipSubscription.closed) {
            this.gamechipSubscription.unsubscribe();
        }
        this.currentSelectedGamechip = gamechip;
        this.playingVideoType = VideoConstants.VIDEO_TYPE_GAMECHIP;
        if (this.loggedInUserType === LoginConstants.BASIC_USER && (gamechip.gameId === CarouselConstants.GAMECHIP_FANTASY_ID || gamechip.gameId === CarouselConstants.GAMECHIP_REDZONE_ID)) {
            this.videoComponent.showMessageVideoError(ErrorMessages.GAMECHIP_NOT_AVAILABLE);
        } else {
            if (gamechip.phase && gamechip.phase.toLowerCase().startsWith("final")) {
                this._raptorService.createSession(`[${gamechip.gameId}] ${gamechip.title} ${REPORT_TITLE_SUFFIX.SHORTCUT}`, false);
                this.gamechipSubscription = from(this._VCNSService.getShortcutContents(gamechip.gameKey)).subscribe((shortcut: GamechipShortcutModel) => {
                    if (shortcut.count > 0) {
                        /**  Shortcut available then play it */
                        const video = new ShortcutVideoModel(gamechip.gameId, gamechip.title, shortcut.clips[0].metadata.media.video.high);
                        this.videoComponent.openVideo(video, this.playingVideoType).then(() => {
                            this.openGamechipDrawer();
                        });
                    } else {
                        /** Shortcut is not available then display error message */
                        this.gamechipSubscription = from(this._gamechipService.getGamechipUrl(gamechip.gameId)).subscribe((gameChipIdUrlResp) => {
                            if (gameChipIdUrlResp && gameChipIdUrlResp.status !== constants.STATUS_SUCCESS) {
                                if (gameChipIdUrlResp) {
                                    this._raptorService.cleanupSession({ isFatal: true, errorMsg: gameChipIdUrlResp.message, errorCode: parseInt(gameChipIdUrlResp.statusCode) });
                                    this.videoComponent.showMessageVideoError(gameChipIdUrlResp.message);
                                    this.currentSelectedGamechip = null;
                                } else {
                                    this._raptorService.cleanupSession({ isFatal: true, errorMsg: "" });
                                }
                            }
                        },
                        err => {
                            this._raptorService.cleanupSession({ isFatal: true, errorMsg: err.message, errorCode: err.status });
                        });
                    }
                },
                err => {
                    this._raptorService.cleanupSession({ isFatal: true, errorMsg: err.message, errorCode: err.status });
                });
            } else {
                this._raptorService.createSession("[" + gamechip.gameId + "] " + gamechip.title, true);
                this.gamechipSubscription = from(this._gamechipService.getGamechipUrl(gamechip.gameId)).subscribe((gameChipIdUrlResp) => {
                    if (gameChipIdUrlResp && gameChipIdUrlResp.status === constants.STATUS_SUCCESS) {
                        const video = new VideoModel(gamechip.gameId, gamechip.title, true, decodeURIComponent(gameChipIdUrlResp.url), gameChipIdUrlResp.cdn);
                        this.videoComponent.openVideo(video, this.playingVideoType).then(() => {
                            this.openGamechipDrawer();
                        });
                    } else {
                        if (gameChipIdUrlResp) {
                            this._raptorService.cleanupSession({ isFatal: true, errorMsg: gameChipIdUrlResp.message, errorCode: parseInt(gameChipIdUrlResp.statusCode) });
                            this.videoComponent.showMessageVideoError(gameChipIdUrlResp.message);
                            this.currentSelectedGamechip = null;
                        } else {
                            this._raptorService.cleanupSession({ isFatal: true, errorMsg: "" });
                        }
                    }
                },
                err => {
                    this._raptorService.cleanupSession({ isFatal: true, errorMsg: err.message, errorCode: err.status });
                });
            }
        }
    }

    /**
     * Auto play a list of highlight videos
     *
     * @param {Array<string>} videos
     * @memberof HomeComponent
     */
    public playHighlightVideo(video: VideoModel) {
        this.playingVideoType = VideoConstants.VIDEO_TYPE_HIGHLIGHT;
        const onHighlightVideoChanged = this._playerService.on('onBufferingStart').subscribe(() => {
            this._VCNSService.selectedHighlight.highlightId = video.id;
        });

        this._raptorService.createSession(video.assetName, false);
        this.videoComponent.openVideo(video, this.playingVideoType).then((isForce) => {
            this.stopHighlightVideo();
            onHighlightVideoChanged.unsubscribe();
        });
    }

    /**
     * stop Highlight and show Highlight panel
     */
    public stopHighlightVideo() {
        this._VCNSService.selectedHighlight && (this._VCNSService.selectedHighlight.destroyAfterView = true);
        this.playingVideoType = null;
        this.currentSelectedGamechip ? this.playGamechip(this.currentSelectedGamechip) : this.videoComponent.showVideoBackground();
        this.videoComponent.isControlsShowing() && this.videoComponent.closeControls();
        !this.carouselComponent.isDrawerOpened() && this.carouselComponent.openDrawer(CarouselConstants.OPEN_HIGHLIGHT_ACTION, this._VCNSService.selectedHighlight.gamechipId);
        this._changeDetectorRef.detectChanges();
    }

    private openVideoControls(event) {
        // show video control
        this.cancelAlertIfNeeded();
        this.videoComponent.openControls();
        if (this.videoComponent.isControlsShowing()) {
            this.guideComponent.hideGuideButtons();
        }
    }

    private openGamechipDrawer(action?, data?) {
        this.videoComponent.closeControls();
        this.cancelAlertIfNeeded();
        if (!this.carouselComponent.isDrawerOpened()) {
            this.carouselComponent.openDrawer(action, data);
        }
    }

    private onReceiveInAppAlert(alert: AlertModel) {
        this.getAlertColor(alert);
        this.appAlertComponent.pushAlert(alert);
        this.openInAppAlert();
    }

    private getAlertColor(alert: AlertModel) {
        const teamInfos = this.carouselComponent.teamInfos;
        const homeTeam = teamInfos.find(team => team.nflCode === alert.team || team.directvCode === alert.team);

        if (homeTeam) {
            alert.teamColor = homeTeam && homeTeam.homeColor || '#232629';
        }
    }

    private openInAppAlert() {
        if (this.isStillFocused() && this._notificationService.isAlertOn && (!this.playingVideoType || this.playingVideoType === VideoConstants.VIDEO_TYPE_GAMECHIP)) {
            // If we are in good shape then show alert
            this.appAlertComponent.openAlert();
        } else {
            // If we are NOT in good shape then debounce show alert 5s
            // After 5s call openInAppAlert again to check if we are in good shape or not
            this.debounceOpenAlert();
        }
    }

    private cancelAlertIfNeeded() {
        const isAlertShowing = this.appAlertComponent.isAlertShowing();
        isAlertShowing && this.appAlertComponent.cancelAlert();
        return isAlertShowing;
    }

    private debounceOpenAlert = _.debounce(this.openInAppAlert.bind(this), 5000);

    private onAppAlertClose(showNext) {
        showNext && this.debounceOpenAlert();
    }

    private playAlertVideo() {
        this.cancelAlertIfNeeded();
        this.playingVideoType = VideoConstants.VIDEO_TYPE_ALERT;
        const onAlertVideoStopped = () => {
            this.playingVideoType = null;
            if (this.currentSelectedGamechip) {
                this.playGamechip(this.currentSelectedGamechip);
                this.videoComponent.isControlsShowing() && this.videoComponent.closeControls();
                this._changeDetectorRef.detectChanges();
            } else {
                this.videoComponent.showVideoBackground();
            }
        };

        var video = this.appAlertComponent.getHighLightVideo(this.playingVideoType);
        this._raptorService.createSession(video.assetName, false);
        this.videoComponent.openVideo(video, this.playingVideoType).then(onAlertVideoStopped.bind(this));
    }

    private onEnterPressed(event) {
        if (this.appAlertComponent.isAlertShowing()) {
            this.playAlertVideo();
        } else if (!this.showingConfirmDialog) {
            this.openVideoControls(event);
        }
    }

    private onUpPressed(event) {
        this.openVideoControls(event);
    }

    private onRightPressed(event) {
        this.guideComponent.resetDebounce();
        this.openGamechipDrawer();
    }

    private onLeftPressed() {
        const isAlertShowing = this.cancelAlertIfNeeded();
        !isAlertShowing && this.guideComponent.hideGuideButtons();
    }

    /**
     * handle to stop playing Highlight when press back
     */
    public onBackPressed() {
        if (this.playingVideoType === VideoConstants.VIDEO_TYPE_HIGHLIGHT) {
            this._playerService.stop();
        } else if (!this.appAlertComponent.isAlertShowing() && !this.hasSplash) {
            this.showingConfirmDialog = true;
            this._errorService.showDialog(LoginConstants.EXIT_APP, 'OK', 'Cancel', this.onDialogConfirmed.bind(this));
        }
        this.cancelAlertIfNeeded();
    }

    private onPlayPressed(event) {
        this.openVideoControls(event);
        this.videoComponent.onPlayPressed(event);
    }

    private onPausePressed(event) {
        this.openVideoControls(event);
        this.videoComponent.onPausePressed(event);
    }

    private onPlayPausePressed(event) {
        this.openVideoControls(event);
        this.videoComponent.onPlayPausePressed(event);
    }

    private onRewindPressed(event) {
        this.openVideoControls(event);
        this.videoComponent.onRewindPressed(event);
    }

    private onFastForwardPressed(event) {
        this.openVideoControls(event);
        this.videoComponent.onFastForwardPressed(event);
    }

    private onStopPressed(event) {
        this.videoComponent.onStopPressed(event);
    }

    /**
     * if user doesn't work on osd popup within 15 seconds, the osd popup will be hide and the video will be stop
     * @param {boolean} withoutAction
     */
    public withoutActionAfterOSDShowing(withoutAction: boolean) {
        if (withoutAction) {
            this.videoComponent.stopVideoPlayBack();
        }
    }

    onDialogConfirmed() {
        this._applicationService.exitApplication();
    }

    onCloseDialog() {
        this.showingConfirmDialog = false;
    }

    onfinishAd() {
        this.hasSplash = false;
        this._changeDetectorRef.detectChanges();
        this.viewRendered();
    }
}
