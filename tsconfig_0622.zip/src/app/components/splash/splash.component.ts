import {Component, ElementRef, Input, ViewChild, ChangeDetectorRef, Output, EventEmitter} from '@angular/core';
import {BaseComponent} from '../../common/components/base.component';
import {KeyboardService, FocusService} from '../../common/services/index';
import {SplashService} from '../../services/splash.service';
import {AdModel} from '../../models/ad.model';
import {AdDetailsModel} from '../../models/ad.details.model';
import {SplashConstants} from '../../common/constants/splash.constants';
import {fadeInFadeOut} from '../../animations/show-hide.animations';
import { VoiceService } from '../../services/voice.service';

@Component({
    selector: 'nfl-splash',
    templateUrl: 'splash.component.html',
    animations: [
        fadeInFadeOut
    ],
    styleUrls: ['./splash.component.scss']
})

export class SplashComponent extends BaseComponent {
    @Output() finishAd = new EventEmitter();

    keyboardEventBusName = 'splash-ad';
    private adData: AdDetailsModel = null;
    private hasSplash: boolean = true;
    private splashAdTime: number = 5000;
    private slashAdTextTime: number = 2500;
    private isAdImageLoaded: boolean = false;

    public splashAdText: string = '';

    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                _changeDetectorRef: ChangeDetectorRef,
                private _splashService: SplashService) {
        super(_keyboardService, _focusService, _changeDetectorRef);
        this.getSplashAd();
    }

    private getSplashAd() {
        this.splashAdText = SplashConstants.LOADING_TEXT;
        VoiceService.speak(this.splashAdText);
        this._splashService.getAdInformation().then((adInfo) => {
            this.adData = adInfo;
            this.startAdTimer();
        });
        window.setTimeout(() => {
            this.splashAdText = SplashConstants.WAITING_TEXT;
            VoiceService.speak(this.splashAdText);
        }, this.slashAdTextTime);
    }

    public loadedAd() {
        this.isAdImageLoaded = true;
        if (this.timer) {
            window.clearTimeout(this.timer);
        }
        this.startAdTimer();
    }
    timer: any;
    startAdTimer() {
        this.timer = window.setTimeout(() => {
            this.hasSplash = false;
            this.finishAd.emit("");
        }, this.splashAdTime)
    }
}
