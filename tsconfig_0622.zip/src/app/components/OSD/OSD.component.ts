import {Component, ElementRef, EventEmitter, Output, ViewChild} from '@angular/core';
import {FocusService, KeyboardService} from '../../common/services';
import {ApplicationService} from '../../services/application.service';
import {SubscriptionLike} from 'rxjs';
import * as _ from 'lodash';
import {BaseComponent} from '../../common/components/base.component';
import {VoiceService} from '../../services/voice.service';
import { ErrorMessages } from '../../common/constants/error-messages.constants';

@Component({
    selector: 'nfl-osd',
    templateUrl: 'osd.component.html',
    styleUrls: ['./osd.component.scss']
})

export class OsdComponent extends BaseComponent {
    @ViewChild('continueButton', {static: false})
    private continueButton: ElementRef;
    private readonly ErrorMessages = ErrorMessages;
    private readonly VoiceService = VoiceService;

    keyboardEventBusName = 'osd';

    @Output()
    withoutAction = new EventEmitter<boolean>();

    /**
     * set true/false for osd popup showing
     * @type {boolean}
     */
    public isShowOSDPopup: boolean = false;

    /**
     * Keyboard event subscription
     */
    private hasEventSubscription: SubscriptionLike;

    /**
     * User inactive in 4 hours
     * @type {number}
     */
    private acceptedTimeForApp = 4 * 60 * 60 * 1000;

    /**
     * User inactive in 15 seconds after show OSD msg popup
     * @type {number}
     */
    private acceptedTimeForOSDShowing = 15 * 1000;

    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                private _applicationService: ApplicationService) {
        super(_keyboardService, _focusService);
    }

    /**
     * Subscribe to keyboard event
     * Start debounce show OSD popup
     * if app has event and ODS popup is showing, then debounce hide OSD popup
     * if app has event and ODS popup is hidden, then debounce show OSD popup
     */
    ngAfterViewInit() {
        super.ngAfterViewInit();
        this.hasEventSubscription = this._keyboardService.on('hasEvent').subscribe(checked => {
            this.isShowOSDPopup ? this.debounceHide() : this.debounceShow();
        });
        this.debounceShow();
    }

    /**
     * Unsubscribe to keyboard event
     * Reset show and hide OSD debounce
     */
    ngOnDestroy() {
        super.ngOnDestroy();
        this.hasEventSubscription.unsubscribe();
        this.resetAllDebounce();
    }

    /**
     * Show OSD msg popup
     * Set focus to OSD popup
     * Start debounce hide OSD msg popup
     */
    public showOSDPopup() {
        if (!this.isShowOSDPopup) {
            this.isShowOSDPopup = true;
            this.setFocusToOSDPopup();
            this.debounceHide();
        }
    }

    /**
     * set focus on Continue watching button of osd popup
     */
    private setFocusToOSDPopup() {
        setTimeout(() => {
            if (this.continueButton) {
                VoiceService.speakMsgAndFocusedElement(ErrorMessages.OSD_MESSAGE, 
                    this.continueButton.nativeElement, this._focusService);
            }
            this.setFocus('.popup-osd-message .focusable');
        }, 100);
    }

    /**
     * execute showOSDPopup after 4 hours
     */
    public debounceShow = _.debounce(() => {
        this.showOSDPopup();
    }, this.acceptedTimeForApp);

    /**
     * Fire Event to HomeComponent if user still inactive after show OSD popup
     * HomeComponent will stop playback and show video background
     * Hide OSD popup
     */
    private debounceHide = _.debounce(() => {
        this.withoutAction.emit(true);
        this.hideOSDPopup();
    }, this.acceptedTimeForOSDShowing);

    /**
     * reset all debounce() in osd component
     */
    public resetAllDebounce() {
        this.debounceShow.cancel();
        this.debounceHide.cancel();
    }

    /**
     * Hide OSD popup
     * Cancel hide debounce in case user choose continue watching
     * Return focus to previous component
     */
    public hideOSDPopup() {
        if (this.isShowOSDPopup) {
            this.debounceHide.cancel();
            this.isShowOSDPopup = false;
            this._focusService.back();
        }
    }

    /**
     * When use press continue watching button
     * Hide OSD popup
     * Start show debounce again
     */
    private continueWatching($event) {
        $event.stopPropagation();
        this.hideOSDPopup();
        this.debounceShow();
    }

    /**
     * When user choose exit app
     * Call exit fn to terminate app
     */
    private exitApp() {
        this._applicationService.exitApplication();
    }
}
