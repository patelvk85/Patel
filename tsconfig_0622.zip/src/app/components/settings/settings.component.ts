import {Component, ChangeDetectorRef, ViewChild} from '@angular/core';
import {BaseComponent} from '../../common/components/base.component';
import {FocusService, KeyboardService, LoggerService, ErrorService, EnvironmentService} from '../../common/services';
import {LoginService} from '../../services/login.service';
import {ActivatedRoute, Router} from '@angular/router';
import {UserInfoModel} from '../../common/models/user-info.model';
import {SettingConstants} from '../../common/constants/setting.constants';
import {NotificationService} from '../../services/notification.service';
import {ErrorMessages} from '../../common/constants';
import { ConfigEnvModel } from '../../common/models/config.env.model';
import { AppDialogComponent } from '../app-dialog/app-dialog.component';
import { VoiceService } from '../../services/voice.service';

@Component({
    selector: 'nfl-settings',
    templateUrl: 'settings.component.html',
    styleUrls: ['./settings.component.scss']
})

export class SettingsComponent extends BaseComponent {

    /**
     * Event Bus Name
     * @type {string} menu
     */
    keyboardEventBusName = 'setting-gamechip';
    confirmMessage = '';

    /**
     * callback when close setting panel
     */
    private onClosed: Function;

    /**
     * User information
     */
    private userInfo: UserInfoModel;

    /**
     * App config
     */
    private config: ConfigEnvModel;

    private packageInfo = require('../../../../package.json');

    /**
     * List of menu in setting
     * @type {string[]}
     */
    private menu: Array<string> = [
        SettingConstants.ACCOUNT,
        SettingConstants.ALERTS,
        SettingConstants.FAQS,
        SettingConstants.TERMS_OF_USE,
        SettingConstants.PRIVACY_POLICY,
        SettingConstants.LEGAL_DISCLOSURE,
        SettingConstants.DO_NOT_SELL_INFO
    ];

    private readonly SettingConstants = SettingConstants;
    private readonly VoiceService = VoiceService;
    
    @ViewChild('appDialogComponent', {static: false})
    private appDialogComponent: AppDialogComponent;

    /**
     * actual selected Menu
     * @type {string}
     * @private
     */
    private _selectedMenu: string = SettingConstants.ACCOUNT;

    /**
     * Setter of selectedMenu
     * Refresh focus service to make new element focusable
     * @param {string} value
     */
    private set selectedMenu(value: string) {
        this._selectedMenu = value;
        setTimeout(() => {
            this._focusService.refresh();
        }, 0);
    }

    /**
     * Getter of selectedMenu
     * @returns {string}
     */
    private get selectedMenu(): string {
        return this._selectedMenu;
    }

    private privacyContent: string = '';
    private termOfUseContent: string = '';

    /**
     *
     * @param _keyboardService
     * @param _focusService
     * @param _changeDetectorRef
     * @param _loginService
     * @param router
     * @param route
     * @param _notificationService
     * @param _errorService
     * @param _environmentService
     */
    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                _changeDetectorRef: ChangeDetectorRef,
                private _loginService: LoginService,
                private router: Router, private route: ActivatedRoute,
                private _notificationService: NotificationService,
                private _errorService: ErrorService,
                private _environmentService: EnvironmentService) {
        super(_keyboardService, _focusService, _changeDetectorRef);
        this.userInfo = this._loginService.userInfo;
        this.config = this._environmentService.config;
        if (!this.config.doNotSellURL && this.menu.length > 5) {
            this.menu.pop();
        }

        this._loginService.getPrivacyContent().then((content: string) => {
            this.privacyContent = content;
        });

        this._loginService.getTermOfUseContent().then((content: string) => {
            this.termOfUseContent = content;
        });
    }

    /**
     * Open setting panel
     * Set init focus element
     * Set onClose callback - this fn will be called when we close setting panel
     * @param {Function} onClosed
     */
    public open(onClosed: Function) {
        this.onClosed = onClosed;
        this.setFocus('.setting-panel .focusable');
        // Waiting for expanding animation finished
        setTimeout(() => {
            let selectedMenuIndex = this.menu.findIndex((m) => {
                return m === this.selectedMenu;
            });
            selectedMenuIndex < 0 && (selectedMenuIndex = 0);
            this._focusService.initFocus(selectedMenuIndex, 0);
            VoiceService.speak(this.getAriaLabel(this.selectedMenu));
        }, 100);
    }

    /**
     * preventDefault and stop Propagation
     * Prevent broadcast event to others listener outside this component
     * @param {KeyboardEvent} event
     */
    private onKeyPressed(event: KeyboardEvent) {
        event.preventDefault();
        event.stopImmediatePropagation();
    }

    /**
     * On menu item enter
     * Set selected menu
     * @param {KeyboardEvent} event
     * @param {string} item
     */
    private selectMenu(event: KeyboardEvent, item: string) {
        if (item !== this.selectedMenu) {
            this.onKeyPressed(event);
            this.selectedMenu = item;
            VoiceService.speak(this.getAriaLabel(item));
        }

    }

    /**
     * Handle back key pressed
     * Close setting panel
     */
    public onBackPressed() {
        if (this.onClosed instanceof Function) {
            this.onClosed().then(() => this._focusService.back());
        } else {
            this._focusService.back();
        }
    }

    /**
     * Open confirm dialog for logout action
     * Redirect to login page after logged-out
     * @param {KeyboardEvent} event
     */
    private openLogoutDialog(event: KeyboardEvent) {
        this.onKeyPressed(event);
        this._errorService.showDialog('Are you sure you want to logout?', 'OK', 'Cancel', this.onDialogConfirmed.bind(this));
    }
 
    onDialogConfirmed() {
        this._loginService.logout().then(() => {
            this.router.navigate(['/login'], {relativeTo: this.route});
        }, (error) => {
            LoggerService.logTrace(error);
            this._errorService.showError(ErrorMessages.APP_SERVER_CONNECTION_FAILURE);
        });
    }

    public getAriaLabel(item) {
        let content = item;
        if (item === SettingConstants.ALERTS) {
            content += (this._notificationService.isAlertOn ? ', on' : ', off') + ', On-screen notifications for instant highlights for touchdowns and big plays';
        }

        if (item === SettingConstants.FAQS) {
            content += ', For question and support, visit https://nflsthelp.directv.com/hc/en-us';
        }

        if (item === SettingConstants.DO_NOT_SELL_INFO) {
            content += ', To learn more about your privacy rights, please visit the link below from any web browser: ';
            content += this.config.doNotSellURL;
        }

        if (item === SettingConstants.ACCOUNT) {
            content += ',, ' + this.userInfo.pgwsSiteUserID;
            content += `,, App Version ${this.packageInfo.version}`;
        }

        return content;
    }

    /**
     * Toggles on and off alert showing
     *
     * @memberof SettingsComponent
     */
    public onOffClosedAlert(isTurnOn: boolean) {
        this._notificationService.isAlertOn = isTurnOn;
        if (isTurnOn) {
            VoiceService.speak("ON selected, OFF not selected");
        } else {
            VoiceService.speak("OFF selected, ON not selected");
        }
        // store alert setting to localStorage
    }
}
