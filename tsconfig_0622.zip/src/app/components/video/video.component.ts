import { ChangeDetectorRef, Component, ElementRef, ViewChild, Input } from '@angular/core';
import { BaseComponent } from '../../common/components/base.component';
import { FocusService, KeyboardService, LoadingService, TvInfoService } from '../../common/services';
import { IPlayerEvents } from '../../common/interfaces';
import { ErrorMessages, VideoConstants } from '../../common/constants';
import { PlayerService } from '../../services/player.service';
import { ApplicationService } from '../../services/application.service';
import { SubscriptionLike } from 'rxjs';
import * as _ from 'lodash';
import { VideoModel } from '../../models/video.model';
import { fadeInFadeOut } from '../../animations/show-hide.animations';
import { CarouselConstants } from '../../common/constants';
import { VoiceService } from '../../services/voice.service';
import { RaptorService } from '../../raptor.service';

@Component({
    selector: 'nfl-video',
    templateUrl: 'video.component.html',
    animations: [
        fadeInFadeOut
    ],
    styleUrls: ['./video.component.scss']
})

export class VideoComponent extends BaseComponent implements IPlayerEvents {

    keyboardEventBusName = 'video-control';
    @ViewChild('seekBar', { static: false })
    private seekBar: ElementRef;
    private ccStyles: object = {};
    private applicationSubscription: SubscriptionLike;
    private showVideoControls: boolean = false;
    private liveStreaming: boolean = false;
    private currentTimeInPercent: number = 0;
    private totalTime: number = 0;
    private currentTime: number = 0;
    private subtitleShowing: boolean = false;
    private messageVideoError: string = '';
    private isShowPopupVideoError: boolean = false;
    private playerState: string;
    private subtitle: string = '';
    private showingSubtitleTimeoutId: number = null;
    private videoType: string;
    private fastForwardPressCount = 0;
    private rewindPressCount = 0;
    private videoDescription: string = '';

    @Input()
    public onVideoControlClosed: () => void;

    /**
     *
     * @type {VideoConstants}
     */
    private readonly VideoConstants = VideoConstants;
    private readonly VoiceService = VoiceService;

    constructor(_keyboardService: KeyboardService,
        _focusService: FocusService,
        _changeDetectorRef: ChangeDetectorRef,
        private _loadingService: LoadingService,
        private _playerService: PlayerService,
        private _tvInfoService: TvInfoService,
        private _applicationService: ApplicationService,
        private _raptorService: RaptorService) {
        super(_keyboardService, _focusService, _changeDetectorRef);
    }

    ngAfterViewInit() {
        super.ngAfterViewInit();
        this.showVideoBackground();
        this._playerService.addListener(this);
        this.applicationSubscription = this._applicationService.on(this._applicationService.documentVisibilityEventName).subscribe(isHidden => {
            isHidden && this.stopVideoPlayBack();
        });
    }

    ngOnDestroy() {
        super.ngOnDestroy();
        this._playerService.removeListener(this);
        this._playerService.stop();
        this._playerService.destroy();
        this.applicationSubscription.unsubscribe();
        this._loadingService.removeAll();
    }

    /**
     * Toggle video play, pause
     *
     * @memberof VideoComponent
     */
    public togglePlay() {
        this.playerState === VideoConstants.VIDEO_PLAYING_STATUS ? this.pause() : this.play();
    }

    /**
     * Opens the video controls
     *
     * @memberof VideoComponent
     */
    public openControls() {
        if (!this.showVideoControls && !this.isShowPopupVideoError) {
            this.showVideoControls = true;
            // Why timeout here? we need to wait until elements displayed
            setTimeout(this.focusToVideoControl.bind(this), 100);
            this.closeControlsAfter();
            this.videoDescription = this._playerService.currentSource && this._playerService.currentSource.title.replace('vs', 'vs.').replace(CarouselConstants.GAMECHIP_FANTASY_NAME, 'Fantasy Zone').replace(CarouselConstants.GAMECHIP_REDZONE_NAME, 'Red Zone');
            // setTimeout(() => VoiceService.speak(this.videoDescription), 200);
        }
    }

    /**
     * Hides the video controls
     *
     * @memberof VideoComponent
     */
    public closeControls() {
        this.debounceClose.cancel();
        if (this.showVideoControls && this.fastForwardPressCount === 0) {
            this.showVideoControls = false;
            this._focusService.back();
        } else {
            this.closeControlsAfter();
        }
    }

    private debounceClose = _.debounce(() => {
        this.closeControls();
    }, 7000);

    /**
     * Automatically closes the video controls after 7 seconds
     *
     * @memberof VideoComponent
     */
    public closeControlsAfter() {
        this.debounceClose();
    }

    private onKeyPressed(event) {
        if (this.showVideoControls) {
            this.closeControlsAfter();
        }
    }

    public onUpPressed(event) {
        if (this.showVideoControls) {
            // Reset hide video control timeout
            this.closeControlsAfter();
        }
    }

    public onDownPressed(event) {
        if (this.showVideoControls) {
            // Reset hide video control timeout
            if (!event.focusEl) {
                this.closeControls();
            }
        }
    }

    public onLeftPressed(event) {
        if (!event.focusEl && this.showVideoControls) {
            if (this.seekBar && this._focusService.currentFocusEl === this.seekBar.nativeElement && !this.liveStreaming) {
                if (this.playerState === VideoConstants.VIDEO_PLAYING_STATUS) {
                    this._playerService.pause();
                }
                this.singleRewind(0);
            }
        }
    }

    public onRightPressed(event) {
        if (!event.focusEl && this.showVideoControls) {
            if (this.seekBar && this._focusService.currentFocusEl === this.seekBar.nativeElement && !this.liveStreaming) {
                if (this.playerState === VideoConstants.VIDEO_PLAYING_STATUS) {
                    this._playerService.pause();
                }
                this.singleFastForward(0);
            }
        }
    }

    private calculateSeekStep(): number {
        return this.videoType === VideoConstants.VIDEO_TYPE_GAMECHIP ? 15000 : 1000;
    }

    public onBackPressed(event) {
        if (!event.focusEl && this.showVideoControls) {
            this.closeControls();
        }
    }

    public onPlayPausePressed(event) {
        this.togglePlay();
    }

    public onPlayPressed(event) {
        this.play();
    }

    public onPausePressed(event) {
        this.pause();
    }

    public onStopPressed(event) {
        if (this.liveStreaming) {
            this.stopVideoPlayBack(true);
        }
    }

    public onFastForwardPressed(event) {
        if (!this.liveStreaming) {
            if (this.rewindPressCount > 0) {
                this.rewindPressCount = 0;
            }
            this.fastForwardPressCount++;
            if (this.fastForwardPressCount > 4) {
                this.fastForwardPressCount = 1;
            } else {
                this._playerService.pause();
                this.fastForward();
            }
        }
    }

    public onRewindPressed(event) {
        if (!this.liveStreaming) {
            if (this.fastForwardPressCount > 0) {
                this.fastForwardPressCount = 0;
            }
            this.rewindPressCount++;
            if (this.rewindPressCount > 4) {
                this.rewindPressCount = 1;
            } else {
                this._playerService.pause();
                this.rewind();
            }
        }
    }

    /**
     * Opens the video urls
     *
     * @param {(VideoModel | Array<VideoModel>)} urls
     * @memberof VideoComponent
     */
    public openVideo(video: VideoModel, videoType): Promise<any> {
        this._loadingService.push('player');
        this.videoType = videoType;
        // Reset error msg
        this.messageVideoError = '';
        return this._playerService.loadContent([video]);
    }

    private updateBufferedValue(): void {
        if (this.seekBar) {
            const self = this;
            const bufferedLength = self._playerService.buffered().length;
            const bufferedStart = bufferedLength ? self._playerService.buffered().start(0) : 0;
            const bufferedEnd = bufferedLength ? self._playerService.buffered().end(bufferedLength - 1) : 0;
            const seekRangeSize = self.seekBar.nativeElement.max - self.seekBar.nativeElement.min;

            const gradient = ['to right'];

            if (bufferedLength == 0) {
                gradient.push('#000 0%');
            } else {
                const clampedBufferStart = Math.max(bufferedStart, self.seekBar.nativeElement.min);
                const clampedBufferEnd = Math.min(bufferedEnd, self.seekBar.nativeElement.max);

                const bufferStartDistance = clampedBufferStart - self.seekBar.nativeElement.min;
                const bufferEndDistance = clampedBufferEnd - self.seekBar.nativeElement.min;
                const playheadDistance = this.currentTimeInPercent - self.seekBar.nativeElement.min;

                // NOTE: the fallback to zero eliminates NaN.
                const bufferStartFraction = (bufferStartDistance / seekRangeSize) || 0;
                const bufferEndFraction = (bufferEndDistance / seekRangeSize) || 0;
                const playheadFraction = (playheadDistance / seekRangeSize) || 0;

                gradient.push('#000 ' + (0) + '%');
                gradient.push('#ccc ' + (0) + '%');
                gradient.push('#ccc ' + (playheadFraction * 100) + '%');
                gradient.push('#444 ' + (playheadFraction * 100) + '%');
                gradient.push('#444 ' + (bufferEndFraction * 100) + '%');
                gradient.push('rgba(0, 0, 0, 0.4) ' + (bufferEndFraction * 100) + '%');
            }
            self.seekBar.nativeElement.style.background = 'linear-gradient(' + gradient.join(',') + ')';
        }

    }

    private updateWithoutBufferedValue(): void {
        if (this.seekBar) {
            const self = this;
            const seekRangeSize = self.seekBar.nativeElement.max - self.seekBar.nativeElement.min;
            const gradient = ['to right'];
            const playheadDistance = this.currentTimeInPercent - self.seekBar.nativeElement.min;
            const playheadFraction = (playheadDistance / seekRangeSize) || 0;

            gradient.push('#1fabe2 ' + (0) + '%');
            gradient.push('#1fabe2 ' + (0) + '%');
            gradient.push('#1fabe2 ' + (playheadFraction * 100) + '%');
            gradient.push('rgba(204, 204, 204, 0.8) ' + (playheadFraction * 100) + '%');
            self.seekBar.nativeElement.style.background = 'linear-gradient(' + gradient.join(',') + ')';
        }
    }

    private seek(seconds) {
        if (!this.liveStreaming) {
            this._playerService.seekTo(this.currentTime + seconds * 1000);
            VoiceService.speak(seconds > 0 ? 'fast forward' : 'rewind');
        }
    }

    private rewind() {
        if (!this.liveStreaming) {
            this.singleRewind(this.rewindPressCount);
            setTimeout(function () {
                if (this.rewindPressCount > 0) {
                    this.rewind();
                }
            }.bind(this), 1000);
        }
    }

    private singleRewind(rewindPressCount) {
        const speed = Math.pow(2, rewindPressCount);
        this.currentTime -= (this.calculateSeekStep() * speed);
        if (this.currentTime < 0) {
            this.currentTime = 0;
            this.rewindPressCount = 0;
        }
        this.currentTimeInPercent = ((this.currentTime / this.totalTime) * 100);
        VoiceService.speak('rewind');
    }

    private fastForward() {
        if (!this.liveStreaming) {
            this.singleFastForward(this.fastForwardPressCount);
            setTimeout(function () {
                if (this.fastForwardPressCount > 0) {
                    this.fastForward();
                }
            }.bind(this), 1000);
        }
    }

    private singleFastForward(fastForwardPressCount) {
        const speed = Math.pow(2, fastForwardPressCount);
        this.currentTime += (this.calculateSeekStep() * speed);
        if (this.currentTime > this.totalTime) {
            this.currentTime = this.totalTime;
            this.fastForwardPressCount = 0;
        }
        this.currentTimeInPercent = ((this.currentTime / this.totalTime) * 100);
        VoiceService.speak('fast forward');
    }

    private stopFastForwardIfNeeded() {
        this.fastForwardPressCount = 0;
        this.rewindPressCount = 0;
    }

    private play() {
        this.stopFastForwardIfNeeded();
        // if (this.playerState === VideoConstants.VIDEO_STOPPED_STATUS || this.playerState === VideoConstants.VIDEO_DESTROYED_STATUS) {
        //     this._playerService.loadContent();
        // } else {
        //     this._playerService.play();
        // }
        if (!this.liveStreaming) {
            if (Math.round(this.currentTime / 1000) != Math.round(this._playerService.currentTime / 1000)) {
                this._playerService.seekTo(this.currentTime);
            } else {
                this._playerService.play();
            }
            VoiceService.speak('playing at ' + this.timeToString(this.currentTime));
        }
    }

    private pause() {
        this.stopFastForwardIfNeeded();
        if (!this.liveStreaming) {
            this._playerService.pause();
            VoiceService.speak('paused at ' + this.timeToString(this.currentTime));
        }
    }

    public focusToVideoControl() {
        this.setFocus('.video-control .focusable', 1, 1);
    }

    private formatTime(miliseconds: number) {
        const seconds = miliseconds / 1000;
        const hh = Math.floor(seconds / 3600);
        const mm = Math.floor(seconds / 60) % 60;
        const ss = Math.floor(seconds) % 60;

        return (hh ? (hh < 10 ? '0' : '') + hh + ':' : '') +
            ((mm < 10) ? '0' : '') + mm + ':' +
            ((ss < 10) ? '0' : '') + ss;
    }

    private timeToString(miliseconds: number) {
        const seconds = miliseconds / 1000;
        const hh = Math.floor(seconds / 3600);
        const mm = Math.floor(seconds / 60) % 60;
        const ss = Math.floor(seconds) % 60;

        return (hh ? hh + ' hours ' : '') + (mm ? mm + ' minutes ' : '') + (ss ? ss + ' seconds ' : '');
    }

    public isControlsShowing(): boolean {
        return this.showVideoControls;
    }

    /**
     * Toggles on and off a video caption
     *
     * @memberof VideoComponent
     */
    public onOffClosedCaption() {
        this.subtitleShowing = !this.subtitleShowing;
        this._playerService.toggleCaption(this.subtitleShowing);
        if (this.subtitleShowing) {
            this.ccStyles = this._tvInfoService.getClosedCaptionStyles();
        }
    }

    /**
     * Stops playing a video and displays a video background
     *
     * @memberof VideoComponent
     */
    public stopVideoPlayBack(speak?: boolean) {
        if (speak) {
            VoiceService.speak('Stopped');
        }
        this._playerService.stop();
        this._loadingService.pop('player');
    }

    private resetVideoControl() {
        this.closeControls();
        this.currentTime = 0;
        this.currentTimeInPercent = 0;
        this.totalTime = 0;
        this.liveStreaming = this._playerService.isLiveStreaming;
        this.currentTimeInPercent = 100;
        this.updateWithoutBufferedValue();
        // this.showVideoControls && this._focusService.refresh();
    }

    public showVideoBackground() {
        if (!this.isShowPopupVideoError) {
            this.messageVideoError = '';
            this.isShowPopupVideoError = true;
            this._changeDetectorRef.detectChanges();
        }
    }

    public hideVideoBackground() {
        this.isShowPopupVideoError = false;
        this._changeDetectorRef.detectChanges();
    }

    public showMessageVideoError(message) {
        this.stopVideoPlayBack();
        this.messageVideoError = message;
        this.isShowPopupVideoError = true;
        this._changeDetectorRef.detectChanges();
        VoiceService.speak(message);
    }

    public isBackgroundShowing(): boolean {
        return this.isShowPopupVideoError;
    }

    // Implement methods

    onPlayerStateChange(state: string): void {
        this.playerState = state;
        if (state === VideoConstants.VIDEO_PLAYING_STATUS) {
            this.hideVideoBackground();
        } else if (state === VideoConstants.VIDEO_DESTROYED_STATUS || state === VideoConstants.VIDEO_STOPPED_STATUS) {
            this.stopFastForwardIfNeeded();
            this.resetVideoControl();
            this.showVideoBackground();
        }
        this._changeDetectorRef.detectChanges();
    }

    onBufferingStart(): void {
        this._loadingService.push('player');
    }

    onBufferingComplete(): void {
        this._loadingService.pop('player');
    }

    onBufferingProgress(): void {
    }

    onTimeUpdate(currentTime: number): void {
        this.liveStreaming = this._playerService.isLiveStreaming;
        if (!this.liveStreaming) {
            this.totalTime = (Math.round(this._playerService.totalTime / 1000)) * 1000;
            if (this.totalTime > 0) {
                this.currentTime = (Math.round(currentTime / 1000) * 1000);
                this.currentTimeInPercent = ((this.currentTime / this.totalTime) * 100);
                if (this._playerService.buffered()) {
                    this.updateBufferedValue();
                } else {
                    this.updateWithoutBufferedValue();
                }
            }
            this._changeDetectorRef.detectChanges();
        }
    }

    onSubtitleChange(duration: any, subtitles: any, $type: any, attriCount: any, attributes: any) {
        if (subtitles) {
            subtitles = subtitles.split(':')[0].split('line');
            if (subtitles.length > 1) {
                subtitles.pop();
            }
            subtitles = subtitles.join('');
        }
        this.subtitle = subtitles;
        this._changeDetectorRef.detectChanges();
        this.showingSubtitleTimeoutId && window.clearTimeout(this.showingSubtitleTimeoutId);
        this.showingSubtitleTimeoutId = window.setTimeout(() => {
            this.subtitle = '';
            this._changeDetectorRef.detectChanges();
        }, duration);
    }

    onEnded(): void {
        if (this.videoType === VideoConstants.VIDEO_TYPE_GAMECHIP) {
            this.showVideoBackground();
        }
    }

    onError($type: string, data): void {
        this._raptorService.cleanupSession({ isFatal: true, errorMsg: $type });
        this.showMessageVideoError(ErrorMessages.VIDEO_PLAYBACK_FAILURE);
        if (this.isControlsShowing()) {
            this.closeControls();
        }
        this._loadingService.pop('player');
    }

}
