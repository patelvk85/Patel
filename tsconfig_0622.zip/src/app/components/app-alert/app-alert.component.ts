import {Component, Input} from '@angular/core';
import {VideoModel} from '../../models/video.model';
import {AlertModel} from '../../models/alert.model';
import {LoggerService} from '../../common/services';
import {HighlightsComponent} from '..';
import {HighlightVideoModel} from '../../models/highlight.video.model';

@Component({
    selector: 'nfl-app-alert',
    templateUrl: './app-alert.component.html',
    styleUrls: ['./app-alert.component.scss']
})
export class AppAlertComponent {

    @Input()
    private onClose: (showNext) => void;
    private alert: AlertModel;
    private alertQueues = [];
    private alertTimeoutId;
    private alertTimeoutTime = 7000;
    private alertShowing: boolean = false;
    private alertShowingTime: number = +new Date();

    /**
     * Push alert to queue and open alert popup when it hidden
     * 
     * @param {any} alert 
     */
    public pushAlert(alert) {
        this.alertQueues.length === 10 && this.alertQueues.shift();
        this.alertQueues.push(alert);
        LoggerService.logTrace('Enqueue Number Alert in queue: ' + this.alertQueues.length);
    }
    
    public openAlert() {
        const currentTime = +new Date();
        if (this.alertQueues.length > 0 && !this.alertShowing && (currentTime - this.alertShowingTime >= (5000 + this.alertTimeoutTime)) ) {
            this.alertShowing = true;
            this.alertShowingTime = currentTime;
            this.alert = this.alertQueues.shift();
            LoggerService.logTrace('Dequeue Number Alert in queue: ' + this.alertQueues.length);
            this.alertTimeoutId = setTimeout(() => this.closeAlert(), this.alertTimeoutTime);
        } else {
            this.onClose(this.alertQueues.length > 0);
        }
    }

    public cancelAlert() {
        clearTimeout(this.alertTimeoutId);
        this.closeAlert();
    }

    public closeAlert() {
        this.alertShowing = false;
        this.onClose(this.alertQueues.length > 0);
    }

    public isAlertShowing() {
        return this.alertShowing;
    }

    public getHighLightVideo(alertType?: string): HighlightVideoModel {
        const video =  new HighlightVideoModel(this.alert.clip.id, this.alert.clip.title, this.alert.clip.url, null, null, alertType);
        return video;
    }
}
