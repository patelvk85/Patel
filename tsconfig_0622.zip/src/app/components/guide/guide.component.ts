import {Component} from '@angular/core';
import * as _ from 'lodash';
import {GuideService} from '../../common/services/guide.service';
import { GuideModel } from '../../models/guide.model';

@Component({
    selector: 'nfl-guide',
    templateUrl: 'guide.component.html',
    styleUrls: ['./guide.component.scss']
})
export class GuideComponent{

    keyboardEventBusName = 'guide';

    private guideShowing: boolean = false;
    private isChangingGuide: boolean = false;

    /**
     * User inactive in 7 seconds after show guide buttons
     * @type {number}
     */
    private acceptedTimeForGuideShowing = 7 * 1000;

    private guideButtons: Array<GuideModel> = [];

    constructor(private _guideService: GuideService) {
        this._guideService.on('showGuideButtons').subscribe((buttons: Array<GuideModel>) => {
            if (buttons.length > 0) {
                this.guideButtons = [];
                this.isChangingGuide = true;
                setTimeout(() => {
                    this.guideButtons = buttons;
                    const dismissButton = this.guideButtons.find(button => button.text === 'Dismiss');
                    if (dismissButton) {
                        this.debounceHideGuideButtons();
                    } else {
                        this.showGuideButtons();
                    }
                    this.isChangingGuide = false;
                }, 200);
            } else {
                this.hideGuideButtons();
            }
        });
    }

    /**
     * Fire Event to HomeComponent if user still inactive after show guide buttons
     * Hide guide buttons
     */
    public debounceHideGuideButtons = _.debounce(() => {
        this.hideGuideButtons();
    }, this.acceptedTimeForGuideShowing);

    public hideGuideButtons() {
        this.guideButtons = [];
        this.guideShowing = false;
        this.resetDebounce();
    }

    public showGuideButtons() {
        this.guideShowing = true;
        this.resetDebounce();
    }

    public resetDebounce() {
        this.debounceHideGuideButtons.cancel();
    }

    public getStatus(): boolean {
        return this.guideShowing;
    }

}
