import {ChangeDetectorRef, Component, ElementRef, ViewChild} from '@angular/core';
import {BaseComponent} from '../../common/components/base.component';
import {FocusService, KeyboardService, LoggerService} from '../../common/services/index';
import {ApplicationService} from '../../services/application.service';
import {EnvironmentService} from '../../common/services';
import {ActivatedRoute, Router} from '@angular/router';
import { VoiceService } from '../../services/voice.service';
import { AppUpdate } from '../../common/constants/constants';

@Component({
    selector: 'nfl-app-version',
    templateUrl: './app-version.component.html',
    styleUrls: ['./app-version.component.scss']
})
export class AppVersionComponent extends BaseComponent {

    @ViewChild('updateButton', {static: false})
    private updateButton: ElementRef;

    keyboardEventBusName = 'app-version';
    private readonly VoiceService = VoiceService;
    private readonly AppUpdate = AppUpdate;

    private backgroundShowing: boolean = false;
    private isShowAppVersion: boolean = false;
    private newVersion: string = '';

    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                _changeDetectorRef: ChangeDetectorRef,
                private router: Router,
                private route: ActivatedRoute,
                private _environmentService: EnvironmentService,
                private _applicationService: ApplicationService) {
        super(_keyboardService, _focusService, _changeDetectorRef);
    }

    ngAfterViewInit() {
        super.ngAfterViewInit();
        if(this._environmentService.config) {
            this.isShowAppVersion = true;
            this.newVersion = this._environmentService.config.minVersion;
            if (this.updateButton) {
                var content = AppUpdate.TITLE + ', Version ' + this.newVersion + ", " + AppUpdate.CONTENT;
                VoiceService.speakMsgAndFocusedElement(content, 
                    this.updateButton.nativeElement, this._focusService);
            }
            setTimeout(() => {
                this.setFocus('.version-background .focusable', 0, 1);
            }, 0);
        } else {
            this.router.navigate(['/'], {relativeTo: this.route});
        }
    }

    updateVersion() {
        this._applicationService.launchAppInTizenStore();
    }

    cancelUpdate() {
        this.backgroundShowing = true;
        VoiceService.speak("A newer version of this app is now available. Please install the latest version.");
        LoggerService.logTrace('cancel update!');
    }
}
