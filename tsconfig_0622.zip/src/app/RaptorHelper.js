"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var RaptorConstants = {
    playerState: {
        UNKNOWN_STATE: 0,
        PLAY: 1,
        PAUSE: 2,
        INTERRUPT: 3,
        STOP: 4,
        BUFFER_START: 6,
        BUFFER_COMPLETE: 7,
        SEEK_START: 8,
        SEEK_COMPLETE: 9,
        AD_START: 10,
        AD_END: 11,
        PLAYBACK_INIT: 12,
        PREPARING: 13
    },
    types: {
        platform: {
            DTVE_WEB: "DTVE Web",
            NFL_WEB: "NFL Web",
            NFL_TIZEN: "NFL Tizen",
            NFL_CHROMECAST: "NFL Chromecast"
        },
        stream: {
            LIVE: "Live",
            LIVE_RESTART: "Restart",
            VOD: "VOD",
            VOD_LOOKBACK: "Lookback",
            M_DVR_VOD: "InHouse-VOD",
            M_DVR_LIVE: "InHouse-Live",
            DOWNLOADED: "Downloaded",
            _UNKNOWN: "Unknown"
        },
        dai: {
            CSAI: "CSAI",
            SSAI: "SSAI"
        },
        serviceDomain: {
            DTVE: "DTVE",
            NFL: "NFLST",
            _UNKNOWN: "UNKNOWN"
        }
    },
    _types: {
        event: {
            BITRATE_CHANGE: "ACEHBBitrateChangeEvent",
            FRAMERATE_CHANGE: "ACEHBFramerateChange",
            STATE_CHANGE: "ACEHBStateChangeEvent",
            URL_CHANGE: "ACEHBURLChangeEvent",
            FATAL_ERROR: "ACEHBFatalError",
            DATA_SAMPLES: "ACEHBDataSamplesEvent",
            APP_BACKGROUND: "CwsAppBackgroundEvent",
            APP_FOREGROUND: "CwsAppForegroundEvent",
            SESSION_END: "CwsSessionEndEvent"
        },
        HEART_BEAT: "ACEHBSessionHb"
    }
};
var browserInfo = (function () {
    var ua = navigator.userAgent;
    var tem;
    var M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/)|edge?)\/?\s*(\d+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
        return {
            name: "Internet Explorer",
            version: tem[1] || ""
        };
    }
    if (M[1] === "Chrome") {
        tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
        if (tem != null) {
            return {
                name: tem[1].replace("OPR", "Opera"),
                version: tem[2]
            };
        }
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, "-?"];
    if ((tem = ua.match(/version\/(\d+)/i)) != null)
        M.splice(1, 1, tem[1]);
    return {
        name: M[0],
        version: M[1]
    };
})();
var RaptorHelper = (function () {
    function RaptorHelper(kinesisKeys) {
        this.kinesisKeys = kinesisKeys;
    }
    RaptorHelper.prototype.createRaptorInstance = function () {
        var raptorInstance = new RaptorImplementation(this.kinesisKeys);
        return raptorInstance;
    };
    return RaptorHelper;
}());
var RaptorImplementation = (function () {
    function RaptorImplementation(kinesisKeys) {
        this.eventSequenceNumber = 0;
        this.startSession(kinesisKeys);
    }
    RaptorImplementation.prototype.startSession = function (kinesisKeys) {
        this.eventSequenceNumber = 0;
        this.currentHeartbeat = this.createFirstSessionHeartBeat();
        var hearbeatInterval = kinesisKeys.heartbeatInterval ? kinesisKeys.heartbeatInterval : 20;
        this.heartBeatTimer = setInterval(this.sendHeartBeat.bind(this), hearbeatInterval * 1000);
        this.heartBeatSender = new HeartBeatSender(kinesisKeys);
    };
    RaptorImplementation.prototype.endSession = function () {
        this.pushEvent({ t: RaptorConstants._types.event.SESSION_END });
        this.sendHeartBeat();
        if (this.heartBeatTimer === undefined) {
            console.error("heartBeatTimer === undefined");
            return;
        }
        clearInterval(this.heartBeatTimer);
    };
    RaptorImplementation.prototype.report = function (data) {
        var _a;
        var event;
        var pht;
        var afps;
        if (this.phtCallback) {
            pht = this.phtCallback();
        }
        if (this.currentHeartbeat) {
            afps = this.currentHeartbeat.afps;
        }
        if (data.url !== undefined) {
            event = {
                old: { url: this.currentHeartbeat.url },
                "new": { url: data.url },
                t: RaptorConstants._types.event.URL_CHANGE
            };
        }
        if (data.br !== undefined) {
            event = {
                old: { br: this.currentHeartbeat.br },
                "new": { br: data.br },
                t: RaptorConstants._types.event.BITRATE_CHANGE
            };
        }
        if (data.afps !== undefined && data.afps != this.currentHeartbeat.afps) {
            event = {
                old: { afps: this.currentHeartbeat.afps },
                "new": { afps: data.afps },
                t: RaptorConstants._types.event.FRAMERATE_CHANGE
            };
        }
        if (data.ps != undefined) {
            event = {
                old: { ps: this.currentHeartbeat.ps },
                "new": __assign({ ps: (_a = data === null || data === void 0 ? void 0 : data.ps) !== null && _a !== void 0 ? _a : this.currentHeartbeat.ps }, data),
                t: RaptorConstants._types.event.STATE_CHANGE
            };
        }
        if (event) {
            if (pht || pht === 0)
                event["new"].pht = pht;
            if ((afps || afps === 0) && event.t != RaptorConstants._types.event.FRAMERATE_CHANGE)
                event["new"].afps = afps;
            this.pushEvent(event);
        }
        this.currentHeartbeat = __assign(__assign({}, this.currentHeartbeat), data);
    };
    RaptorImplementation.prototype.setContentInfo = function (data) {
        this.currentHeartbeat = __assign(__assign({}, this.currentHeartbeat), data);
    };
    RaptorImplementation.prototype.reportPlaybackFailed = function (error) {
        this.pushEvent({
            t: RaptorConstants._types.event.FATAL_ERROR,
            errorMsg: error.errorMsg,
            isFatal: error.isFatal,
            errorCode: error.errorCode
        });
    };
    RaptorImplementation.prototype.reportAdStarted = function (adData) {
        var ps = RaptorConstants.playerState.AD_START;
        this.pushEvent({
            old: { ps: this.currentHeartbeat.ps },
            "new": __assign({ ps: ps }, adData),
            t: RaptorConstants._types.event.STATE_CHANGE
        });
        this.currentHeartbeat.ps = ps;
    };
    RaptorImplementation.prototype.reportAdEnded = function () {
        var ps = RaptorConstants.playerState.AD_END;
        this.pushEvent({
            old: { ps: this.currentHeartbeat.ps },
            "new": { ps: ps },
            t: RaptorConstants._types.event.STATE_CHANGE
        });
        this.currentHeartbeat.ps = ps;
    };
    RaptorImplementation.prototype.createFirstSessionHeartBeat = function () {
        var numberOfSidCharacters = 12;
        var randomString = Math.floor(Math.random() * Math.pow(10, numberOfSidCharacters)).toString();
        var streamId = this.generateStreamId();
        var padding = "";
        for (var i = 0; i < numberOfSidCharacters - randomString.length; i++) {
            padding += "0";
        }
        var sid = padding + randomString;
        var UNKNOWN = "Unknown";
        var dm = browserInfo.name + " " + browserInfo.version;
        return {
            hbseq: 0,
            ps: RaptorConstants.playerState.UNKNOWN_STATE,
            sevs: [],
            st: 0,
            t: RaptorConstants._types.HEART_BEAT,
            lv: false,
            vid: "",
            strmt: RaptorConstants.types.stream._UNKNOWN,
            an: UNKNOWN,
            url: UNKNOWN,
            os: browserInfo.name,
            osVer: browserInfo.version,
            dm: dm,
            sst: Date.now(),
            streamID: streamId,
            sid: sid,
            serviceDomain: RaptorConstants.types.serviceDomain._UNKNOWN
        };
    };
    RaptorImplementation.prototype.generateStreamId = function () {
        var uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";
        return uuid.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    };
    RaptorImplementation.prototype.pushEvent = function (event) {
        this.currentHeartbeat.sevs.push(__assign(__assign({}, event), { sseq: this.eventSequenceNumber++, st: Date.now() - this.currentHeartbeat.sst }));
    };
    RaptorImplementation.prototype.setPhtCallback = function (callback) {
        this.phtCallback = callback;
    };
    RaptorImplementation.prototype.sendHeartBeat = function () {
        if (this.currentHeartbeat.sevs.length == 0) {
            this.pushEvent({ t: RaptorConstants._types.event.DATA_SAMPLES });
        }
        if (this.phtCallback) {
            this.currentHeartbeat.pht = this.phtCallback();
        }
        this.currentHeartbeat.st = Date.now() - this.currentHeartbeat.sst;
        this.heartBeatSender.sendWithRetries(this.currentHeartbeat);
        this.currentHeartbeat = __assign(__assign({}, this.currentHeartbeat), { hbseq: this.currentHeartbeat.hbseq + 1, sevs: [] });
    };
    return RaptorImplementation;
}());
var HeartBeatSender = (function () {
    function HeartBeatSender(kinesisKeys) {
        this.unsentHeartbeats = [];
        this.isPutRequestInProgress = false;
        this.kinesis = new AWS.Kinesis({
            region: kinesisKeys.region,
            credentials: {
                accessKeyId: kinesisKeys.accessKeyId,
                secretAccessKey: kinesisKeys.secretAccessKey
            }
        });
        this.streamName = kinesisKeys.streamName;
    }
    HeartBeatSender.prototype.sendWithRetries = function (heartBeat) {
        this.unsentHeartbeats.push(heartBeat);
        if (!this.isPutRequestInProgress) {
            this.putHeartbeatsWithRetry();
        }
    };
    HeartBeatSender.prototype.putHeartbeatsWithRetry = function () {
        var _this = this;
        this.kinesis.putRecords({
            Records: this.unsentHeartbeats.map(function (heartBeat) { return ({
                Data: JSON.stringify(heartBeat) + '\n',
                PartitionKey: "partition-" + heartBeat.vid + "-" + heartBeat.sid
            }); }),
            StreamName: this.streamName
        }, function (_, data) {
            var successfullySentIndexes = [];
            data.Records.forEach(function (record, index) {
                if (record.ErrorCode === undefined &&
                    record.ErrorMessage === undefined) {
                    successfullySentIndexes.push(index);
                }
            });
            _this.unsentHeartbeats = _this.unsentHeartbeats.filter(function (_, index) {
                var indexWasSuccessfullySent = false;
                for (var i = 0; i < successfullySentIndexes.length; i++) {
                    if (index === successfullySentIndexes[i]) {
                        indexWasSuccessfullySent = true;
                        break;
                    }
                }
                return !indexWasSuccessfullySent;
            });
            if (_this.unsentHeartbeats.length !== 0) {
                _this.putHeartbeatsWithRetry();
            }
            else {
                _this.isPutRequestInProgress = false;
            }
        });
        this.isPutRequestInProgress = true;
    };
    return HeartBeatSender;
}());
