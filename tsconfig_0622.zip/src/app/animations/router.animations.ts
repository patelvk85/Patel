import {trigger, animate, style, group, animateChild, query, stagger, transition} from '@angular/animations';

export const routerTransition = trigger('routerTransition', [
    transition('* <=> *', [
        group([
            query(
                ':enter',
                [
                    style({
                        opacity: 0,
                    }),
                    animate(
                        '0.35s cubic-bezi' +
                        'er(0, 1.8, 1, 1.8)',
                        style({ opacity: 1})
                    ),
                    animateChild()
                ],
                { optional: true }
            ),
            query(
                ':leave',
                [animate('0.35s', style({ opacity: 0 })), animateChild()],
                { optional: true }
            )
        ])
    ])
]);
