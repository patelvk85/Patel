import {trigger, animate, style, transition} from '@angular/animations';

export const fadeInFadeOut = trigger(
    'fadeInFadeOut', [
        transition(':enter', [
            style({opacity: 0}),
            animate('0.35s', style({opacity: 1}))
        ]),
        transition(':leave', [
            style({opacity: 1}),
            animate('0.35s', style({opacity: 0}))
        ])
    ]
);
