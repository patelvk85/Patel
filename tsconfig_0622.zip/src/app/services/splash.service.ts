import {Injectable} from '@angular/core';
import {EnvironmentService} from '../common/services';
import {JsonConvert, ValueCheckingMode} from 'json2typescript';
import {AdDetailsModel} from '../models/ad.details.model';
import { HttpClient } from '@angular/common/http';
import { map, retry, catchError } from 'rxjs/operators';
import { ToJsonService } from '../common/services/to-json.service';
import { throwError } from 'rxjs';
import { constants } from '../common/constants/constants';

@Injectable()
export class SplashService {

    constructor(private _httpClient: HttpClient,
                private _xml2JsonService: ToJsonService,
                private _environmentService: EnvironmentService) {
    }

    public getAdInformation(): Promise<any> {
        const url = this._environmentService.config.adUnitURL ? this._environmentService.config.adUnitURL.replace(/\[timestamp\]/g, (+new Date()).toString()) : '';
        return this._httpClient.get(url, {
            responseType: 'text', 
            withCredentials: true })
        .pipe(map((res) => {
            const jsonConvert: JsonConvert = new JsonConvert();
            let adInfo: AdDetailsModel = null;
            jsonConvert.valueCheckingMode = ValueCheckingMode.ALLOW_NULL;
            try {
                adInfo = jsonConvert.deserializeObject(this._xml2JsonService.getJson(res).ad, AdDetailsModel);
            } catch (e) {
                console.log(e.message);
                throwError(e);
            }
            return adInfo;
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }
}
