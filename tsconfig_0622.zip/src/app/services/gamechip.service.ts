import {Injectable} from '@angular/core';
import {NetworkService, UtilsService} from '../common/services';
import {LoginService} from './login.service';
import {JsonConvert, ValueCheckingMode} from 'json2typescript';
import {TeamInfo} from '../models/team-info.model';
import { HttpClient } from '@angular/common/http';
import { ToJsonService } from '../common/services/to-json.service';
import { map, retry, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { constants } from '../common/constants/constants';

@Injectable()
export class GamechipService {

    constructor(private _httpClient: HttpClient,
                private _toJsonService: ToJsonService,
                private _networkService: NetworkService,
                private _loginService: LoginService,
                private _utilsService: UtilsService) {
    }

    public getBatchGameAuthServiceUrl(): Promise<any> {
        const queryStr = '?' + this._utilsService.getQueryStr({
            platform: 'samsungTVTizen',
            source: this._networkService.getNetworkType(),
            device: this._loginService.deviceId,
        });
        return this._httpClient.get(this._loginService.userInfo.batchGameAuthServiceUrl + queryStr, {
            headers: { session: this._loginService.userInfo.sessionId },
            responseType: 'text', 
            withCredentials: true })
        .pipe(map((res) => {
                return this._toJsonService.getJson(res);
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    public getGamechipUrl(id): Promise<any> {
        const queryStr = '?' + this._utilsService.getQueryStr({
            gameId: id,
            platform: 'samsungTVTizen', // 'samsungTVTizen',
            streamtype: this._loginService.userInfo.streamType,
            device: this._loginService.deviceId,
            drm: false
        });
        return this._httpClient.get(this._loginService.userInfo.gameIdUrlServiceUrl + queryStr, {
            headers: { session: this._loginService.userInfo.sessionId },
            responseType: 'text', 
            withCredentials: true })
        .pipe(map((res) => {
                return this._toJsonService.getJson(res);
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    public getGameChips(): Promise<any> {
        return this._httpClient.get('data/fakescore1.json', {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json',
            },
            responseType: 'text', 
            withCredentials: true })
        .pipe(map((res) => {
                return this._toJsonService.getJson(res).config;
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    private fakeIndex: number = 1;

    public fakeGamechip(): Promise<any> {
        const config = {
            url: `data/fakescore1.json`,
            method: 'get'
        };

        return new Promise((resolve) => {
            const xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4) {
                    // Action to be performed when the document is read;
                    const data = JSON.parse(xhttp.response).Scores;
                    const gamechips = data.GameSnapShot;
                    gamechips.forEach(game => {
                        game.homeTeamCode = game.homeTeamClubCode;
                        game.awayTeamCode = game.awayTeamClubCode;
                        game.kickoffDate.GMT = game.kickoffDate._GMT;
                    });
                    resolve(data.GameSnapShot);
                }
            };
            xhttp.open('GET', config.url, true);
            xhttp.send();
        });
    }

    public fakeScore(): Promise<any> {
        const config = {
            url: `data/fakescore${this.fakeIndex}.json`,
            method: 'get'
        };
        this.fakeIndex++;
        if (this.fakeIndex > 22) {
            this.fakeIndex = 1;
        }

        return new Promise((resolve) => {
            const xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4) {
                    // Action to be performed when the document is read;
                    const data = JSON.parse(xhttp.response).Scores;
                    data.GameSnapShot.forEach(game => {
                        game.homeTeamCode = game.homeTeamClubCode;
                        game.awayTeamCode = game.awayTeamClubCode;
                        game.kickoffDate.GMT = game.kickoffDate._GMT;
                    });
                    data.refresh = 2;
                    resolve(data);
                }
            };
            xhttp.open('GET', config.url, true);
            xhttp.send();
        });
    }

    public getGamechipScore(): Promise<any> {
        return this._httpClient.get(this._loginService.userInfo.scoreURL + '?mtoken=' + encodeURIComponent(this._loginService.userInfo.metaDataToken), {
            responseType: 'text', 
            withCredentials: true })
        .pipe(map((res) => {
                return this._toJsonService.getJson(res);
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    public getTeamInfo(): Promise<any> {
        return this._httpClient.get(this._loginService.userInfo.teamInfoUrl + '?mtoken=' + encodeURIComponent(this._loginService.userInfo.metaDataToken), {
            responseType: 'text', 
            withCredentials: true })
        .pipe(map((res) => {
                const response = this._toJsonService.getJson(res);
                const teamInfos: Array<TeamInfo> = [];
                response.TeamInfo.Conference.forEach(conference => {
                    conference.Division.forEach(division => {
                        division.Team.forEach(team => {
                            const jsonConvert: JsonConvert = new JsonConvert();
                            jsonConvert.valueCheckingMode = ValueCheckingMode.ALLOW_NULL;
                            try {
                                const teamInfo: TeamInfo = jsonConvert.deserializeObject(team, TeamInfo);
                                teamInfos.push(teamInfo);
                            } catch (e) {
                                console.log(e.message);
                                // reject(e);
                            }        
                        });
                    });
                });
                return teamInfos;
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }
}
