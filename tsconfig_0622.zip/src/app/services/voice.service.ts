import { Injectable } from '@angular/core';
import { FocusService } from '../common/services';

declare const webapis;

@Injectable()
export class VoiceService {

    public static isVoiceGuideOn(): boolean {
        return webapis && webapis.tvinfo && webapis.tvinfo.getMenuValue(webapis.tvinfo.TvInfoMenuKey.VOICE_GUIDE_KEY);
    }

    public static speak(text: string, listener?: { onStart?, onEnd?}) {
        listener = listener || {};
        listener.onEnd = listener.onEnd || (() => { });
        listener.onStart = listener.onStart || (() => { });
        if (VoiceService.isVoiceGuideOn()) {
            try {
                const synth = window.speechSynthesis;
                const ttsObject = new SpeechSynthesisUtterance(text);
                ttsObject.onend = listener.onEnd;
                ttsObject.onerror = listener.onEnd;
                ttsObject.onpause = listener.onEnd;
                ttsObject.onstart = listener.onStart;
                synth.cancel();
                synth.speak(ttsObject);
            } catch (e) {
                listener.onEnd(false);
            }
        } else {
            listener.onEnd(false);
        }
    }

    public static buttonSpeak(text: string) {
        if (text) {
            VoiceService.speak(text + " button");
        }
    }

    public static speakMsgAndFocusedElement(message: string, nativeElement: any, focusService: FocusService) {
        if (nativeElement && focusService) {
            nativeElement.onfocus = (event) => {
                nativeElement.onfocus = null;
                setTimeout(() => {
                    VoiceService.speak(message, {
                        onEnd: () => {
                            focusService.currentFocusEl === nativeElement && focusService.refresh();
                        }
                    });
                }, 200);
            };
        }
    }
}
