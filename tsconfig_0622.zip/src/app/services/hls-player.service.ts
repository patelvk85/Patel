import {Injectable} from '@angular/core';
import {TvInfoService} from '../common/services';
// const Hls = require('hls.js/dist/hls.js');
/*import * as Hls from 'hls.js/dist/hls.js';*/
import {IPlayer, IPlayerEvents} from '../common/interfaces';
import {ErrorMessages} from '../common/constants';

@Injectable()
export class HlsPlayerService  {
    /*private hls: Hls;

    private video: HTMLVideoElement;

    private delayPlayInSeekTimeoutId: number = null;
    private listeners: IPlayerEvents;

    public totalTime: number = 0;
    public isLiveStreaming: boolean = false;
    public currentTime: number = 0;
    private isSeeking: boolean = false;

    /!* public listeners: {
         MEDIA_ATTACHING?: (event, data) => void,
         MEDIA_ATTACHED?: (event, data) => void,
         MANIFEST_PARSED?: (event, data) => void,
         LEVEL_LOADED?: (event, data) => void
     };*!/

    constructor(private _tvInfoService: TvInfoService) {
        const config = {
            xhrSetup: (xhr, url) => {
                xhr.withCredentials = true; // do send cookies
            },
            enableWorker: true
           /!* enableSoftwareAES: true*!/
        };
        this.hls = new Hls(config);
    }

    init(videoElement: HTMLVideoElement, listeners: IPlayerEvents): void {
        this.attachMedia(videoElement);
        this.listeners = listeners;
    }

    loadContent(url: string): void {
        this.stop();
        this.destroy();
        this.hls = new Hls();
        this.attachMedia(this.video).then(() => {
            this.hls.loadSource(url);
        });
    }

    play(): void {

    }

    pause(): void {

    }

    seekTo(time: number): void {
        if (this.delayPlayInSeekTimeoutId) {
            clearTimeout(this.delayPlayInSeekTimeoutId);
        }
        time < 0 && (time = 0);
        time > this.totalTime && (time = this.totalTime);
        this.video.pause();
        this.isSeeking = true;
        this.currentTime = time;
        // this.fireEvent('oncurrentplaytime', [this.currentTime]);
        this.listeners.onTimeUpdate(this.currentTime);
        this.delayPlayInSeekTimeoutId = window.setTimeout(() => {
            this.video.currentTime = time;
            this.video.play();
            this.isSeeking = false;
        }, 1000);
    }

    buffered(): TimeRanges {
        return this.video.buffered;
    }

    paused(): boolean {
        return this.video.paused;
    }

    textTracks(): TextTrackList {
        return this.video.textTracks;
    }

    stop(): void {
        this.hls.stopLoad();
    }

    destroy(): void {
        this.hls.destroy();
    }

    private attachMedia(videoElement: HTMLVideoElement) {
        return new Promise((resolve, reject) => {
            this.video = videoElement;
            this.hls.attachMedia(videoElement);
            this.hls.on(Hls.Events.MEDIA_ATTACHED, () => {
                this.initListeners();
                resolve();
            });
        });

    }

    public detachMedia() {
        this.hls.detachMedia();
    }

    private initListeners() {
        this.hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
            this.video.play();
        });

        this.hls.on(Hls.Events.LEVEL_LOADED, (event, data) => {
            console.log('level loaded');
            this.totalTime = data.details.totalduration;
            this.isLiveStreaming = data.details.live;
        });

        this.hls.on(Hls.Events.ERROR, (event, data) => {
            console.log(data);
            switch (data.type) {
                case Hls.ErrorTypes.NETWORK_ERROR:
                    // try to recover network error
                    console.log('fatal network error encountered, try to recover');
                    this.hls.startLoad();
                    break;
                case Hls.ErrorTypes.MEDIA_ERROR:
                    console.log('fatal media error encountered, try to recover');
                    this.hls.recoverMediaError();
                    break;
                default:
                    // cannot recover
                    this.hls.destroy();
                    this.listeners.onError(ErrorMessages.VIDEO_PLAYBACK_FAILURE);
                    // this.fireEvent('onerror', [event, data]);
                    break;
            }
        });

        this.video.addEventListener('playing', () => {
            console.log('playing');
            this.listeners.onBufferingComplete();
        });

        this.video.addEventListener('seeking', () => {
            // this.fireEvent('seeking');
            console.log('seeking');
            this.listeners.onSeeking();
        });

        this.video.addEventListener('seekend', () => {
            // this.fireEvent('seekend');
            console.log('seekend');
            this.listeners.onSeekEnd();
        });

        this.video.addEventListener('ended', () => {
            this.listeners.onEnded();
        });

        this.video.addEventListener('timeupdate', () => {
            if (!this.isSeeking) {
                // this.fireEvent('oncurrentplaytime', [this.video.currentTime]);
                this.listeners.onTimeUpdate(this.video.currentTime);
            }
        });

        this.video.addEventListener('error', () => {
            // this.fireEvent('onerror');
            this.listeners.onError(ErrorMessages.VIDEO_PLAYBACK_FAILURE);
        });
    }

    // public seekTo(time) {
    //     if (this.delayPlayInSeekTimeoutId) {
    //         clearTimeout(this.delayPlayInSeekTimeoutId);
    //     }
    //     time < 0 && (time = 0);
    //     time > this.totalTime && (time = this.totalTime);
    //     this.video.pause();
    //     this.isSeeking = true;
    //     this.currentTime = time;
    //     this.fireEvent('oncurrentplaytime', [this.currentTime]);
    //     this.delayPlayInSeekTimeoutId = window.setTimeout(() => {
    //         this.video.currentTime = time;
    //         this.video.play();
    //         this.isSeeking = false;
    //     }, 1000);
    // }

    // public stop() {
    //     this.hls.stopLoad();
    //     this.hls.destroy();
    // }

    // public openUrl(url: string) {
    //     this.stop();
    //     this.hls.destroy();
    //     this.hls = new Hls();
    //     this.attachMedia(this.video).then(() => {
    //         this.hls.loadSource(url);
    //     });
    // }*/
}
