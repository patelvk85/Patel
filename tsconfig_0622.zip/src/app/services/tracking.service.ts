import {Injectable} from '@angular/core';
import {NetworkConstants, CarouselConstants} from '../common/constants';
import {LoginService} from './login.service';
import {LoggerService, NetworkService, EnvironmentService} from '../common/services';
import {TrackingConstants} from '../common/constants/tracking.constants';
import {GamechipModel} from '../models/gamechip.model';
import {HighlightVideoModel} from '../models/highlight.video.model';
import {VideoModel} from '../models/video.model';
import {VisitorModel} from '../models/visitor.model';

declare var AppMeasurement: any;

@Injectable()
export class TrackingService {

    private trackingSender = null;
    private isReady = false;
    public adobeConfig = {
        'measurement': {
            'account': 'dtvglobalvisitor',
            'rsID': 'dtvapptizenstprod',
            'trackingServer': 'metrics.directv.com',
            'ssl': false
        }
    };
    private packageInfo = require('../../../package.json');
    private keepAliveTimeout = 10 * 60 * 1000; // 10 minutes
    private videoKeepAliveProcessId = null;
    private osVersion = null;

    constructor(private _loginService: LoginService,
                private _networkService: NetworkService,
                private _environmentService: EnvironmentService) {
        this.osVersion = this.getDeviceVersion();
    }

    /**
     * Get the network type
     */
    private getNetworkType() {
        let networkTypeText = '';
        const type = this._networkService.getActiveConnectionType();

        switch (type) {
            case NetworkConstants.DISCONNECTED:
                networkTypeText = NetworkConstants.DISCONNECTED_TEXT;
                break;
            case NetworkConstants.WIFI:
                networkTypeText = NetworkConstants.WIFI_TEXT;
                break;
            case NetworkConstants.CELLULAR:
                networkTypeText = NetworkConstants.CELLULAR_TEXT;
                break;
            case NetworkConstants.ETHERNET:
                networkTypeText = NetworkConstants.ETHERNET_TEXT;
                break;
        }

        return networkTypeText;
    }

    /**
     * Get device version
     */
    private getDeviceVersion() {
        const webapis = window['webapis'] || {};
        const tizen = window['tizen'] || {};
        const version = tizen && tizen.systeminfo && tizen.systeminfo.getCapability('http://tizen.org/feature/platform.version');
        const modelCode = webapis && webapis.productinfo && webapis.productinfo.getRealModel();
        return [TrackingConstants.PLATFORM, modelCode, version].join('/');
    }

    /**
     * Init ominture icd sdk with configurations
     */
    public initTracking() {
        try {
            this.trackingSender = this.getAdobeAppMeasurement(this.adobeConfig) || {};
            this.isReady = true;
        } catch (error) {
            LoggerService.warnTrace('Failed to init Omniture App Measurement');
        }
    }

    /**
     * Initiate app measurement with configuration
     * @param adobeConfiguration
     */
    private getAdobeAppMeasurement(adobeConfiguration) {
        // if config has metricsPlatformAccount, that is updated config, then we use metricsAccount for account. If not, use hardcoded account
        const account = this._environmentService.config && this._environmentService.config.metricsPlatformAccount ? this._environmentService.config.metricsAccount : adobeConfiguration.measurement.account;
        const appMeasurement = new AppMeasurement();
        appMeasurement.account = account;
        appMeasurement.trackingServer =  (this._environmentService.isDev ? this._environmentService.config.metricsHost :  this._environmentService.config.metricsHostSecured) || adobeConfiguration.measurement.trackingServer;
        appMeasurement.ssl = !this._environmentService.isDev;
        appMeasurement.charSet = TrackingConstants.CHARSET;
        return appMeasurement;
    }

    /**
     * Start tracking after initiate the tracking data
     */
    private track() {
        this.trackingSender.track();
        window['track'] = this.trackingSender;
    }

    /**
     * Build common data for tracking
     * @param tracking
     */
    private commonContextData() {
        try {
            const visitor: VisitorModel = new VisitorModel();
            this.trackingSender.contextData['att.page.rsid'] = this._environmentService.config && this._environmentService.config.metricsPlatformAccount ? this._environmentService.config.metricsPlatformAccount : this.adobeConfig.measurement.rsID;
            this.trackingSender.contextData['att.device.platform'] = TrackingConstants.PLATFORM;
            this.trackingSender.contextData['att.device.devicename'] = TrackingConstants.DEVICE_NAME;
            this.trackingSender.contextData['att.device.osversion'] = this.osVersion;
            this.trackingSender.contextData['att.device.appid'] = this.packageInfo.version;
            this.trackingSender.contextData['att.device.networktype'] = this.getNetworkType();
            this.trackingSender.contextData['att.device.screenlayout'] = TrackingConstants.LANDSCAPE;
            this.trackingSender.contextData['att.media.playername'] = TrackingConstants.MY_PLAYERS;
            this._loginService.userInfo && this._loginService.userInfo.account && (this.trackingSender.contextData['att.visitor.account'] = this._loginService.userInfo.account);
            this.trackingSender.contextData['att.visitor.type'] = visitor.type;
            this.trackingSender.contextData['att.visitor.date'] = visitor.date;
            this.trackingSender.contextData['att.visitor.hour'] = visitor.hour;
            this.trackingSender.contextData['att.visitor.day'] = visitor.day;

            this.track();
            LoggerService.infoTrace(this.trackingSender.contextData);
        } catch (e) {
            LoggerService.logTrace(e);
        }

    }

    private getSubSections(subSections) {
        this.trackingSender.contextData['att.page.subsection1'] = subSections;
        this.trackingSender.contextData['att.page.subsection2'] = subSections;
        this.trackingSender.contextData['att.page.subsection3'] = subSections;
    }

    /**
     * 4.1 App Launch
     */
    public appLaunch() {
        try {
            const pageName = [TrackingConstants.MY_ACCOUNT, TrackingConstants.APP_LAUNCH].join(':');
            this.trackingSender.contextData = {
                ['att.page.name']: pageName,
                ['att.page.nflsection']: TrackingConstants.LOGIN,
                ['att.page.section']: TrackingConstants.MY_ACCOUNT
            };
            this.getSubSections(pageName);
            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 4.2 Login Form
     */
    public loginForm() {
        try {
            const pageName = [TrackingConstants.WHATSON, TrackingConstants.LOGIN_FORM].join(':');
            this.trackingSender.contextData = {
                ['att.page.name']: pageName,
                ['att.page.nflsection']: TrackingConstants.LOGIN,
                ['att.page.section']: TrackingConstants.WHATSON
            };
            this.getSubSections(pageName);
            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 4.3 Login success
     */
    public loginSuccess() {
        try {
            const pageName = [TrackingConstants.MY_ACCOUNT, TrackingConstants.LOGIN].join(':');
            this.trackingSender.contextData = {
                ['att.page.name']: pageName,
                ['att.page.nflsection']: TrackingConstants.LOGIN,
                ['att.action.login']: true,
                ['att.action.logintype']: TrackingConstants.LOGIN_TYPE,
                ['att.device.nfltracking']: [TrackingConstants.LOGIN, TrackingConstants.BUTTON, TrackingConstants.LOGIN].join(':')
            };
            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 4.4 Login Error
     * @param errorCode Login failed with error code
     * @param errorMessage  Login failed with error message
     */
    public loginError(errorCode, errorMessage) {
        try {
            const pageName = [TrackingConstants.MY_ACCOUNT, TrackingConstants.LOGIN].join(':');
            this.trackingSender.contextData = {
                ['att.page.name']: pageName,
                ['att.page.nflsection']: TrackingConstants.LOGIN,
                ['att.page.messagekeynotification']: true,
                ['att.page.messagetype']: errorCode,
                ['att.page.messagekey']: errorMessage,
                ['att.action.loginerror']: true,
                ['att.action.logintype']: 'ET',
                ['att.device.nfltracking']: [TrackingConstants.LOGIN, TrackingConstants.BUTTON, TrackingConstants.LOGIN].join(':')
            };
            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 9.1 Red Zone channel on page load (If applicable)
     * 9.5 Fantasy Zone channel on page load
     * @param gameId gamechip Id
     * @param messageKey User message string
     * @param teamsName away team vs home team
     */
    public channelOnPageLoad(gameId: string, messageKey?: string, teamsName?: string) {
        try {
            let channelName = '';
            let pageName = '';
            if (gameId === CarouselConstants.GAMECHIP_FANTASY_ID) {
                channelName = TrackingConstants.FTC;
            } else if (gameId === CarouselConstants.GAMECHIP_REDZONE_ID) {
                channelName = TrackingConstants.RZC;
            }
            pageName = [TrackingConstants.WHATSON, channelName].join(':');

            this.trackingSender.contextData = {
                ['att.page.name']: pageName,
                ['att.page.nflsection']: channelName,
                ['att.page.section']: TrackingConstants.WHATSON,
                ['att.page.messagekey']: messageKey || ''
            };

            if (channelName === TrackingConstants.RZC) {
                this.trackingSender.contextData['att.media.game'] = teamsName;
            }

            this.getSubSections(pageName);
            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 9.2 Red zone channel on click
     * 9.3 Fantasy zone channel on click
     * 9.4 Gamechip on click
     * @param gamechip GamechipModel
     * @param teamsName away team vs home team
     */
    public channelOnClickInstances(gamechip: GamechipModel) {
        try {
            let channelName = TrackingConstants.PLAY_LIST;
            let pageName = null;
            let teamsName = null;
            if (gamechip.gameId === CarouselConstants.GAMECHIP_FANTASY_ID) {
                channelName = TrackingConstants.FTC;
                pageName = [TrackingConstants.WHATSON, channelName].join(':');
            } else if (gamechip.gameId === CarouselConstants.GAMECHIP_REDZONE_ID) {
                channelName = TrackingConstants.RZC;
                pageName = [TrackingConstants.WHATSON, channelName].join(':');
            } else {
                teamsName = [gamechip.awayTeamCode, ' vs ', gamechip.homeTeamCode].join('');
                channelName = teamsName;
                pageName = [TrackingConstants.WHATSON, TrackingConstants.PLAY_LIST].join(':');
            }

            this.trackingSender.contextData = {
                ['att.page.name']: pageName,
                ['att.page.nflsection']: teamsName ? TrackingConstants.PLAY_LIST : channelName,
                ['att.page.section']: TrackingConstants.WHATSON,
                ['att.device.nfltracking']: [TrackingConstants.PLAY_LIST, TrackingConstants.CHIP, channelName].join(':'),
                ['att.media.clickinstances']: true,
                ['att.media.game']: channelName
            };

            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 10.1 Highlight clip on click
     * @param highlightVideo HighlightVideoModel
     */
    public highlightSelection(highlightVideo: HighlightVideoModel) {
        try {
            if (highlightVideo instanceof HighlightVideoModel) {
                const pageName = [TrackingConstants.WHATSON, TrackingConstants.HIGHLIGHTS].join(':');
                this.trackingSender.contextData = {
                    ['att.page.name']: pageName,
                    ['att.page.nflsection']: TrackingConstants.HIGHLIGHTS,
                    ['att.page.section']: TrackingConstants.WHATSON,
                    ['att.device.nfltracking']: [TrackingConstants.HIGHLIGHTS, TrackingConstants.SELECTION, highlightVideo.title].join(':'),
                    ['att.media.clickinstances']: true,
                    ['att.media.game']: highlightVideo.teamsName
                };

                this.commonContextData();
            }
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 5.1 Omniture Keep Alive
     */
    public videoKeepAlive() {
        try {
            this.videoKeepAliveProcessId && this.clearVideoKeepAliveTimeout();
            this.keepAlive();
            this.videoKeepAliveProcessId = window.setInterval(() => {
                this.keepAlive();
            }, this.keepAliveTimeout);
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    private keepAlive() {
        const visitor: VisitorModel = new VisitorModel();
        this.trackingSender.contextData = {};
        this.trackingSender.contextData['att.visitor.account'] = this._loginService.userInfo && this._loginService.userInfo.account;
        this.trackingSender.contextData['att.visitor.date'] = visitor.date;
        this.track();
        LoggerService.infoTrace(this.trackingSender.contextData);
    }

    public clearVideoKeepAliveTimeout() {
        window.clearInterval(this.videoKeepAliveProcessId)
    }

    /**
     * 5.2 Video streaming errors
     */
    public videoStreamingError(video: VideoModel) {
        try {
            let channelName = '';
            const gameId = video instanceof HighlightVideoModel ? video.gameId : video.id;
            const liveClipId = !video.isLive && video instanceof HighlightVideoModel ? video.id : null;

            if (video.id === CarouselConstants.GAMECHIP_FANTASY_ID) {
                channelName = TrackingConstants.FTC;
            } else if (video.id === CarouselConstants.GAMECHIP_REDZONE_ID) {
                channelName = TrackingConstants.RZC;
            } else {
                channelName = TrackingConstants.PLAY_LIST;
            }

            const pageName = [TrackingConstants.WHATSON, channelName].join(':');
            this.trackingSender.contextData = {
                ['att.page.name']: pageName,
                ['att.page.messagekeynotification']: true,
                ['att.page.messagetype']: TrackingConstants.STREAM_ERROR,
                ['att.page.messagekey']: null,
                ['att.media.game']: gameId,
                ['att.media.payloadid']: null,
                ['att.media.liveclipid']: liveClipId
            };

            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 7.1 Live streaming - Start event (RZC, Fantasy and Live Streams, Companion)
     * 8.2 Highlight video streaming: Start event
     * 8.5 Shotcut video: Start event
     * @param video VideoModel
     */
    public videoStartEvent(video: VideoModel) {
        try {
            let content = '';
            let segment = '';
            const location = video instanceof HighlightVideoModel ? TrackingConstants.HIGHLIGHTS : TrackingConstants.HOMEPAGE;
            const gameId = video instanceof HighlightVideoModel ? video.gameId : video.id;
            const liveClipId = !video.isLive && video instanceof HighlightVideoModel ? video.id : null;

            if (video instanceof HighlightVideoModel) {
                content = TrackingConstants.STREAM_HIGHLIGHT_CONTENT;
                segment = video.alertType ? '0:A:0-25' : '0:H:0-25';
            } else if (video.isLive) {
                content = TrackingConstants.STREAM_CONTENT;
                segment = '0:L:0-10';
            } else {
                content = TrackingConstants.STREAM_SHORTCUT_CONTENT;
                segment = '0:S:0-25';
            }

            this.trackingSender.contextData = {
                ['att.media.view']: true,
                ['att.media.location']: location,
                ['att.media.content']: content,
                ['att.media.playername']: TrackingConstants.MY_PLAYERS,
                ['att.device.videosegment']: segment,
                ['att.media.name']: gameId,
                ['att.media.liveclipid']: liveClipId
            };

            if (video.isLive) {
                this.trackingSender.contextData['att.media.livestreamstart'] = true;
            } else {
                this.trackingSender.contextData['att.media.highlightalert'] = true;
            }

            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 7.2 Live streaming - Stop event (RZC, Fantasy and Live Streams, Companion)
     * 8.3 Highlight video streaming: Stop event
     * 8.6 Shortcut video: Stop event
     * @param video VideoModel
     * @param timePlayed video time played in seconds
     */
    public videoStopEvent(video: VideoModel, timePlayed?: number) {
        try {
            let content = '';
            let segment = '';
            let timeplayedText = TrackingConstants.TIME_PLAYED_DEFAULT_TEXT;
            let isShortCut = false;
            const gameId = video instanceof HighlightVideoModel ? video.gameId : video.id;
            const liveClipId = !video.isLive && video instanceof HighlightVideoModel ? video.id : null;
            const location = video instanceof HighlightVideoModel ? TrackingConstants.HIGHLIGHT_LOCATION : TrackingConstants.HOMEPAGE;

            if (video instanceof HighlightVideoModel) {
                content = TrackingConstants.STREAM_HIGHLIGHT_STOP_EVENT_CONTENT;
                segment = video.alertType ? '0:A:95-100' : '0:H:95-100';
            } else if (video.isLive) {
                content = TrackingConstants.STREAM_CONTENT;
                segment = '1:L:0-Null';
            } else {
                content = TrackingConstants.STREAM_SHORTCUT_CONTENT;
                segment = '0:S:95-100';
                timeplayedText = TrackingConstants.TIME_PLAYED_SHORTCUT_TEXT;
                isShortCut = true;
            }

            this.trackingSender.contextData = {
                ['att.media.complete']: true,
                ['att.media.timeplayed']: timePlayed,
                ['att.media.location']: location,
                ['att.media.content']: content,
                ['att.media.playername']: TrackingConstants.MY_PLAYERS,
                ['att.device.videosegment']: segment,
                ['att.media.name']: gameId,
                ['att.media.liveclipid']: liveClipId
            };

            if (video.isLive) {
                this.trackingSender.contextData['att.media.livestreamstop'] = true;
            } else {
                this.trackingSender.contextData['att.media.highlightalert'] = true;
            }

            if (isShortCut) {
                this.trackingSender.contextData['att.media.videosegmentview'] = true;
            }

            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }

    /**
     * 7.3 Audio close caption - Task tracking (If applicable)
     * @param video VideoModel
     * @param isShow caption is on/off
     */
    public videoToggleCaption(video: VideoModel, isShow: boolean) {
        try {
            const gameId = video instanceof HighlightVideoModel ? video.gameId : video.id;
            const ccState = isShow ? TrackingConstants.CAPTION_ON : TrackingConstants.CAPTION_OFF;
            this.trackingSender.contextData = {
                ['att.page.name']: [TrackingConstants.NFL_CLOSE_CAPTION, ccState].join(' '),
                ['att.media.closedcaptioning']: true,
                ['att.media.name']: gameId,
                ['att.device.nfltracking']: TrackingConstants.HOMESCREEN_CLOSE_CAPTION
            };

            this.commonContextData();
        } catch (error) {
            LoggerService.logTrace(error);
        }
    }
}
