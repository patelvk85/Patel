import { Injectable } from '@angular/core';
import {
    AvplayService,
    TvInfoService,
    LoggerService,
    EnvironmentService,
    LoadingService
} from '../common/services';
import { BroadcasterService } from '../common/services/broadcaster.service';
import { IPlayer, IPlayerEvents } from '../common/interfaces';
import { LoginService } from './login.service';
import * as _ from 'lodash';
import { VideoModel } from '../models/video.model';
import { VideoConstants } from '../common/constants';
import { TrackingService } from './tracking.service';
import { RaptorService } from '../raptor.service';

declare const m3u8Parser;

@Injectable()
export class PlayerService extends BroadcasterService implements IPlayer {

    private listeners: Array<IPlayerEvents> = [];
    private isShowCaption: boolean = false;
    private currentVideoIndex: number = 0;
    private playListUrls: Array<VideoModel>;
    private playerState: string;
    private stopResolver: Function;
    private startTime: number;
    private bufferingTimeout: any;

    public currentSource: VideoModel = null;
    public totalTime: number = 0;
    public currentTime: number = 0;
    public isLiveStreaming: boolean = false;

    private listener = {
        onbufferingstart: () => {
            this.fireEvent('onBufferingStart');
        },
        onbufferingprogress: (percent) => {
            // this.fireEvent('onBufferingProgress', [percent]);
        },
        onbufferingcomplete: () => {
            this.fireEvent('onBufferingComplete');
        },
        onstreamcompleted: () => {
            this.fireEvent('onEnded');
        },
        oncurrentplaytime: (currentTime) => {
            this.fireEvent('onTimeUpdate', [currentTime]);
        },
        ondrmevent: (drmEvent, drmData) => {
            this.fireEvent('onDrmEvent', [drmEvent, drmData]);
        },
        onerror: (errorType) => {
            LoggerService.errorTrace(errorType);
            errorType !== 'PLAYER_ERROR_NOT_SUPPORTED_FORMAT' && this.fireEvent('onError', [errorType]);
        },
        onevent: ($type, data) => {
            LoggerService.debugTrace('onevent');
            LoggerService.debugTrace($type);
            LoggerService.debugTrace(data);
            if ($type === 'PLAYER_MSG_BITRATE_CHANGE') {
                setTimeout(this.onBitRateChanged.bind(this), 0);
            }
            this.fireEvent('onEvent', [$type, data]);
        },
        onsubtitlechange: (duration, subtitles, $type, attriCount, attributes) => {
            this.fireEvent('onSubtitleChange', [duration, subtitles, $type, attriCount, attributes]);
        }
    };

    constructor(private _avPlayService: AvplayService,
        private _tvInfoService: TvInfoService,
        private _loginService: LoginService,
        private _raptorService: RaptorService,
        private _trackingService: TrackingService,
        private _environmentService: EnvironmentService,
        private _loadingService: LoadingService) {
        super();
    }

    public init(videoElement: HTMLVideoElement): void {

    }

    private initListeners() {
        this._avPlayService.setListener(this.listener);
    }

    private fireEvent(event, params?) {
        this.listeners.forEach((listener: IPlayerEvents) => {
            listener[event] instanceof Function && listener[event].apply(listener, params);
        });
        this.broadcast(event, params);
        this[event] instanceof Function && this[event].apply(this, params);
    }

    /**
     * Adding callback methods for player information notifications
     *
     * @param {IPlayerEvents} listener
     */
    public addListener(listener: IPlayerEvents): void {
        this.listeners.push(listener);
    }

    /**
     * Removing callback methods for player information notifications
     *
     * @param {IPlayerEvents} listener
     */
    public removeListener(listener: IPlayerEvents): void {
        const index = this.listeners.findIndex((l: IPlayerEvents) => {
            return l === listener;
        });
        this.listeners.splice(index, 1);
    }

    /**
     * Get the current index of url which are playing in playlist.
     *
     * @returns {number}
     */
    public getCurrentVideoIndex(): number {
        return this.currentVideoIndex;
    }

    private loadVideo(): void {
        this.currentSource = this.playListUrls[this.currentVideoIndex];
        this.isLiveStreaming = this.currentSource.isLive;
        this._avPlayService.stop();
        this._avPlayService.close();
        this.currentTime = 0;
        this.updatePlayerState();
        this._avPlayService.open(this.currentSource.url); // http://dtvnfltest-nonndsee2-live.hls.adaptive.level3.net/NFL/10/000705/11/playlist.m3u8
        this._avPlayService.setStreamingProperty('ADAPTIVE_INFO', 'STARTBITRATE=AVERAGE');
        this._avPlayService.setStreamingProperty('COOKIE', `supercast=${this._loginService.userInfo.supercastCookie}`);
        this._avPlayService.setListener(this.listener);
        this._avPlayService.setDisplayRect(0, 0, 1920, 1080);
        this._raptorService.updateRaptorSession(this.currentSource.url, this.getCurrentTime.bind(this));
        this.initListeners();
        this._trackingService.highlightSelection(this.currentSource);
        this._avPlayService.prepareAsync();
    }

    /**
     * Instantiates the player object with a content URL as the input parameter.
     *
     * @param {(Array<string> | string)} url
     */
    public loadContent(videos: Array<VideoModel> = null): Promise<any> {
        this.clearBufferingTimeout();
        return new Promise((resolve) => {
            this.stopResolver = resolve;
            this.playListUrls = videos || [this.currentSource];
            this.currentVideoIndex = 0;
            this.loadVideo();
        });
    }

    private loadNextContent(): void {
        this.currentVideoIndex++;
        this.loadVideo();
    }

    /**
     * Starts stream playback, or resumes stream playback after pause.
     *
     */
    public play(bufferComplete = false): void {
        this._avPlayService.play();
        this.updatePlayerState(bufferComplete);
    }

    /**
     * Pauses playback. If this method is called successfully, current time updates are stopped.
     *
     */
    public pause(): void {
        this.clearBufferingTimeout();
        this._avPlayService.pause();
        this.updatePlayerState();
    }

    private debounceSeek = _.debounce((time) => {
        this._raptorService.seekStarted();
        LoggerService.debugTrace('Seek to ' + time);
        LoggerService.debugTrace('State' + this._avPlayService.getState());
        this._avPlayService.seekTo(time, () => {
            this._raptorService.seekEnded();
        });
    }, 1000);

    /**
     * Skips playback to a specific timestamp.
     *
     * @param {number} time Timestamp to skip to (milliseconds)
     */
    public seekTo(time: number): void {
        time < 0 && (time = 0);
        time > this.totalTime && (time = this.totalTime);
        this.pause();
        this.fireEvent('onTimeUpdate', [this.currentTime = time]);
        this.debounceSeek(time);
    }

    public buffered(): TimeRanges {
        return null;
    }

    /**
     * Pauses playback
     *
     * @returns {boolean}
     */
    public paused(): boolean {
        const state = this._avPlayService.getState();
        return state === VideoConstants.VIDEO_PAUSED_STATUS;
    }

    /**
     * Get all subtitle track of audio
     *
     * @returns {TextTrack[]}
     */
    public textTracks(): TextTrack[] {
        const totalTrackInfo = this._avPlayService.getTotalTrackInfo();
        const textTracks = [];
        for (let i = 0, length = totalTrackInfo.length; i < length; i++) {
            if (totalTrackInfo[i].type == 'TEXT') {
                textTracks.push(totalTrackInfo[i]);
            }
        }
        return textTracks;
    }

    public getCurrentTime() {
        return this.isLiveStreaming ? (new Date()).getTime() : this.currentTime;
    }

    /**
     * Get bitrate of video
     *
     */
    private trackingVideoBitRate(state: string) {
        if (state === 'READY') {
            const bitRate = this.getCurrentBitRate();
            this._raptorService.setBitRate((bitRate.videoRate + bitRate.audioRate) / 1000);
        }
    }

    private getCurrentBitRate(): { videoRate: number, audioRate: number } {
        const currentStreamInfo = this._avPlayService.getCurrentStreamInfo();
        if (currentStreamInfo) {
            try {
                const videoRate = JSON.parse(currentStreamInfo[0].extra_info).Bit_rate;
                const audioRate = JSON.parse(currentStreamInfo[1].extra_info).bit_rate;
                return { videoRate: parseInt(videoRate), audioRate: parseInt(audioRate) };
            } catch (e) {

            }
        }
        return { videoRate: 0, audioRate: 0 };
    }

    private onBitRateChanged() {
        this.getCurrentHlsPlaylist().then((manifest: any) => {
            try {
                const currentBitRate = this.getCurrentBitRate().videoRate;
                if (currentBitRate && manifest) {
                    let currentFps = null;
                    manifest.playlists.forEach((playlist: any) => {
                        if (playlist.attributes.BANDWIDTH === currentBitRate) {
                            currentFps = playlist.attributes['FRAME-RATE'];
                        }
                    });
                    if (currentFps) {
                        this._raptorService.updateFps(currentFps);
                    }
                }
            } catch (e) {

            }
        });
    };

    private getCurrentHlsPlaylist() {
        return new Promise(resolve => {
            const req = new XMLHttpRequest();
            req.addEventListener('load', () => {
                const parser = new m3u8Parser.Parser();
                parser.push(req.responseText);
                parser.end();
                resolve(parser.manifest);
            });
            req.open('GET', this.currentSource.url, true);
            req.send();
        });
    }

    /**
     * Stops the player. Call this function after the video finishes playing.
     *
     */
    public stop(): void {
        this.clearBufferingTimeout();
        this._avPlayService.stop();
        this.destroy();
        this.updatePlayerState();
        this.fireEvent('onEnded', [true]);
        this._raptorService.cleanupSession();
    }

    /**
     * Destroys the player object.
     *
     */
    public destroy(): void {
        this.clearBufferingTimeout();
        this._avPlayService.close();
        this.updatePlayerState();
        this._raptorService.cleanupSession();
    }

    /**
     * Switches on or off for showing close caption
     *
     * @param {any} isShow
     */
    public toggleCaption(isShow) {
        this._tvInfoService.registerInAppCaptionControl(true);
        this._tvInfoService.showCaption(isShow);
        this.isShowCaption = isShow;
        this._trackingService.videoToggleCaption(this.currentSource, isShow);
    }

    private onBufferingStart() {
        this._raptorService.reportBufferingState(true);
        this.updatePlayerState();
        if (this._environmentService.config.bufferingTimeOutEnabled == 'true') {
            this.bufferingTimeout = setTimeout(() => {
                this.stop();
                clearTimeout(this.bufferingTimeout);
            }, 30000);
        }
    }

    private onBufferingComplete() {
        this.clearBufferingTimeout();
        this._raptorService.reportBufferingState();
        // ON TV 2016 player state is not updated immediately
        setTimeout(function () {
            this.play(true);
            this.isLiveStreaming = this._avPlayService.getStreamingProperty('IS_LIVE') == '1';
            this.totalTime = this._avPlayService.getDuration();
            this.toggleCaption(this.isShowCaption);
            this.updatePlayerState();
            this._trackingService.videoStartEvent(this.currentSource);
            this._raptorService.reportDuration(this.totalTime, this.isLiveStreaming);
        }.bind(this), 1000);

        this.startTime = +new Date();

    }

    private clearBufferingTimeout() {
        if (this.bufferingTimeout) {
            this._loadingService.pop('player');
            window.clearTimeout(this.bufferingTimeout);
            this.bufferingTimeout = null;
        }
    }

    private onTimeUpdate(currentTime) {
        if (!this.isLiveStreaming) {
            this.totalTime = this._avPlayService.getDuration();
            this.currentTime = currentTime;
        } else {
            this.currentTime = +new Date() - this.startTime;
        }
        return true;
    }

    private updatePlayerState(bufferComplete = false) {
        const state = this._avPlayService.getState();
        LoggerService.debugTrace('State :' + state);
        if (this.playerState !== state) {
            this.playerState = state;
            this.trackingVideoBitRate(this.playerState);
            this._raptorService.onPlayerStateChange(state, this.getCurrentTime());
            this.fireEvent('onPlayerStateChange', [state]);
        } else if (this.playerState == VideoConstants.VIDEO_PLAYING_STATUS && bufferComplete) {
            this._raptorService.onPlayerStateChange(this.playerState, this.getCurrentTime());
        }
    }

    private onEnded(isForce = false) {
        this.clearBufferingTimeout();
        this.updatePlayerState();
        if (!isForce && this.playListUrls instanceof Array && this.currentVideoIndex < this.playListUrls.length - 1) {
            this.loadNextContent();
        } else if (this.stopResolver instanceof Function) {
            this.stopResolver(isForce);
            this.stopResolver = null;
            this.currentSource && this._trackingService.videoStopEvent(this.currentSource, Math.round(this.currentTime / 1000));
        }

        this._raptorService.cleanupSession();
    }

    private onError(errorType) {
        this.clearBufferingTimeout();
        this.stop();
        this._trackingService.videoStreamingError(this.currentSource);
        this._raptorService.cleanupSession({ isFatal: true, errorMsg: errorType });
    }

}
