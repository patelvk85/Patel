import {Injectable} from '@angular/core';
import {VCNSService} from './vcns.service';
import {StompService, StompConfig} from '@stomp/ng2-stompjs';
import {BroadcasterService, LoggerService} from '../common/services';
import {Message} from '@stomp/stompjs';
import {AlertModel} from '../models/alert.model';
import * as SockJS from 'sockjs-client';
import {JsonConvert, ValueCheckingMode} from 'json2typescript';
import {Subscription} from 'rxjs';

@Injectable()
export class NotificationService extends BroadcasterService {

    private alertModel: AlertModel;

    private _stompService: StompService;

    private errorSubscription: Subscription;
    private subscriptions: Array<Subscription> = [];

    private topics: Array<string> = [];

    public appAlertEventName = 'hightlight-notification';

    public HIGHLIGHT_EVENT_NAME: string = 'hightlight-notification';

    private alertSetting: string = localStorage.getItem('alertSetting');

    /**
     * default of alert setting mode is Turn on
     * if alert setting variable is null/undefined in localStorage, then set default value for it
     * @type {boolean}
     */
    public get isAlertOn(): boolean {
        this.alertSetting = localStorage.getItem('alertSetting');
        return (typeof this.alertSetting === 'undefined' || this.alertSetting === null) ? true : JSON.parse(this.alertSetting);
    }

    public set isAlertOn(isTurnOn: boolean) {
        localStorage.setItem('alertSetting', isTurnOn.toString());
    }

    constructor(private _VCNSService: VCNSService) {
        super();
    }

    /**
     *
     */
    private initServer() {
        this._VCNSService.getToken().then(data => {
            const config: StompConfig = this.fetchConfig(data);
            this._stompService = new StompService(config);
            // This Subject will trigger when an error occurs
            this.errorSubscription = this._stompService.errorSubject.subscribe((error) => {
                LoggerService.logTrace(`Stomp connection error: ${error}`);
                this.disconnectServer();
                // Reconnect server after 15 seconds
                setTimeout(() => {
                    this.initServer();
                }, 15000);
            });
            this.topics = data.subscriptions;
            this.getMessages();
        });
        window['test'] = (msg) => {
            this.broadcast(this.appAlertEventName, msg);
        };
    }

    /**
     * set config for Stomp server
     * @param token
     * @returns {StompConfig}
     */
    private fetchConfig(token: any): StompConfig {
        const stompConfig: StompConfig = {
            url: new SockJS('http://' + token.notification_server + '/stomp/'),

            // Headers
            headers: {
                login: token.user,
                passcode: token.pass
            },

            // Interval in milliseconds, set to 0 to disable
            heartbeat_in: 0, // Typical value 0 - disabled
            heartbeat_out: 20000, // Typical value 20000 - every 20 seconds

            // Wait in milliseconds before attempting auto reconnect
            // Set to 0 to disable
            // Typical value 5000 (5 seconds)
            reconnect_delay: 5000,

            // Will log diagnostics on console
            debug: false
        };
        return stompConfig;
    }

    private getMessages() {
        this.topics.forEach(topic => {
            const subscription = this._stompService
                .subscribe(topic)
                .subscribe((message: Message) => {
                    // Log it to the console
                    const jsonConvert: JsonConvert = new JsonConvert();
                    jsonConvert.valueCheckingMode = ValueCheckingMode.ALLOW_NULL;
                    jsonConvert.ignorePrimitiveChecks = true;
                    try {
                        const alert: AlertModel = jsonConvert.deserializeObject(JSON.parse(message.body), AlertModel);
                        LoggerService.logTrace('Alert from server: ' + alert.description);
                        this.broadcast(this.appAlertEventName, alert);
                    } catch (e) {
                        LoggerService.logTrace(e.message);
                    }
                });

            this.subscriptions.push(subscription);
        });
    }

    /**
     * reconnect to server
     */
    public connectServer() {
        if (!this._stompService) {
            this.initServer();
        } else if (this.subscriptions.length === 0) {
            this.getMessages();
        }
    }

    /**
     * terminate connection
     */
    public disconnectServer() {
        this.subscriptions.forEach(subscription => {
            if (!subscription.closed) {
                subscription.unsubscribe();
            }
        });
        this.subscriptions = [];
        this.errorSubscription.unsubscribe();
        this._stompService.disconnect();
    }
}
