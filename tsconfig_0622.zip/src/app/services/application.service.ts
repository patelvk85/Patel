import { Injectable } from '@angular/core';
import {
    BroadcasterService, EnvironmentService,
    TvInfoService
} from '../common/services';
import {
    TermsAndConditions,
    ApplicationConstants
} from '../common/constants';
import { LoginService } from './login.service';
import { LoggerService } from '../common/services';
import { Subject } from 'rxjs';
import { RaptorService } from '../raptor.service';

@Injectable()
export class ApplicationService extends BroadcasterService {

    private documentHiddenName: string = ApplicationConstants.DOCUMENT_VISIBILITY_DEFAULT_STATUS;
    private tizenApi: any = window['tizen'];
    private backgroundTime: number = Date.now();
    private acceptedTime = 4 * 60 * 60 * 1000;
    private bgServiceId = 'HZsMPwNnfh.service';
    private readonly MESG_PORT_NAME = 'FOREGROUND_APP_PORT';

    public isInAcceptedTime = true;
    public documentVisibilityEventName: string = ApplicationConstants.DOCUMENT_VISIBILITY_DEFAULT_EVENT;
    public isAppInBackground: boolean = false;
    public smartHubRequestEventName: string = 'onSmartHubRequest';
    public currentAppVersion: string = require('../../../package.json').version;

    private applicationPackageId = 'HZsMPwNnfh.TizenNFL';
    private appStoreUrl = 'tizenstore://ProductDetail/' + this.applicationPackageId;

    onForceLogout: Subject<any> = new Subject<any>();

    constructor(
        private _tvInfoService: TvInfoService,
        private _loginService: LoginService,
        private _raptorService: RaptorService,
        private _environmentService: EnvironmentService
    ) {
        super();
        // Init event document visibility listener
        document.addEventListener(this.documentVisibilityEventName, (event: KeyboardEvent) => {
            event.stopPropagation();
            event.stopImmediatePropagation();
            this.isAppInBackground = this.isAppHidden();
            this.backgroundTime = this.isAppInBackground ? Date.now() : this.backgroundTime;
            this.isInAcceptedTime = (Date.now() - this.backgroundTime) < this.acceptedTime;
            this._tvInfoService.registerInAppCaptionControl(!this.isAppInBackground);
            this.broadcast(this.documentVisibilityEventName, this.isAppInBackground);
        });
        window.addEventListener('appcontrol', this.onSmartHubRequest.bind(this));

        this._loginService.onSessionIssue.subscribe(issue => {
            this.onForceLogout.next(issue);

            var that = this;
            var timeout = Number.parseInt(this._environmentService.config.concurrencyOSDTimeout);
            timeout = timeout ? timeout * 1000 : 30000;
            setTimeout(function () {
                that.exitApplication();
            }, timeout);
        });
    }

    /**
     * Flag to check if app was fisrt launched
     *
     * @param {boolean} [isLaunched=false] (optional) use for marked that user was launched the app
     * @returns {boolean}
     */
    public checkFirstLaunch(isLaunched: boolean = false): boolean {
        isLaunched && localStorage.setItem(TermsAndConditions.IS_FIRST_LAUNCH, 'false');
        return !localStorage.getItem(TermsAndConditions.IS_FIRST_LAUNCH);
    }

    /**
     * Check existing tizen api
     * Exit tizen application
     */
    public exitApplication() {
        if (!!this.tizenApi) {
            let timeoutId;
            const afterLogoutFired = () => {
                clearTimeout(timeoutId);
                this._raptorService.cleanupSession();
                this.tizenApi.application.getCurrentApplication().exit();
            };
            this._loginService.shallowLogout().then(afterLogoutFired, afterLogoutFired);
            timeoutId = setTimeout(afterLogoutFired, 5000);
        }
    }

    /**
     * Check the app is running background
     *
     * @private
     * @returns {boolean}
     * @memberof ApplicationService
     */
    private isAppHidden(): boolean {
        if (typeof document.hidden !== 'undefined') { // Opera and Firefox
            this.documentHiddenName = ApplicationConstants.DOCUMENT_VISIBILITY_DEFAULT_STATUS;
            this.documentVisibilityEventName = ApplicationConstants.DOCUMENT_VISIBILITY_DEFAULT_EVENT;
        } else if (typeof document[ApplicationConstants.DOCUMENT_VISIBILITY_MS_STATUS] !== 'undefined') { // IE
            this.documentHiddenName = ApplicationConstants.DOCUMENT_VISIBILITY_MS_STATUS;
            this.documentVisibilityEventName = ApplicationConstants.DOCUMENT_VISIBILITY_MS_EVENT;
        } else if (typeof document[ApplicationConstants.DOCUMENT_VISIBILITY_WEBKIT_STATUS] !== 'undefined') { // Chrome
            this.documentHiddenName = ApplicationConstants.DOCUMENT_VISIBILITY_WEBKIT_STATUS;
            this.documentVisibilityEventName = ApplicationConstants.DOCUMENT_VISIBILITY_WEBKIT_EVENT;
        } else {
            return true; // the app is visible
        }

        return !!document[this.documentHiddenName];
    }

    public startBackgroundService(msg) {
        if (!!this.tizenApi) {
            const appControl = new this.tizenApi.ApplicationControl('http://tizen.org/appcontrol/operation/service');
            this.tizenApi.application.launchAppControl(appControl, this.bgServiceId, () => {
                // success callback
                LoggerService.logTrace('Launch Background Service success');
                setTimeout(this.sendMessageToBgService.bind(this, msg), 5000);
            }, (e) => {
                LoggerService.logTrace('Launch Background Service failed: ' + e);
            }
            );
        }

    }

    private sendMessageToBgService(msg) {
        if (!!this.tizenApi) {
            // Message data is a dictionary - {key, value} pair, not just any Object
            try {
                const remotePort = this.tizenApi.messageport.requestRemoteMessagePort(this.bgServiceId, this.MESG_PORT_NAME);
                const messageData = {
                    key: 'METADATA',
                    value: JSON.stringify(msg)
                };
                LoggerService.logTrace('sendMessage to bg service');
                remotePort.sendMessage([messageData]);
            } catch (e) {
                LoggerService.logTrace('sendMessage error ' + e.message);
            }
        }
    }

    public getAppLaunchData(): string {
        if (!!this.tizenApi) {
            const requestedAppControl = this.tizenApi.application.getCurrentApplication().getRequestedAppControl();
            let gameId;
            if (requestedAppControl) {
                const appControlData = requestedAppControl.appControl.data;
                for (let i = 0; i < appControlData.length; i++) {
                    if (appControlData[i].key == 'PAYLOAD') {
                        try {
                            const actionData = JSON.parse(appControlData[i].value[0]).values;
                            gameId = JSON.parse(actionData).gameId;
                            LoggerService.logTrace('Receive Game ID from requestedAppControl' + gameId);
                        } catch (e) {
                            LoggerService.logTrace('Error in parsing action data from requestedAppControl');
                            LoggerService.logTrace(e);
                        }
                    }
                }
            } else {
                LoggerService.logTrace('No req app control');
            }
            return gameId;
        } else {
            return '';
        }

    }

    private onSmartHubRequest() {
        const gameId = this.getAppLaunchData();
        if (gameId) {
            this.broadcast(this.smartHubRequestEventName, gameId);
        }
    }

    /**
     * Invoking a details page of an app in Tizen store
     */
    public launchAppInTizenStore() {
        LoggerService.logTrace('start update app version');
        const appControl = new this.tizenApi.ApplicationControl('http://tizen.org/appcontrol/operation/view', this.appStoreUrl, null, null, null);

        const storeId = 'org.volt.apps';

        try {
            this.tizenApi.application.launchAppControl(appControl, storeId,
                () => {
                    // success callback
                    LoggerService.logTrace('success');
                },
                (e) => {
                    // error callback
                    LoggerService.logTrace('failed: ' + e);
                    alert('AppControl Exception:' + e);
                }, null);
        } catch (exc) {
            LoggerService.logTrace('Failed to launch your app on appStore.');
            alert('AppControl Exception:' + exc.message);
        }
    }

    private isPositiveInteger(x) {
        return /^\d+$/.test(x);
    }

    /**
     * Check number is positive number
     * @param parts
     * @returns {boolean}
     */
    private validateParts(parts) {
        for (const i of parts) {
            if (!this.isPositiveInteger(i)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Compare two software version numbers (e.g. 1.7.1)
     * Returns:
     *
     *  0 if they're identical
     *  negative if v1 < v2
     *  positive if v1 > v2
     *  Nan if they in the wrong format
     *
     */
    public compareVersionNumbers(v1, v2): number {
        const v1parts = v1.split('.');
        const v2parts = v2.split('.');

        if (!this.validateParts(v1parts) || !this.validateParts(v2parts)) {
            return NaN;
        }

        for (let i = 0; i < v1parts.length; ++i) {
            if (v2parts.length === i) {
                return 1;
            }

            if (v1parts[i] === v2parts[i]) {
                continue;
            }
            if (v1parts[i] > v2parts[i]) {
                return 1;
            }
            return -1;
        }

        if (v1parts.length != v2parts.length) {
            return -1;
        }

        return 0;
    }

    public isNewUpdateAvailable(): boolean {
        return this.compareVersionNumbers(this._environmentService.config.minVersion, this.currentAppVersion) === 1;
    }
}
