import {Injectable} from '@angular/core';
import {LoggerService} from '../common/services';
import {LoginService} from './login.service';
import * as _ from 'lodash';
import {JsonConvert, ValueCheckingMode} from 'json2typescript';
import {GamechipHighlightModel} from '../models/vcns/gamechip.highlight.model';
import { HttpClient } from '@angular/common/http';
import { map, retry, catchError } from 'rxjs/operators';
import { ToJsonService } from '../common/services/to-json.service';
import { throwError } from 'rxjs';
import { constants } from '../common/constants/constants';

@Injectable()
export class VCNSService {

    private filterSpecHighlight: any = {
        type: 'ftb.nfl.pbp',
        categories: [
            {
                type: 'play',
                id: [
                    'fid_score_td',
                    'fid_score_td_pass',
                    'fid_score_td_rush',
                    'fid_score_xp_2pt',
                    'fid_score_fg_good',
                    'fid_off_great_pass',
                    'fid_off_great_rush',
                    'fid_def_great_safety',
                    'fid_def_great_interception',
                    'fid_def_great_blk_punt',
                    'fid_def_great_fumb_recovery'
                ]
            }
        ],
        contests: [
            {
                type: 'GAME',
                id: ''
            }
        ]
    };

    private filterSpecShortcut: any = {
        type: 'ftb.nfl.postgame',
        contests: [
            {
                type: 'GAME',
                id: ''
            }
        ]
    };

    private accessToken: string = '';
    private clientId: string = '';

    constructor(private _httpClient: HttpClient,
                private _toJsonService: ToJsonService,
                private _loginService: LoginService) {
    }

    public getToken(): Promise<any> {
        const body = 'sessionId=' + encodeURIComponent(this._loginService.userInfo.sessionId) + '&etoken=' + encodeURIComponent(this._loginService.userInfo.liveclipsEToken) + '&deviceId=' + this._loginService.deviceId;
        return this._httpClient.post(this._loginService.userInfo.liveclipsAuthUrl + '/auth/etoken', body, {
            headers: {
                'content-type': 'application/x-www-form-urlencoded'
            },
            responseType: 'json', 
            withCredentials: true })
        .pipe(
            map((response) => {
                this.accessToken = response['access_token'];
                this.clientId = response['client_id'];
                LoggerService.logTrace('test in getToken(): ' + response);
                return response;
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    public getHighlightContents(gameKey: string) {
        const filterSpec = _.clone(this.filterSpecHighlight);
        if (gameKey === '') {
            delete filterSpec.contests;
        } else {
            filterSpec.contests[0].id = gameKey;
        }
        const promise = this.executeApi(filterSpec);
        const returnPromise = new Promise((resolve, reject) => {
            promise.then(data => {
                const jsonConvert: JsonConvert = new JsonConvert();
                jsonConvert.valueCheckingMode = ValueCheckingMode.ALLOW_NULL;
                jsonConvert.ignorePrimitiveChecks = true;
                try {
                    const gamechipHighlight: GamechipHighlightModel = jsonConvert.deserializeObject(data, GamechipHighlightModel);
                    resolve(gamechipHighlight);
                } catch (e) {
                    LoggerService.logTrace(e.message);
                }
            }, err => {
                return reject(err);
            });
        });

        return returnPromise;
    }

    public getShortcutContents(gameKey: string) {
        const filterSpec = _.clone(this.filterSpecShortcut);
        filterSpec.contests[0].id = gameKey;
        return this.executeApi(filterSpec);
    }

    private async executeApi(filterSpec: string) {
        await this.getToken();

        const body = 'filter_spec=' + encodeURIComponent(JSON.stringify(filterSpec));
        return this._httpClient.post(this._loginService.userInfo.liveclipsAPIUrl + '/clips/filter/spec', body, {
            headers: {
                'Authorization': ['HMAC', this.accessToken, this.clientId].join(':'),
                'content-type': 'application/x-www-form-urlencoded'
            },
            responseType: 'text', 
            withCredentials: true })
        .pipe(
            map((res) => {
                return this._toJsonService.getJson(res);
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    public selectedHighlight: {
        gamechipId: string,
        destroyAfterView: boolean,
        highlightId: string
    } = null;
}
