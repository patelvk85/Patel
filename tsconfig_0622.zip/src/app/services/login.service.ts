import {Injectable} from '@angular/core';
import {EnvironmentService, NetworkService, BroadcasterService} from '../common/services';
import {ActivatedRoute, Router} from '@angular/router';
import {UserInfoModel} from '../common/models/user-info.model';
import {LoginConstants} from '../common/constants';
import {ProductInfoService} from '../common/services/product.info.service';
import {TvInfoService} from '../common/services/tvinfo.service';
import { HttpClient } from '@angular/common/http';
import { ToJsonService } from '../common/services/to-json.service';
import { map, retry, catchError } from 'rxjs/operators';
import { throwError, Subject } from 'rxjs';
import { constants } from '../common/constants/constants';
import { UtilsService } from '../common/services/utils.service';
import { reject } from 'core-js/es6/promise';

@Injectable()
export class LoginService extends BroadcasterService {

    private keepSessionAliveProcessId: number;
    // Session refresh interval in seconds
    private sessionInterval: number = 60;
    private LOCAL_STORAGE_CONSTANTS = {
        USERNAME: 'username',
        E_TOKEN: 'eToken',
        AUTO_LOGIN: 'autoLogin'
    };
    public userAuthenticateEventName = LoginConstants.USER_AUTH;
    public deviceId: string;
    public userInfo: UserInfoModel;
    onSessionIssue: Subject<any> = new Subject<any>();

    constructor(private _httpClient: HttpClient,
                private _toJsonService: ToJsonService,
                private _environmentService: EnvironmentService,
                private _networkService: NetworkService,
                private _tvInfoService: TvInfoService,
                private _productInfoService: ProductInfoService,
                private _activatedRoute: ActivatedRoute,
                private _router: Router,
                private _utilsService: UtilsService) {
        super();
    }

    private keepSessionAlive() {
        this.keepSessionAliveProcessId && clearTimeout(this.keepSessionAliveProcessId);
        this.keepSessionAliveProcessId = window.setTimeout(() => {
            this.refreshSession().then((result) => {
                if (result) {
                    if (result.status === 'failure') {
                        this.onSessionIssue.next(result.statusMessage);
                    } 

                    if (result.refresh) {
                        this.sessionInterval = Number(result.refresh);
                    }
                }
                this.keepSessionAlive();
            }).catch(err => this.keepSessionAlive());
        }, this.sessionInterval * 1000);
    }

    private refreshSession() {
        return this._httpClient.get(this.userInfo.sessionURL, {
            headers: { session: this.userInfo.sessionId },
            params: {
                device: this.deviceId
            },
            responseType: 'text', 
            withCredentials: true })
        .pipe(map((res) => {
                return this._toJsonService.getJson(res);
            }),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    public getSavedUserCredentials() {
        return {
            username: localStorage.getItem(this.LOCAL_STORAGE_CONSTANTS.USERNAME) && atob(localStorage.getItem(this.LOCAL_STORAGE_CONSTANTS.USERNAME)),
            eToken: localStorage.getItem(this.LOCAL_STORAGE_CONSTANTS.E_TOKEN)
        };
    }

    /**
     *  get type {MAX, BASIC} of Logged-in User
     * @returns {string}
     */
    public getLoggedInUserType(): string {
        let typeUser: string = '';
        if (this.userInfo && this.userInfo.authFeatures && this.userInfo.authFeatures.feature.indexOf('fantasy') !== -1 &&
            this.userInfo.authFeatures.feature.indexOf('redzone') !== -1) {
            typeUser = LoginConstants.MAX_USER;
        } else {
            typeUser = LoginConstants.BASIC_USER;
        }
        return typeUser;
    }

    public isRememberMe(): boolean {
        const autoLogin = localStorage.getItem(this.LOCAL_STORAGE_CONSTANTS.AUTO_LOGIN);
        let isRememberMe = true;
        if (autoLogin === 'true') {
            isRememberMe = true;
        } else if (autoLogin === 'false') {
            isRememberMe = false;
        }
        return isRememberMe;
    }

    public reLogin(username, eToken): Promise<any> {
        const body = this._utilsService.getQueryStr({
            u: username,
            e: eToken,
            site: this._environmentService.config.site,
            device: this._productInfoService.getDuid() || this._networkService.getMACAddress(),
        });
        return this._httpClient.post(this._environmentService.config.loginURL, body, {
            headers: { 
                ['X-UserAgent']: 'tizen;15AV_BD;1443',
                'content-type': 'application/x-www-form-urlencoded'
            },
            responseType: 'text', 
            withCredentials: true })
        .pipe(
            map((res) => {
                const response = this._toJsonService.getJson(res);
                if (response.account) {
                    this.onLoginSuccess(username, true, response);
                    return response;
                } else {
                    return reject(response);
                }
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    public silentLogin() {
        const savedUserCredentials = this.getSavedUserCredentials();
        if (savedUserCredentials.username && savedUserCredentials.eToken) {
            this.reLogin(savedUserCredentials.username, savedUserCredentials.eToken).then(null, error => {
                this._router.navigate(['/login'], {
                    relativeTo: this._activatedRoute,
                    queryParams: {
                        error: error.statusMessage || error.message
                    }
                });
            });
        } else {
            this._router.navigate(['/login'], {relativeTo: this._activatedRoute});
        }
    }

    private onLoginSuccess(username, isRememberMe, response) {
        this.deviceId = this._productInfoService.getDuid() || this._networkService.getMACAddress();
        this.userInfo = response;

        if (this._tvInfoService.isTizen2016() && this.userInfo.liveclipsAuthUrl) {
            this.userInfo.liveclipsAuthUrl = this.userInfo.liveclipsAuthUrl.replace('https', 'http');
        }

        if (isRememberMe) {
            localStorage.setItem(this.LOCAL_STORAGE_CONSTANTS.USERNAME, btoa(username));
            localStorage.setItem(this.LOCAL_STORAGE_CONSTANTS.E_TOKEN, response.customerEToken.toString());
            localStorage.setItem(this.LOCAL_STORAGE_CONSTANTS.AUTO_LOGIN, isRememberMe.toString());
        }
        this.keepSessionAlive();
        this.broadcast(this.userAuthenticateEventName, true);
    }

    public login(username: string, password: string, isRememberMe: boolean = false): Promise<any> {
        const body = '&u=' + encodeURIComponent(username) + '&p=' + encodeURIComponent(password) + '&site=' + encodeURIComponent(this._environmentService.config.site) + '&device=' + encodeURIComponent(this._productInfoService.getDuid() || this._networkService.getMACAddress());
        return this._httpClient.post(this._environmentService.config.loginURL, body, {
            headers: {
                ['X-UserAgent']: 'tizen;15AV_BD;1443',
                'content-type': 'application/x-www-form-urlencoded'
            },
            responseType: 'text', 
            withCredentials: true })
        .pipe(
            map((res) => {
                const response = this._toJsonService.getJson(res);
                if (response.account) {
                    this.onLoginSuccess(username, isRememberMe, response);
                    return response;
                } else {
                    return reject(response);
                }
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    /**
     * Logout without clear etoken
     * @returns {Promise<any>}
     */
    public shallowLogout() {
        return new Promise((resolve, reject) => {
            this.executeLogout().then((response) => {
                if (!this.isRememberMe()) {
                    localStorage.removeItem(this.LOCAL_STORAGE_CONSTANTS.USERNAME);
                }
                clearTimeout(this.keepSessionAliveProcessId);
                resolve(response);
                this.broadcast(this.userAuthenticateEventName, false);
            }, reject);
        });
    }

    private executeLogout() {
        return this._httpClient.get(this.userInfo['logoutURL'], {
            headers: { session: this.userInfo.sessionId },
            params: {
                device: this._productInfoService.getDuid() || this._networkService.getMACAddress()
            },
            responseType: 'text', 
            withCredentials: true })
        .pipe(
            map((response) => {
                return this._toJsonService.getJson(response);
            }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }

    public logout() {
        return new Promise((resolve) => {
            this.executeLogout().then((response) => {
                if (!this.isRememberMe()) {
                    localStorage.removeItem(this.LOCAL_STORAGE_CONSTANTS.USERNAME);
                }
                localStorage.removeItem(this.LOCAL_STORAGE_CONSTANTS.E_TOKEN);
                clearTimeout(this.keepSessionAliveProcessId);
                resolve(response);
                this.broadcast(this.userAuthenticateEventName, false);
            });
        });
    }

    public stopKeepSessionAlive() {
        clearTimeout(this.keepSessionAliveProcessId);
    }

    public toogleRememberMe(isRememberMe) {
        localStorage.setItem(this.LOCAL_STORAGE_CONSTANTS.AUTO_LOGIN, isRememberMe.toString());
    }

    public getPrivacyContent() {
        const config = {
            url: 'http://directv.com/NFLST/PrivacyPolicy',
            method: 'get'

        };
        return new Promise((resolve) => {
            const xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4) {
                    resolve(xhttp.response);
                }
            };
            xhttp.open('GET', config.url, true);
            xhttp.send();
        });
    }

    public getTermOfUseContent() {
        const config = {
            url: 'http://directv.com/NFLST/TermsofUse',
            method: 'get'

        };
        return new Promise((resolve) => {
            const xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4) {
                    resolve(xhttp.response);
                }
            };
            xhttp.open('GET', config.url, true);
            xhttp.send();
        });
    }
}
