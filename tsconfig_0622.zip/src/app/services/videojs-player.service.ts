import {Injectable} from '@angular/core';
import {IPlayer, IPlayerEvents} from '../common/interfaces';
import {BroadcasterService} from '../common/services/broadcaster.service';

import * as videojs from 'video.js/dist/video.js';
window['videojs'] = videojs;
import 'videojs-contrib-hls/dist/videojs-contrib-hls.js';
import * as playlist from 'videojs-playlist/dist/videojs-playlist.js';
import {VideoConstants} from '../common/constants';
// declare const videojs;

@Injectable()
export class VideoJsPlayerService extends BroadcasterService implements IPlayer {

    private player: any;
    private listeners: Array<IPlayerEvents> = [];
    private config = {
        controls: false,
        autoplay: true,
        loop: false,
        preload: 'false',
        html5: {
            hls: {
                withCredentials: true
            }
        }
    };
    private delayPlayInSeekTimeoutId: number = null;
    private isShowCaption: boolean = false;

    public totalTime: number = 0;
    public currentTime: number = 0;
    public isLiveStreaming: boolean = false;
    public isSeeking: boolean = false;
    public playerState: string;
    public currentSource;

    constructor() {
        super();
        videojs.options.hls.overrideNative = true;
        videojs.options.html5.nativeAudioTracks = false;
        videojs.options.html5.nativeVideoTracks = false;
        videojs.options.html5.nativeTextTracks = false;
        videojs.options.html5.useCueTags = true;
    }

    public init(videoElement: HTMLVideoElement): void {
        this.player = videojs(videoElement, this.config);
        this.player.playlist = playlist;
        this.player.isFullscreen(true);
        this.initListeners();
        // player config
        this.handleShowControl();
        this.handleFullScreenChange();
    }

    private initListeners() {
        const eventMappings = {
            loadstart: 'onBufferingProgress',
            loadedmetadata: 'onBufferingComplete',
            playing: 'onPlayerStateChange',
            play: 'onPlayerStateChange',
            pause: 'onPlayerStateChange',
            seeking: 'onSeeking',
            seeked: 'onSeekEnd',
            ended: 'onEnded',
            timeupdate: 'onTimeUpdate',
            error: 'onError'
        };

        for (const event of Object.keys(eventMappings)) {
            this.player.on(event, ($event, data) => {
                let canNotFireEvent = false;
                if (this[eventMappings[event]] instanceof Function) {
                    canNotFireEvent = this[eventMappings[event]](data, eventMappings[event]);
                }
                !canNotFireEvent && this.fireEvent(eventMappings[event], data);
            });
        }
    }

    private fireEvent(event, data?) {
        this.listeners.forEach((listener: IPlayerEvents) => {
            listener[event](data);
        });
        this.broadcast(event, data);
    }

    public addListener(listener: IPlayerEvents) {
        this.listeners.push(listener);
    }

    public removeListener(listener: IPlayerEvents) {
        const index = this.listeners.findIndex((l: IPlayerEvents) => {
            return l === listener;
        });
        this.listeners.splice(index, 1);
    }

    public getCurrentVideoIndex(): number {
        return this.player.playlist.currentIndex();
    }

    /*
    * TODO: Need to check the video type and set correct type to the player
    */
    public loadContent(urls: Array<string> | string): void {
        this.player.playlist([]);
        const playlist = [];
        const formatMapping = {
            mp4: 'video/mp4',
            m3u8: 'application/x-mpegURL'
        };
        if (typeof urls === 'string') {
            urls = [urls];
        }
        if (urls instanceof Array) {
            urls.forEach(url => {
                const ext = url.split('.').pop();
                playlist.push({
                    sources: [{
                        src: url,
                        type: formatMapping[ext]
                    }],
                });

            });
        }
        this.player.playlist(this.currentSource = playlist);
        this.player.playlist.autoadvance(0);
        this.player.playlist.repeat(false);
        window['player'] = this.player;
        this.currentSource = urls;
    }

    private onBufferingComplete() {
        const duration = this.player.duration();
        this.isLiveStreaming = duration === Infinity;
        this.totalTime = duration;
        this.toggleCaption(this.isShowCaption);
    }

    private onPlayerStateChange() {
        const paused = (this.player.paused() || (this.player.readyState() < 3 && this.player.readyState() > 0));
        this.playerState = paused ? VideoConstants.VIDEO_PAUSED_STATUS : VideoConstants.VIDEO_PLAYING_STATUS;
        (this.player.ended() || this.player.readyState() == 0) && (this.playerState = VideoConstants.VIDEO_STOPPED_STATUS);
        this.fireEvent('onPlayerStateChange', this.playerState);
        return true;
    }

    private onTimeUpdate(data) {
        const duration = this.player.duration();
        this.isLiveStreaming = duration === Infinity;
        this.fireEvent('onTimeUpdate', this.player.currentTime());
        return true;
    }

    private onSeeking() {
        this.isSeeking = true;
    }

    private onSeekEnd() {
        this.isSeeking = false;
    }

    private onEnded() {
        this.onPlayerStateChange();
    }

    public play(): void {
        if (this.playerState === VideoConstants.VIDEO_STOPPED_STATUS) {
            this.loadContent(this.currentSource);
        } else {
            this.player.play();
        }
    }

    public pause(): void {
        this.player.pause();
    }

    public seekTo(time: number): void {
        if (this.delayPlayInSeekTimeoutId) {
            window.clearTimeout(this.delayPlayInSeekTimeoutId);
        }
        time < 0 && (time = 0);
        time > this.totalTime && (time = this.totalTime);
        this.pause();
        this.isSeeking = true;
        this.fireEvent('onTimeUpdate', this.currentTime = time);
        this.delayPlayInSeekTimeoutId = window.setTimeout(() => {
            this.player.currentTime(time);
            this.play();
        }, 1000);
    }

    public buffered(): TimeRanges {
        return this.player.buffered();
    }

    public paused(): boolean {
        return this.player.paused();
    }

    public textTracks() {
        const textTracks = this.player.textTracks();
        const subtitles = [];
        for (let i = 0, length = textTracks.length; i < length; i++) {
            const track = textTracks[i];
            if (track.kind === VideoConstants.TRACK_KIND_CAPTIONS || track.kind === VideoConstants.TRACK_KIND_SUBTITLES) {
                subtitles.push(track);
            }
        }
        return subtitles;
    }

    public toggleCaption(isShow) {
        const subtitles = this.textTracks();
        subtitles.forEach((subtitle) => {
            subtitle.mode = VideoConstants.SUBTITLES_MODE_HIDDEN;
        });
        subtitles[0] && (subtitles[0].mode = isShow ? VideoConstants.SUBTITLES_MODE_SHOWING : VideoConstants.SUBTITLES_MODE_HIDDEN);
        this.isShowCaption = isShow;
    }

    public stop(): void {
        this.player.reset();
        this.onPlayerStateChange();
    }

    public destroy(): void {
        this.player.playlist([]);
    }

    private handleShowControl() {
        if (this.config.controls) {
            this.player.removeClass('vjs-controls-disabled');
            this.player.addClass('vjs-controls-enabled');
        } else {
            this.player.removeClass('vjs-controls-enabled');
            this.player.addClass('vjs-controls-disabled');
        }
    }

    private handleFullScreenChange() {
        if (this.player.isFullscreen()) {
            this.player.addClass('vjs-fullscreen');
        } else {
            this.player.removeClass('vjs-fullscreen');
        }
    }
}
