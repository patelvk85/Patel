import {JsonObject, JsonProperty} from 'json2typescript';
import {AdDetailsModel} from './ad.details.model';

@JsonObject('AdModel')
export class AdModel {
    
    @JsonProperty('contest', AdDetailsModel)
    ad: AdDetailsModel = null;

}
