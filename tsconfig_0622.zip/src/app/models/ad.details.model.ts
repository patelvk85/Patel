import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('AdDetailsModel')
export class AdDetailsModel {
    
    @JsonProperty('adURI')
    adUri: string = null;

    @JsonProperty('clickURI')
    clickUri: string = null;

    @JsonProperty('third_party_impressions')
    thirdPartyImpressions: string = null;

}
