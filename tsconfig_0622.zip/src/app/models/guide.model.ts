export class GuideModel {
    text: string = '';
    icon: string = '';
}
