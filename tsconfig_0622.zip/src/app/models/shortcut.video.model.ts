import {VideoModel} from './video.model';
import { REPORT_TITLE_SUFFIX } from '../common/constants/constants';

export class ShortcutVideoModel extends VideoModel {

    public get assetName() {
        return `[${this.id}] ${this.title} ${REPORT_TITLE_SUFFIX.SHORTCUT}`;
    }

    constructor(id: string, title: string, url: string) {
        super(id, title, false, url);
    }

}
