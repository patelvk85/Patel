import {CarouselConstants} from '../common/constants';
import {JsonObject, JsonProperty} from 'json2typescript';

const moment = require('moment');

@JsonObject('GamechipModel')
export class GamechipModel {

    @JsonProperty('gameId', String)
    gameId: string = null;

    @JsonProperty('gameKey', String)
    gameKey: string = null;

    /*   @JsonProperty('sourceDate', String)
       sourceDate: string = null;*/

    @JsonProperty('homeTeamCode', String)
    homeTeamCode: string = null;

    @JsonProperty('homeTeamName', String)
    homeTeamName: string = null;

    /*    @JsonProperty('homeTeamNFLTriCode', String)
        homeTeamNFLTriCode: string = null;*/

    @JsonProperty('homeTeamScore', Number, true)
    homeTeamScore: number = null;

    @JsonProperty('awayTeamScore', Number, true)
    awayTeamScore: number = null;

    @JsonProperty('awayTeamCode', String)
    awayTeamCode: string = null;

    @JsonProperty('awayTeamName', String)
    awayTeamName: string = null;

    awayName: string = null;
    homeName: string = null;

    /* @JsonProperty('awayTeamNFLTriCode', String)
     awayTeamNFLTriCode: string = null;*/

    @JsonProperty('clock', String, true)
    clock: string = null;

    @JsonProperty('phase', String, true)
    phase: string = null;

    @JsonProperty('possession', String, true)
    possession: string = null;

    @JsonProperty('territory', String, true)
    territory: string = null;

    @JsonProperty('kickoffDate', String, true)
    kickoffDate = null;

    @JsonProperty('kickOffTime', String)
    kickOffTime: string = null;

    @JsonProperty('down', String, true)
    down: string = null;

    @JsonProperty('yardLine', String, true)
    yardLine: number = null;

    @JsonProperty('yardsToGo', String, true)
    yardsToGo: string = null;

    @JsonProperty('chipOrder', String)
    chipOrder: string = null;

    @JsonProperty('homeTeamClubImg', String, true)
    homeTeamClubImg: string = null;

    @JsonProperty('awayTeamClubImg', String, true)
    awayTeamClubImg: string = null;

    @JsonProperty('homeTeamColor', String, true)
    homeTeamColor: string = null;

    @JsonProperty('awayTeamColor', String, true)
    awayTeamColor: string = null;

    @JsonProperty('progress', Number, true)
    progress: number = null;

    @JsonProperty('focused', Boolean, true)
    focused: boolean = false;

    @JsonProperty('preGame', Boolean, true)
    preGame: boolean = false;

    @JsonProperty('finalGame', Boolean, true)
    finalGame: boolean = false;

    @JsonProperty('blackout', String)
    blackout: string = null;

    @JsonProperty('isExpanded', Boolean, true)
    isExpanded: boolean = false;

    @JsonProperty('isHighlighted', Boolean, true)
    isHighlighted: boolean = false;

    @JsonProperty('isNextToHighlighted', Boolean, true)
    isNextToHighlighted: boolean = false;

    @JsonProperty('isSelected', Boolean, true)
    isSelected: boolean = false;

    @JsonProperty('touchDown', Boolean, true)
    touchDown: boolean = false;

    @JsonProperty('fieldGoal', Boolean, true)
    fieldGoal: boolean = false;

    @JsonProperty('safety', Boolean, true)
    safety: boolean = false;

    @JsonProperty('isFantasyZone', Boolean, true)
    isFantasyZone: boolean = false;

    @JsonProperty('isRedZone', Boolean, true)
    isRedZone: boolean = false;

    public get title() {
        let gameName = '';

        if (this.gameId === CarouselConstants.GAMECHIP_FANTASY_ID) {
            gameName = CarouselConstants.GAMECHIP_FANTASY_NAME;
        } else if (this.gameId === CarouselConstants.GAMECHIP_REDZONE_ID) {
            gameName = CarouselConstants.GAMECHIP_REDZONE_NAME;
        } else {
            gameName = [this.awayTeamCode, ' vs ', this.homeTeamCode].join('');
        }
        return gameName;
    }

    private _formattedKickOffTime: string;
    private _formattedKickOffFullDate: string;

    public get formattedKickOffTime() {
        this._formattedKickOffTime = this._formattedKickOffTime || moment.utc(this.kickoffDate.GMT.replace(' GMT', '')).local().format('h:mm a');
        return this._formattedKickOffTime;
    }

    private _formattedKickOffDate: string;

    public get formattedKickOffDate() {
        this._formattedKickOffDate = this._formattedKickOffDate || moment.utc(this.kickoffDate.GMT.replace(' GMT', '')).local().format('ddd');
        return this._formattedKickOffDate;
    }

    public get formattedKickOffFullDate() {
        this._formattedKickOffFullDate = this._formattedKickOffFullDate || moment(this.kickoffDate._.replace(' GMT', '')).format('dddd');
        return this._formattedKickOffFullDate;
    }

    public get formattedStatus() {
        let status = '';

        if (this.isSelected) {
            status = CarouselConstants.NOW_SELECTED;
        } else {
            if (this.finalGame) {
                if (this.phase === CarouselConstants.GAME_PHASE_FINAL_OT) {
                    status = CarouselConstants.GAMECHIP_FINAL_OT_STATUS;
                } else {
                    status = this.phase;
                }
            } else if (this.preGame) {
                status = this.formattedKickOffTime;
            } else if (this.phase === CarouselConstants.GAME_PHASE_HALFTIME) {
                status = this.phase;
            } else if (this.touchDown) {
                status = CarouselConstants.TOUCHDOWN;
            } else if (this.fieldGoal) {
                status = CarouselConstants.FIELDGOAL;
            } else if (this.safety) {
                status = CarouselConstants.SAFETY;
            } else if (this.phase && this.clock) {
                status = `${this.phase} ${this.clock}`;
            }
        }

        return status;
    }

    public get isBlackedOut() {
        return this.blackout === 'true';
    }

    private getTeamColor(homeTeam: boolean, alpha: number = 1) {
        const color = (homeTeam ? this.homeTeamColor : this.awayTeamColor) || '#232629';
        const cutHex = color.charAt(0) === '#' ? color.substr(1) : color;
        const red = parseInt(cutHex.substring(0, 2), 16);
        const green = parseInt(cutHex.substring(2, 4), 16);
        const blue = parseInt(cutHex.substring(4, 6), 16);
        return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
    }

    public getHomeTeamColor(alpha: number = 1) {
        return this.getTeamColor(true, alpha);
    }

    public getAwayTeamColor(alpha: number = 1) {
        return this.getTeamColor(false, alpha);
    }

    private gameState = CarouselConstants.GAME_SCORE_DEFAULT;

    public get getGameState() {
        return this.gameState;
    }

    public setGameState(state) {
        this.gameState = state;
    }

    public get scoreText() {
        let text = '';
        if (this.touchDown) {
            text = CarouselConstants.TOUCHDOWN;
        } else if (this.fieldGoal) {
            text = CarouselConstants.FIELDGOAL;
        } else if (this.safety) {
            text = CarouselConstants.SAFETY;
        }
        return text;
    }

    private scoringTeam: string;

    public checkGamechipScoring(gamechipData) {
        if (!this.homeTeamScore || !this.awayTeamScore) { return; }
        const homeTeamScoreChange = parseInt(gamechipData.homeTeamScore) - parseInt(this.homeTeamScore.toString());
        const awayTeamScoreChange = parseInt(gamechipData.awayTeamScore) - parseInt(this.awayTeamScore.toString());

        this.scoringTeam = (homeTeamScoreChange > 0) ? CarouselConstants.GAMECHIP_HOME_STATUS : CarouselConstants.GAMECHIP_AWAY_STATUS;
        this.touchDown = homeTeamScoreChange >= 6 || awayTeamScoreChange >= 6;
        this.fieldGoal = (homeTeamScoreChange >= 3 && homeTeamScoreChange < 6)
                         || (awayTeamScoreChange >= 3 && awayTeamScoreChange < 6);
        this.safety = (homeTeamScoreChange == 2 && this.possession === CarouselConstants.GAMECHIP_AWAY_STATUS)
                      || (awayTeamScoreChange == 2 && this.possession === CarouselConstants.GAMECHIP_HOME_STATUS);
    }

    public get teamScore() {
        const isHomeTeamScore = this.scoringTeam === CarouselConstants.GAMECHIP_HOME_STATUS;
        const clubImg = isHomeTeamScore ? this.homeTeamClubImg : this.awayTeamClubImg;
        const bgColor = isHomeTeamScore ? this.getHomeTeamColor() : this.getAwayTeamColor();
        return {
            isHomeTeamScore,
            clubImg,
            bgColor
        };
    }

}
