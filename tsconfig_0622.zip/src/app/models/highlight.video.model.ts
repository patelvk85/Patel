import { REPORT_TITLE_SUFFIX } from '../common/constants/constants';
import {VideoModel} from './video.model';

export class HighlightVideoModel extends VideoModel {

    public get assetName() {
        return `[${this.id}] ${this.title} ${REPORT_TITLE_SUFFIX.HIGHLIGHT}`;
    }

    teamsName?: string;

    gameId?: string;

    alertType?: string;

    constructor(id: string, title: string, url: string, teamsName?: string, gameId?: string, alertType?: string) {
        super(id, title, false, url);
        this.teamsName = teamsName;
        this.gameId = gameId;
        this.alertType = alertType;
    }

}
