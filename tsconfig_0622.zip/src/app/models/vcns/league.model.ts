import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('LeagueModel')
export class LeagueModel {

    @JsonProperty('team_id', String, true)
    team_id?: string = null;

    @JsonProperty('contest_id', String, true)
    contest_id: string = null;

    @JsonProperty('game_key', String, true)
    game_key: string = null;

    @JsonProperty('name', String, true)
    name: string = null;
}
