import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('VideoModel')
export class VideoModel {

    @JsonProperty('high60', String, true)
    high60?: string = '';

    @JsonProperty('phone60', String, true)
    phone60?: string = '';

    @JsonProperty('high', String, true)
    high?: string = '';

    @JsonProperty('phone', String, true)
    phone?: string = '';

    @JsonProperty('1280x720_3200_30', String, true)
    screen1280720?: string = '';

    @JsonProperty('other', String, true)
    other?: string = '';

    @JsonProperty('592x336_880_30', String, true)
    screen59236?: string = '';

    @JsonProperty('tablet60', String, true)
    tablet60?: string = '';

    urls?: Array<string> | string = null;

    clip_id?: string = null;

    clip_title?: string = null;

    cdnName?: string = null;
    
    videoType?: number = null;

    constructor(urls?: Array<string> | string, clip_id?: string, clip_title?: string, videoType?: number, cdnName?: string) {
        this.urls = urls;
        this.clip_id = clip_id;
        this.clip_title = clip_title;
        this.cdnName = cdnName;
        this.videoType = videoType;
    }
}
