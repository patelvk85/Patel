import {ClipModel} from './clip.model';
import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('GamechipHighlightModel')
export class GamechipHighlightModel {

    @JsonProperty('count', Number)
    public count: number = 0;

    @JsonProperty('start', Number, true)
    public start: number = 0;

    @JsonProperty('clips', [ClipModel])
    clips?: ClipModel[] = undefined;
}
