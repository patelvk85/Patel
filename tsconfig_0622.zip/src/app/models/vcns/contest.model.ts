import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('ContestModel')
export class ContestModel {
    @JsonProperty('week', String, true)
    week: string = null;

    @JsonProperty('domain', String, true)
    domain: string = null;

    @JsonProperty('title_short', String, true)
    title_short: string = null;

    @JsonProperty('id', String, true)
    id: string = null;

    @JsonProperty('home_team', String, true)
    home_team: string = null;

    @JsonProperty('away_team', String, true)
    away_team: string = null;

    @JsonProperty('title', String, true)
    title: string = null;

    @JsonProperty('season_type', String, true)
    season_type: string = null;

    @JsonProperty('venue', String, true)
    venue: string = null;

    @JsonProperty('start', String, true)
    start: string = null;

    @JsonProperty('season_yr', String, true)
    season_yr: string = null;
}
