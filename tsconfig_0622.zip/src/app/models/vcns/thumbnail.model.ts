import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('ThumbnailModel')
export class ThumbnailModel {

    @JsonProperty('ipad-large', String, true)
    ipad_large: string = '';

    @JsonProperty('ps')
    ps: string = '';

    @JsonProperty('iphone-large', String, true)
    iphone_large: string = '';

    @JsonProperty('ps-alert', String, true)
    ps_alert: string = '';

    @JsonProperty('large', String, true)
    large: string = '';

    @JsonProperty('iphone', String, true)
    iphone: string = '';

    @JsonProperty('ipad', String, true)
    ipad: string = '';
}
