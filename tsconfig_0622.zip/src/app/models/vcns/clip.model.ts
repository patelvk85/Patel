import {ContestModel} from './contest.model';
import {LeagueModel} from './league.model';
import {MetadataModel} from './metadata.model';
import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('ClipModel')
export class ClipModel {

    @JsonProperty('contest', ContestModel, true)
    contest: ContestModel = null;

    @JsonProperty('league', LeagueModel, true)
    league: LeagueModel = null;

    @JsonProperty('metadata', MetadataModel, true)
    metadata: MetadataModel = undefined;

    public get url() {
        return this.metadata.media.video.high60 || this.metadata.media.video.high || this.metadata.media.video.screen1280720;
    }

    public get thumbnail() {
        return this.metadata.media.thumbs.ps || this.metadata.media.thumbs.large || this.metadata.media.thumbs.iphone;
    }

    public get title() {
        return this.metadata.title;
    }

    public get id() {
        return this.metadata.play_id || this.metadata.id;
    }

    public get teamLogo() {
        let url = 'assets/team_logo/nfl.png';
        if (this.metadata.team) {
            url = `assets/team_logo/${this.metadata.team.toLowerCase()}.png`;
        }
        return url;
    }
}
