import {ThumbnailModel} from './thumbnail.model';
import {VideoModel} from './video.model';
import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('MediaModel')
export class MediaModel {

    @JsonProperty('thumbs', ThumbnailModel, true)
    thumbs?: ThumbnailModel = null;

    @JsonProperty('video', VideoModel, true)
    video: VideoModel = null;
}
