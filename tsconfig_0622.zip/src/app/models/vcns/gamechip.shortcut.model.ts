import {ClipModel} from './clip.model';

export class GamechipShortcutModel {
    count?: number;
    start?: number;
    clips?: ClipModel[];
}
