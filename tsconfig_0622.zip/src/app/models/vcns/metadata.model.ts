import {MediaModel} from './media.model';
import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('MetadataModel')
export class MetadataModel {

    @JsonProperty('media', MediaModel, true)
    media: MediaModel = null;

    @JsonProperty('gameclock', String, true)
    gameclock?: string = '';

    @JsonProperty('down', Number, true)
    down?: number = null;

    @JsonProperty('poi', String, true)
    poi?: string = '';

    @JsonProperty('duration', String, true)
    duration?: string = '';

    @JsonProperty('title_sub', String, true)
    title_sub?: string = '';

    @JsonProperty('id', String, true)
    id?: string = '';

    @JsonProperty('title', String, true)
    title?: string = '';

    @JsonProperty('yards_gained', Number, true)
    yards_gained?: number = null;

    @JsonProperty('start', String, true)
    start?: string = null;

    @JsonProperty('score', String, true)
    score?: string = null;

    @JsonProperty('play_type', String, true)
    play_type?: string = null;

    @JsonProperty('description', String, true)
    description?: string = null;

    @JsonProperty('play_id', String, true)
    play_id?: string = null;

    @JsonProperty('poi_id', String, true)
    poi_id?: string = null;

    @JsonProperty('start_position', String, true)
    start_position?: string = null;

    @JsonProperty('cop', String, true)
    cop?: string = null;

    @JsonProperty('title_short', String, true)
    title_short?: string = null;

    players?: string[] = null;

    @JsonProperty('team', String, true)
    team?: string = null;

    @JsonProperty('yards_to_go', Number, true)
    yards_to_go?: number = null;

    @JsonProperty('quarter', Number, true)
    quarter?: number = null;
}
