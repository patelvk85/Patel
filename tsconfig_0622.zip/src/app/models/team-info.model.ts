import {JsonObject, JsonProperty} from 'json2typescript';

@JsonObject('TeamInfo')
export class TeamInfo {
    
    @JsonProperty('color')
    homeColor: string = null;

    @JsonProperty('color2')
    awayColor: string = null;

    @JsonProperty('directv-code')
    directvCode: string = null;

    @JsonProperty('location')
    location: string = null;

    @JsonProperty('name')
    name: string = null;

    @JsonProperty('nfl-code')
    nflCode: string = null;

}
