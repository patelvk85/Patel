import {JsonObject, JsonProperty} from 'json2typescript';
import {ClipModel} from './vcns/clip.model';

@JsonObject('AlertModel')
export class AlertModel {

    @JsonProperty('clip', ClipModel)
    clip: ClipModel = undefined;

    @JsonProperty('event')
    event: string = null;

    @JsonProperty('filter_id')
    filterId: string = null;

    public get title() {
        return `Instant Highlight - ${this.team}`;
    }

    public get description() {
        return this.clip.metadata.title || this.clip.metadata.description;
    }

    public get image() {
        return this.clip.metadata.media.thumbs.ps;
    }

    public get team() {
        return this.clip.metadata.team;
    }

    teamColor: string = null;

    private convertHexToRGB(teamColor: string, alpha: number = 1) {
        const color = teamColor;
        const cutHex = color.charAt(0) === '#' ? color.substr(1) : color;
        const red = parseInt(cutHex.substring(0, 2), 16);
        const green = parseInt(cutHex.substring(2, 4), 16);
        const blue = parseInt(cutHex.substring(4, 6), 16);
        return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
    }

    public getTeamColor(alpha: number = 1) {
        return this.convertHexToRGB(this.teamColor, alpha);
    }
}
