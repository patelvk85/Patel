import {TrackingConstants} from "../common/constants/tracking.constants";

const moment = require('moment');

export class VisitorModel {

    public get type() {
        return TrackingConstants.VISITOR_TYPE;
    }

    public get date() {
        return moment().format('YYYY-MM-DD[T]HH:mm:ss[GMT]ZZ');
    }

    public get hour() {
        return moment().format('h:mmA');
    }

    public get day() {
        return moment().format('dddd');
    }
}
