export class TimeZoneModel {
    _GMT: string = null;
    __text: string = null;
}
