export class VideoModel {

    public id: string;
    public title: string;
    public cdnName: string;
    public isLive: boolean;
    public url: string;

    public get assetName() {
        return `[${this.id}] ${this.title}`;
    }

    constructor(id: string, title: string, isLive: boolean, url: string, cdnName: string = '') {
        this.id = id;
        this.title = title;
        this.isLive = isLive;
        this.url = url;
        this.cdnName = cdnName;
    }

}
