import {ModuleWithProviders} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {
    LoginComponent,
    HomeComponent,
    AppVersionComponent
} from './components';
export const appRoutes: Routes = [
    {path: 'login', component: LoginComponent, data: {state: 'login'}},
    {path: 'home', component: HomeComponent, data: {state: 'home'}},
    {path: 'version', component: AppVersionComponent, data: {state: 'version'}}
];

// Debugging purposes -> enableTracing: true
export const Routing: ModuleWithProviders = RouterModule.forRoot(appRoutes, {enableTracing: false, useHash: true});
