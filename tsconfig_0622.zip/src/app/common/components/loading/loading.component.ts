'use strict';

import {Component, ChangeDetectorRef, OnDestroy} from '@angular/core';
import {LoadingService} from '../../services/loading.service';
import { VoiceService } from '../../../services/voice.service';

@Component({
    selector: 'nfl-loading',
    templateUrl: 'loading.component.html',
    styleUrls: ['./loading.component.scss']
})
export class LoadingComponent implements OnDestroy {

    private isShowLoading: boolean = false;
    private loadingRequestCount: number = 0;
    // private loadingTimeout: number = 60000;
    // private loadingTimeoutId;
    private events = [];

    constructor(private _loadingService: LoadingService, private _changeDetectorRef: ChangeDetectorRef) {
        this._loadingService.on('push').subscribe((event) => {
            if ((this.events.indexOf(event) < 0)) {
                this.events.push(event);
                this.loadingRequestCount++;
                this.checkRequestCount();
            }
        });

        this._loadingService.on('pop').subscribe((event) => {
            const eventIndex = this.events.indexOf(event);
            if ((eventIndex > -1)) {
                this.events.splice(eventIndex, 1);
                this.loadingRequestCount > 0 && this.loadingRequestCount--;
                this.checkRequestCount();
            }
        });

        this._loadingService.on('remove-all').subscribe(() => {
            this.reset();
        })
    }

    ngOnDestroy() {
        this._changeDetectorRef.detach();
    }

    private checkRequestCount() {
        // TODO why this.loadingTimeoutId is a ZoneTask ??!!!!
        // typeof this.loadingTimeoutId === 'object' && window['__zone_symbol__clearTimeout'](this.loadingTimeoutId.data.handleId);
        // typeof this.loadingTimeoutId === 'number' && window.clearTimeout(this.loadingTimeoutId);
        this.isShowLoading = this.loadingRequestCount > 0;
        if (this.isShowLoading) {
            VoiceService.speak("loading");
        }
        // this.loadingTimeoutId = window.setTimeout(this.reset.bind(this), this.loadingTimeout);
        this._changeDetectorRef.detectChanges();
    }

    private reset() {
        this.loadingRequestCount = 0;
        this.isShowLoading = false;
        this.events = [];
    }
}
