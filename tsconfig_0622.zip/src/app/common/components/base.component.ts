import {AfterViewInit, OnDestroy, HostListener, ChangeDetectorRef} from '@angular/core';
import { SubscriptionLike } from 'rxjs';
import {KeyCode} from '../constants/key-code.constants';
import {FocusService, KeyboardService} from '../services/';

export abstract class BaseComponent implements AfterViewInit, OnDestroy {

    private subscription: SubscriptionLike;

    protected functionMapping = [];

    abstract keyboardEventBusName = '';

    @HostListener('keydown', ['$event'])
    onKeyDown(event: KeyboardEvent) {
        event.stopPropagation();
        const newEvent = document.createEvent('Events');
        if (newEvent.initEvent) {
            newEvent.initEvent('keydown', true, true);
        }
        newEvent['keyCode'] = event.keyCode;
        newEvent['which'] = event.keyCode;
        newEvent['preventDefault'] = event.preventDefault;
        document.body.dispatchEvent(newEvent);
    }

    constructor(protected _keyboardService: KeyboardService,
                protected _focusService: FocusService,
                protected _changeDetectorRef?: ChangeDetectorRef) {
        if (window['tizen']) {
            const tizen = window['tizen'];
            tizen.tvinputdevice.registerKey('MediaPlay');
            tizen.tvinputdevice.registerKey('MediaStop');
            tizen.tvinputdevice.registerKey('MediaPause');
            tizen.tvinputdevice.registerKey('MediaRewind');
            tizen.tvinputdevice.registerKey('MediaFastForward');
            tizen.tvinputdevice.registerKey('MediaPlayPause');
        }

        this.functionMapping[KeyCode.Escape.toFixed()] = 'onBackPressed';
        this.functionMapping[KeyCode.Return.toFixed()] = 'onBackPressed';
        this.functionMapping[KeyCode.KeyboardCancel.toFixed()] = 'onCancelPressed';
        this.functionMapping[KeyCode.ArrowUp.toFixed()] = 'onUpPressed';
        this.functionMapping[KeyCode.ArrowLeft.toFixed()] = 'onLeftPressed';
        this.functionMapping[KeyCode.ArrowRight.toFixed()] = 'onRightPressed';
        this.functionMapping[KeyCode.ArrowDown.toFixed()] = 'onDownPressed';
        this.functionMapping[KeyCode.Enter.toFixed()] = 'onEnterPressed';
        this.functionMapping[KeyCode.KeyboardDone.toFixed()] = 'onDonePressed';
        // this.functionMapping[KeyCode.KeyboardDoneInput.toFixed()] = 'onDonePressed';
        this.functionMapping[KeyCode.MediaFastForward.toFixed()] = 'onFastForwardPressed';
        this.functionMapping[KeyCode.MediaRewind.toFixed()] = 'onRewindPressed';
        this.functionMapping[KeyCode.MediaPlayPause.toFixed()] = 'onPlayPausePressed';
        this.functionMapping[KeyCode.MediaPlay.toFixed()] = 'onPlayPressed';
        this.functionMapping[KeyCode.MediaPause.toFixed()] = 'onPausePressed';
        this.functionMapping[KeyCode.MediaStop.toFixed()] = 'onStopPressed';
    }

    ngAfterViewInit() {
        this.listenToKeyboard();
    }

    private listenToKeyboard() {
        this.subscription = this._keyboardService.on(this.keyboardEventBusName).subscribe((event: KeyboardEvent) => {
            this['onKeyPressed'] && this['onKeyPressed'](event);
            const fnName = this.functionMapping[event.keyCode];
            this[fnName] && this[fnName](event);
        });
    }

    private unListenToKeyboard() {
        this.subscription.unsubscribe();
    }

    ngOnDestroy() {
        this.unListenToKeyboard();
        this._changeDetectorRef && this._changeDetectorRef.detach();
    }

    protected setFocus(selector: string = '.no-focus', defaultFocusRow: number = 0, defaultFocusCol: number = 0) {
        this._focusService.createFocusMatrix(selector, defaultFocusRow, defaultFocusCol);
        this._focusService.setActiveEventBusName(this.keyboardEventBusName);
    }

    protected isStillFocused(): boolean {
        return this.keyboardEventBusName === this._focusService.getActiveEventBusName();
    }
}
