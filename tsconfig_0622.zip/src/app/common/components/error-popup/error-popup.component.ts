'use strict';

import {Component, OnDestroy, ChangeDetectorRef} from '@angular/core';
import {ErrorService, FocusService, KeyboardService} from '../../services';
import {BaseComponent} from '../base.component';
import {VoiceService} from '../../../services/voice.service';

@Component({
    selector: 'nfl-error-popup',
    templateUrl: './error-popup.component.html',
    styleUrls: ['./error-popup.component.scss']
})
export class ErrorPopupComponent extends BaseComponent {

    keyboardEventBusName = 'error-popup';
    private alertMessage: string = '';
    private buttonText: string = 'OK';
    private alertQueues: Array<string> = [];

    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                _changeDetectorRef: ChangeDetectorRef,
                private _errorService: ErrorService) {
        super(_keyboardService, _focusService, _changeDetectorRef);

        this._errorService.on('push-alert').subscribe(this.openAlert.bind(this));
        this._errorService.on('pop-alert').subscribe(this.closeAlert.bind(this));
    }

    private openAlert(data) {
        if ((this.alertQueues.indexOf(data.message) < 0)) {
            this.alertQueues.push(data.message);
            if (this.alertMessage === '') {
                this.alertMessage = this.alertQueues.shift();
                this.buttonText = data.buttonText ? data.buttonText : 'OK';
                this.setFocus('.alert-popup .focusable');
                VoiceService.speak(this.alertMessage + ", " + this.buttonText + " button");
            }
        }
    }

    private closeAlert() {
        this.alertMessage = this.alertQueues.shift() || '';
        this.alertMessage === '' && this._focusService.back();
    }

    private onBackPressed(event: KeyboardEvent) {
        if (this._errorService.errorShowing()) {
            this._errorService.closeError();
        }
    }

    ngOnDestroy() {
        super.ngOnDestroy();
    }
}
