import {GamechipModel} from '../../models/gamechip.model';

export class UserInfoModel {
    account: string;
    aswsUrl: string;
    authFeatures: { feature: Array<string> } = {feature: []};
    batchGameAuthServiceUrl: string;
    cdnTokenURL: string;
    customerEToken: string;
    gameIdUrlServiceUrl: string;
    gameScheduleUrl: string;
    games: { seasonType: string, week: string, GameAuthInfo: Array<GamechipModel> } = {
        seasonType: '',
        week: '',
        GameAuthInfo: []
    };
    genericEToken: string;
    genericServerTime: string;
    genericSignatureKey: string;
    hdrGameIdUrlServiceUrl: string;
    highlightURLPrefix: string;
    liveclipsAPIKey: string;
    liveclipsAPIUrl: string;
    liveclipsAuthUrl: string;
    liveclipsEToken: string;
    liveclipsNotificationUrl: string;
    liveclipsRefreshUrl: string;
    logoutURL: string;
    metaDataToken: string;
    ndsEnabled: string;
    nflFantasyAppKey: string;
    nflFantasyAppSecret: string;
    nflFantasyUrl: string;
    nlpgwsEndpointURL: string;
    nlpgwsProviderName: string;
    nlpgwsSiteID: string;
    nlpgwsSiteUserID: string;
    nlpgwsUpdateInterval: string;
    pgwsEndpointURL: string;
    pgwsSiteID: string;
    pgwsSiteUserID: string;
    playersUrl: string;
    schedulesUrl: string;
    scoreURL: string;
    serverTime: string;
    sessionId: string;
    sessionURL: string;
    sessionURLV2: string;
    signatureKey: string;
    standingsUrl: string;
    statisticsURL: string;
    status: string;
    streamType: string;
    streamTypeChromecastHDR: string;
    subscriptions: string;
    teamInfoUrl: string;
    tgsToken: string;
    thumbnailURLPrefix: string;
    userType: string;
    supercastCookie: string;
    nflRaptorStreamName: string;
    nflRaptorRegion: string;
    nflRaptorAccessKey: string;
    nflRaptorSecretKey: string;
    ipAddress: string;
    viewerid: string;
}
