export class VideoConstants {
  public static get VIDEO_PLAYING_STATUS(): string { return 'PLAYING'; }
  public static get VIDEO_PAUSED_STATUS(): string { return 'PAUSED'; }
  public static get VIDEO_STOPPED_STATUS(): string { return 'IDLE'; }
  public static get VIDEO_DESTROYED_STATUS(): string { return 'NONE'; }
  public static get TRACK_KIND_CAPTIONS(): string { return 'captions'; }
  public static get TRACK_KIND_SUBTITLES(): string { return 'subtitles'; }
  public static get SUBTITLES_MODE_HIDDEN(): string { return 'hidden'; }
  public static get SUBTITLES_MODE_SHOWING(): string { return 'showing'; }
  public static get LIVE_STREAMING(): string { return 'LIVE'; }
  public static get VIDEO_TYPE_GAMECHIP(): string { return 'gamechip'; }
  public static get VIDEO_TYPE_HIGHLIGHT(): string { return 'highlight'; }
  public static get VIDEO_TYPE_ALERT(): string { return 'alert'; }
}
