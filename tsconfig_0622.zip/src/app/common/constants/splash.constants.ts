export class SplashConstants {
    public static get LOADING_TEXT(): string { return 'Sit tight, it\'s loading...'; }
    public static get WAITING_TEXT(): string { return 'The action is on its way...'; }
}