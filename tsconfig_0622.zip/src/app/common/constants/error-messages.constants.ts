export class ErrorMessages {
    public static get GAMECHIP_BLACKOUT(): string { return 'Sorry, this game is not part of NFL SUNDAY TICKET programming'; }
    public static get GAMECHIP_PREGAME(): string { return 'Sorry, this game is not available now, see you then !'; }
    public static get GAMECHIP_NOT_AVAILABLE(): string { return 'Sorry, but games outside of this window are not part of the package.'; }

    public static get VIDEO_PLAYBACK_FAILURE(): string { return 'Sorry about the interruption. We\'re addressing the problem ASAP.'; }
    public static get VIDEO_START_FAILURE(): string { return 'Sorry, the player is unable to start this game, please try again !'; }

    public static get APP_NETWORK_ERROR(): string { return 'Please make sure you\'re connected to a WiFi network, and try again'; }
    public static get APP_SERVER_CONNECTION_FAILURE(): string { return 'Sorry about the interruption. We\'re addressing the problem ASAP.'; }
    public static get APP_TERMS_AND_CONDITIONS(): string { return 'You must agree in order to proceed.'; }

    public static get LOGIN_WRONG_ACCOUNT(): string { return 'Looks like you forgot to enter your User ID or password.'; }

    public static get HIGHLIGHT_NOT_AVAILABLE(): string { return 'Sorry, no highlights are available right now!'; }
    public static get OSD_MESSAGE(): string { return 'Are you still watching NFL Sunday Ticket?'; }
}
