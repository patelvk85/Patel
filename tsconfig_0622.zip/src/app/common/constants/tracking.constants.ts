export class TrackingConstants {
    public static get DEVICE_NAME(): string { return 'NFL:Tizen'; }
    public static get LANDSCAPE(): string { return 'Landscape'; }
    public static get PORTRAIT(): string { return 'Portrait'; }
    public static get ANDROID_TABLET(): string { return 'NFL:AndroidTablet'; }
    public static get ANDROID_PHONE(): string { return 'NFL:AndroidPhone'; }
    public static get NFL_CLOSE_CAPTION(): string { return 'NFL:CloseCaption'; }
    public static get HOMESCREEN_CLOSE_CAPTION(): string { return 'Homescreen:CloseCaption'; }
    public static get DEFAULT_STREAM_ERROR(): string { return 'Streaming Errors'; }
    public static get DEFAULT_LOGIN_ERROR(): string { return 'LoginError'; }
    public static get INDEX(): string { return 'Index'; }
    public static get HOMEPAGE(): string { return 'Homepage'; }
    public static get TEASER(): string { return 'Teaser'; }
    public static get LOGIN(): string { return 'Login'; }
    public static get APP_LAUNCH(): string { return 'App Launch'; }
    public static get LOGIN_FORM(): string { return 'Login Form'; }
    public static get PLAY_LIST(): string { return 'Playlist'; }
    public static get CHIP(): string { return 'Chip'; }
    public static get WHATSON(): string { return 'NFLApp:WhatsOn'; }
    public static get MY_ACCOUNT(): string { return 'NFLApp:MyAccount'; }
    public static get SHARE(): string { return 'Share'; }
    public static get SETTING(): string { return 'Setting'; }
    public static get RECORD(): string { return 'Record'; }
    public static get RECORD_CONFIRMATION(): string { return 'RecordConfirmation'; }
    public static get PROGRAM_RECORD(): string { return 'ProgramRecord'; }
    public static get FANTASY(): string { return 'Fantasy'; }
    public static get MY_PLAYERS(): string { return 'NFL Tizen'; }
    public static get HIGHLIGHTS(): string { return 'Highlights'; }
    public static get STATS_STANDINGS(): string { return 'StatsAndStandings'; }
    public static get RZC(): string { return 'RZC'; }
    public static get FTC(): string { return 'FTC'; }
    public static get GAMES(): string { return 'Games'; }
    public static get CAST(): string { return 'Cast'; }
    public static get RECORD_GAME(): string { return 'RecordGame'; }
    public static get WIFI(): string { return 'Wifi'; }
    public static get CHARSET(): string { return 'UTF-8'; }
    public static get PLATFORM(): string { return 'Tizen'; }
    public static get SELECTION(): string { return 'Selection'; }
    public static get VISITOR_TYPE(): string { return 'DTV'; }
    public static get STREAM_CONTENT(): string { return 'U_NFLLTV_Game'; }
    public static get STREAM_SHORTCUT_CONTENT(): string { return 'U_NFLShortcut_LiveClip'; }
    public static get STREAM_HIGHLIGHT_CONTENT(): string { return 'U_NFLHighlight_LiveClip'; }
    public static get STREAM_HIGHLIGHT_STOP_EVENT_CONTENT(): string { return 'U_NFLLTV_Game'; }
    public static get STREAM_ERROR(): string { return 'Content Streaming failure'; }
    public static get BUTTON(): string { return 'Button'; }
    public static get LOGIN_TYPE(): string { return 'ET'; }
    public static get TIME_PLAYED_DEFAULT_TEXT(): string { return ' - In seconds'; }
    public static get TIME_PLAYED_SHORTCUT_TEXT(): string { return ' - Time in seconds that video was viewed'; }
    public static get HIGHLIGHT_LOCATION(): string { return 'Highlights or Alerts'; }
    public static get CAPTION_ON(): string { return 'On'; }
    public static get CAPTION_OFF(): string { return 'Off'; }
}
