export class ApplicationConstants {
  public static get DOCUMENT_VISIBILITY_DEFAULT_STATUS(): string { return 'hidden'; }
  public static get DOCUMENT_VISIBILITY_MS_STATUS(): string { return 'msHidden'; }
  public static get DOCUMENT_VISIBILITY_WEBKIT_STATUS(): string { return 'webkitHidden'; }
  public static get DOCUMENT_VISIBILITY_DEFAULT_EVENT(): string { return 'visibilitychange'; }
  public static get DOCUMENT_VISIBILITY_MS_EVENT(): string { return 'msvisibilitychange'; }
  public static get DOCUMENT_VISIBILITY_WEBKIT_EVENT(): string { return 'webkitvisibilitychange'; }
}
