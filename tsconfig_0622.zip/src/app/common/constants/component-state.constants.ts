export class ComponentState {
    public static get FOCUSSED(): string { return 'focussed'; }
    public static get SELECTED(): string { return 'selected'; }
    public static get UNFOCUSSED(): string { return 'unfocussed'; }
    public static get VISIBLE(): string { return 'visible'; }
    public static get HIDDEN(): string { return 'hidden'; }
}
