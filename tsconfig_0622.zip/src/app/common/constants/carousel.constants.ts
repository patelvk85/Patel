export class CarouselConstants {
    public static get OPEN_HIGHLIGHT_ACTION(): string { return 'OpenHighlight'; }
    public static get OPEN_SMART_HUB_ACTION(): string { return 'OpenFromSmartHub'; }
    public static get GAMECHIP_FINAL_STATUS(): string { return 'Final'; }
    public static get GAMECHIP_FINAL_OT_STATUS(): string { return 'Final OT'; }
    public static get GAMECHIP_PREGAME_STATUS(): string { return 'Pregame'; }
    public static get GAMECHIP_HOME_STATUS(): string { return 'Home'; }
    public static get GAMECHIP_AWAY_STATUS(): string { return 'Away'; }
    public static get GAMECHIP_REDZONE_ID(): string { return '999999999'; }
    public static get GAMECHIP_FANTASY_ID(): string { return '888888888'; }
    public static get GAMECHIP_REDZONE_NAME(): string { return 'RedZone'; }
    public static get GAMECHIP_FANTASY_NAME(): string { return 'Fantasy'; }
    public static get GAMECHIP_SETTINGS_ID(): string { return 'SETTINGS'; }
    public static get UNAVAILABLE(): string { return 'UNAVAILABLE'; }
    public static get BLACKED_OUT(): string { return 'BLACKED OUT'; }
    public static get TOUCHDOWN(): string { return 'TOUCHDOWN!'; }
    public static get FIELDGOAL(): string { return 'FIELD GOAL'; }
    public static get SAFETY(): string { return 'SAFETY'; }
    public static get NOW_SELECTED(): string { return 'Now Selected'; }
    public static get GAME_PHASE_HALFTIME(): string { return 'Halftime'; }
    public static get GAME_PHASE_FINAL(): string { return 'Final'; }
    public static get GAME_PHASE_FINAL_OT(): string { return 'Final Overtime'; }
    public static get GAME_PHASE_PREGAME(): string { return 'Pregame'; }

    public static get GAME_SCORE_DEFAULT(): string { return 'ScoringDefault'; }
    public static get GAME_SCORE_START(): string { return 'ScoringStart'; }
    public static get GAME_SCORE_END(): string { return 'ScoringEnd'; }
}
