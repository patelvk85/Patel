/**
 * Last Modified: 3:58 PM
 * File Name: key-code.constants.ts
 *
 */

// Mapping of Samsung Key codes from https://www.samsungdforum.com/TizenGuide/tizen3551/index.html
export class KeyCode {
    public static get ArrowLeft(): Number { return 37; }
    public static get ArrowUp(): Number { return 38; }
    public static get ArrowRight(): Number { return 39; }
    public static get ArrowDown(): Number { return 40; }

    public static get MediaPause(): Number { return 19; }
    public static get Enter(): Number { return 13; }
    public static get Escape(): Number { return 27; }
    public static get Return(): Number { return 10009; }
    public static get MediaPlayPause(): Number { return 10252; }
    public static get MediaRewind(): Number { return 412; }
    public static get MediaFastForward(): Number { return 417; }
    public static get MediaPlay(): Number { return 415; }
    public static get MediaStop(): Number { return 413; }
    public static get MediaRecord(): Number { return 416; }
    public static get MediaTrackPrevious(): Number { return 10232; }
    public static get MediaTrackNext(): Number { return 10233; }
    public static get VolumeUp(): Number { return 447; }
    public static get VolumeDown(): Number { return 448; }
    public static get VolumeMute(): Number { return 449; }
    public static get ChannelUp(): Number { return 427; }
    public static get ChannelDown(): Number { return 428; }
    public static get Info(): Number { return 457; }
    public static get Exit(): Number { return 10182; }
    public static get Caption(): Number { return 10221; }
    public static get Guide(): Number { return 458; }
    public static get Search(): Number { return 10225; }

    public static get KeyboardDone(): Number { return 65376; }
    public static get KeyboardDoneInput(): Number { return 229; }
    public static get KeyboardCancel(): Number { return 65385; }

    static readonly Space: number = 32;
    static readonly F: number = 70;
    static readonly R: number = 82;
}
