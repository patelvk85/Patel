export class APIErrorCodes {
    public static get SYSTEM_ERROR(): string { return '0001'; }
    public static get INVALID_ACCOUNT_STATUS(): string { return '0002'; }
    public static get MISSING_CLIENT_IDENTIFIER(): string { return '0003'; }
    public static get MISSING_USER_IDENTIFIER(): string { return '0004'; }
    public static get MISSING_VALIDATION_TOKEN(): string { return '0005'; }
    public static get CLIENT_IDENTIFIER_IS_INVALID_UNRECOGNIZED(): string { return '0006'; }
    public static get MISSING_REFRESH_TOKEN(): string { return '0010'; }
    public static get CLIENT_IDENTIFIER_DOES_NOT_MATCH_CLIENT_IDENTIFIER(): string { return '0011'; }
    public static get CORRUPTED_INVALID_REFRESH_TOKEN(): string { return '0012'; }
    public static get CORRUPTED_INVALID_ACCESS_TOKEN(): string { return '0013'; }
    public static get MISSING_ACCESS_TOKEN(): string { return '0014'; }
    public static get ACCESS_TOKEN_HAS_EXPIRED(): string { return '0015'; }
    public static get UNABLE_TO_RECEIVE_RESPONSE_FROM_TGUARD(): string { return '0100'; }
    public static get UNABLE_TO_RECEIVE_RESPONSE_FROM_ACCOUNT_SERVICE(): string { return '0101'; }
    public static get UNABLE_TO_RECEIVE_RESPONSE_FROM_DEVICE_SERVICE(): string { return '0210'; }
    public static get TOKEN_CORRUPTED_OR_EXPIRED(): string { return '500'; }
    public static get DEVICE_MANAGEMENT_ERROR(): string { return 'DMS-1004'; }
}
