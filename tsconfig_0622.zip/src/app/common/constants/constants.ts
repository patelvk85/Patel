export const constants = {
    RETRY_TIMES: 3,
    SELECTED_ENV: 'selectedEnv',
    STATUS_SUCCESS: 'success'
};

export const REPORT_TITLE_SUFFIX = {
    SHORTCUT: ' - Shortcut',
    HIGHLIGHT: ' - Highlight'
}

export const AppUpdate = {
    TITLE: 'New Update Available',
    CONTENT: 'NOTE: There is a new version of the app available. Please update your app to continue using the latest version of NFL Sunday Ticket.',
    VERSION: 'Version '
}
