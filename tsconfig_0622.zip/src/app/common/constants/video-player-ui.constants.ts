export class VideoPlayerUI {
    public static get ACCESSIBILITY(): string { return 'accessibility'; }
    public static get COMMON_INFO(): string { return 'common-info'; }
    public static get FAST_FORWARD(): string { return 'fast-forward'; }
    public static get LOOKBACK(): string { return 'lookback'; }
    public static get PLAY_PAUSE(): string { return 'play-pause'; }
    public static get STOP(): string { return 'stop'; }
    public static get RECORD(): string { return 'record'; }
    public static get REWIND(): string { return 'rewind'; }
    public static get SKIP_AHEAD(): string { return 'skip-ahead'; }
    public static get SKIP_BACK(): string { return 'skip-back'; }
    public static get LIVE_MODE(): string { return 'liveMode'; }
    public static get VOD_MODE(): string { return 'vodMode'; }
    public static get RESTART_MODE(): string { return 'restartMode'; }
    public static get DAI_MODE(): string { return 'daiMode'; }
    public static get RESTART(): string { return 'restart'; }
    public static get CAPTION(): string { return 'caption'; }
    public static get LANGUAGE(): string { return 'language'; }
}
