export class NetworkConstants {
    public static get DISCONNECTED(): number { return 0; }
    public static get WIFI(): number { return 1; }
    public static get CELLULAR(): number { return 2; }
    public static get ETHERNET(): number { return 3; }
    public static get DISCONNECTED_TEXT(): string { return 'Disconnected'; }
    public static get WIFI_TEXT(): string { return 'Wifi'; }
    public static get CELLULAR_TEXT(): string { return 'Cellular'; }
    public static get ETHERNET_TEXT(): string { return 'Ethernet'; }
    public static get UNKNOWN_TEXT(): string { return 'Unknown'; }
    public static get STATE_LAN_CABLE_ATTACHED(): number { return 1; }
    public static get STATE_GATEWAY_CONNECTED(): number { return 4; }
    public static get STATE_WIFI_MODULE_STATE_ATTACHED(): number { return 6; }
}
