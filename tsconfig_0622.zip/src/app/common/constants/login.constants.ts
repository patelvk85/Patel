export class LoginConstants {
    public static get BASIC_USER(): string { return 'BASIC'; }
    public static get MAX_USER(): string { return 'MAX'; }
    public static get USER_AUTH(): string { return 'USER_AUTH'; }
    public static get SIGN_IN(): string { return 'Sign In'; }
    public static get SIGN_UP(): string { return 'Sign Up'; }
    public static get REMEMBER_ME(): string { return 'Remember Me'; }
    public static get PRIVACY_POLICY(): string { return 'The NFLSUNDAYTICKET.TV Privacy Policy (available at directv.com/NFLST/PrivacyPolicy) describes the type of information that may be collected by the application and how DIRECTV can use and share this information.'; }
    public static get SIGN_IN_VOICE_TEXT(): string { return `Sign in to NFL Sunday ticket.
    The NFL Sunday ticket dot TV Privacy Policy (available at directv.com/NFLST/PrivacyPolicy) describes the type of information that may be collected by the application and how DIRECTV can use and share this information.`; }
    public static get EXIT_APP(): string { return 'Do you really want to exit app?'; }
    public static get SIGN_UP_HIGHLIGHT(): string { return 'Go to NFLST.DIRECTV.COM/SAMSUNG'; }
    public static get SIGN_UP_MESS(): string { return 'To get every live out-of-market Sunday afternoon game this NFL season.'; }
    public static get SIGN_UP_LEGAL(): string { return 'Eligibility requirements apply.'; }
}
