export class ConfigConstants {

    public static get ENVIRONMENT(): string {
        return 'env';
    }

    public static get ENVIRONMENT_CE(): string {
        return 'ce';
    }

    public static get ENVIRONMENT_CE2(): string {
        return 'ce2';
    }

    public static get ENVIRONMENT_E2E(): string {
        return 'e2e';
    }

    public static get ENVIRONMENT_PRODUCTION(): string {
        return 'production';
    }
}
