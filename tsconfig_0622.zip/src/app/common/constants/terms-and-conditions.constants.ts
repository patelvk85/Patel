export class TermsAndConditions {

    public static get IS_FIRST_LAUNCH(): string {
        return 'isFirstLaunch2021';
    }

    public static get TITLE(): string {
        return `User Acknowledgement`;
    }

    public static get DETAILS(): string {
        return `
        By subscribing to NFL SUNDAY TICKET, you agree DIRECTV may share your DIRECTV and NFL SUNDAY TICKET account related information with the NFL for use consistent with their privacy policy. (available at http://www.nfl.com/help/privacy).

        By choosing Accept you also agree to the NFLSUNDAYTICKET.TV Privacy Policy (available at directv.com/NFLST/PrivacyPolicy) and the NFLSUNDAYTICKET.TV Terms of Use (available at directv.com/NFLST/TermsofUse).
        `;
    }

    public static get DETAILS_VOICE_TEXT(): string {
        return `
        User acknowledgement
        
        By subscribing to NFL SUNDAY TICKET, you agree DIRECTV may share your DIRECTV and NFL SUNDAY TICKET account related information with the NFL for use consistent with their privacy policy. (available at http://www.nfl.com/help/privacy).

        By choosing Accept you also agree to the NFL SUNDAYTICKET dot TV Privacy Policy (available at directv.com/NFLST/PrivacyPolicy) and the NFL SUNDAYTICKET dot TV Terms of Use (available at directv.com/NFLST/TermsofUse).`;
    }

}
