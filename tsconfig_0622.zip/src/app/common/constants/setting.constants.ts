export class SettingConstants {
    public static get ACCOUNT(): string { return 'Account'; }
    public static get ALERTS(): string { return 'Alerts'; }
    public static get FAQS(): string { return 'FAQs'; }
    public static get PRIVACY_POLICY(): string { return 'Privacy policy'; }
    public static get TERMS_OF_USE(): string { return 'Terms of use'; }
    public static get LEGAL_DISCLOSURE(): string { return 'Legal Disclosure'; }
    public static get DO_NOT_SELL_INFO(): string { return 'Do Not Sell My Personal Information'; }
}