import {Injectable} from '@angular/core';

export class LoggerService {

    /**
     *
     * @type {Console}
     */
    private static logger: Console = console;

    /**
     * check Logging is enabled or disabled
     * @type {boolean}
     */
    private static isLogging: boolean = false;

    constructor() {
    }

    /**
     * Outputs a message to the Web Console
     * @function
     * @param {any} message
     */
    public static logTrace(message: any) {
        if (this.isLogging) {
            this.logger.log('%s %s', new Date(), message);
        }
    }

    /**
     * Outputs a warning message to the Web Console
     * @function
     * @param {any} message
     */
    public static warnTrace(message: any) {
        if (this.isLogging) {
            this.logger.warn(message);
        }
    }

    /**
     * Outputs an informational message to the Web Console
     * @function
     * @param {any} message
     */
    public static infoTrace(message: any) {
        if (this.isLogging) {
            this.logger.info(message);
        }
    }

    /**
     * Outputs a message to the console with the log level "debug"
     * @function
     * @param {any} message
     */
    public static debugTrace(message: any) {
        if (this.isLogging) {
            this.logger.debug(message);
        }
    }

    /**
     * Outputs a message to the console with the log level "error"
     * @function
     * @param {any} message
     */
    public static errorTrace(message: any) {
        this.logger.error(message);
    }

    /**
     * enable Logging
     */
    public static enableLogging() {
        this.isLogging = true;
    }

    /**
     * disable Logging
     */
    public static disableLogging() {
        this.isLogging = false;
    }

}
