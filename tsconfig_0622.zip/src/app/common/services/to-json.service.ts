// Dependencies
import { Injectable } from '@angular/core';
import * as xml2js from 'xml2js';

@Injectable()
export class ToJsonService {
  private parser = new xml2js.Parser({ explicitArray: false, mergeAttrs: true, explicitRoot: false });

  constructor() {
  }

  // Method for get Json Data
  getJson(data) {
    try {
        return JSON.parse(data);
    } catch (e) {
      this.parser.parseString(data, (err, json) => {
        if (!err) {
          data = json;
        }
      });
      
      return data;
    }
  }

}
