import {Injectable} from '@angular/core';
import {KeyCode} from '../constants';
import * as _ from 'lodash';
import {KeyboardService} from './keyboard.service';

@Injectable()
export class FocusService {

    public pointer: { row: number, col: number } = {row: 0, col: 0};
    public currentFocusEl: HTMLElement = null;

    private activeEventBusName = '';
    public focusMatrix = [[]];
    private focusHistory = [];
    private eventBusNameHistory = [];
    private focusHistoryOfRow = [];
    private currentSelector: string = '';

    constructor(private _keyboardService: KeyboardService) {
        // Init event listener
        this._keyboardService.on('keydown').subscribe((event: KeyboardEvent) => {
            const keyCode = event.keyCode;
            let isHandled = null;
            switch (keyCode) {
                case KeyCode.ArrowLeft:
                    isHandled = this.left();
                    break;
                case KeyCode.ArrowRight:
                    isHandled = this.right();
                    break;
                case KeyCode.ArrowDown:
                    isHandled = this.down();
                    break;
                case KeyCode.ArrowUp:
                    isHandled = this.up();
                    break;
            }
            event['focusEl'] = isHandled;
            this._keyboardService.broadcast(this.activeEventBusName, event);
            this._keyboardService.broadcast('hasEvent', event);
        });

    }

    public setActiveEventBusName(name: string) {
        this.eventBusNameHistory.push(this.activeEventBusName || name);
        this.activeEventBusName = name;
    }

    public getActiveEventBusName(): string {
        return this.activeEventBusName;
    }

    public back() {
        const previousFocusConfig = this.focusHistory.pop();
        this.currentFocusEl.blur();
        // DO NOT store current config by RESET this.currentSelector
        this.currentSelector = '';
        this.activeEventBusName = this.eventBusNameHistory.pop();
        this.createFocusMatrix(previousFocusConfig.selector, previousFocusConfig.pointer.row, previousFocusConfig.pointer.col);
    }

    public refresh(selector?: string, row: number = this.pointer.row, col: number = this.pointer.col) {
        selector = selector || this.currentSelector;
        // DO NOT store current config by RESET this.currentSelector
        this.currentSelector = '';
        this.createFocusMatrix(selector, row, col);
    }

    public createFocusMatrix(selector?: string, row = null, col = null) {

        if (this.currentSelector) {
            this.focusHistory.push({
                selector: this.currentSelector,
                pointer: _.clone(this.pointer)
            });

        }
        this.resetFocus();
        const focusElements = document.querySelectorAll((this.currentSelector = (selector || '')));
        for (let i = 0; i < focusElements.length; i++) {
            const el = <HTMLElement> focusElements.item(i);
            const focusRow: number = parseInt(el.dataset.focusRow || '0');
            const focusCol: number = parseInt(el.dataset.focusCol || '0');
            const rowSpan: number = parseInt(el.dataset.focusRowSpan || '0');
            const colSpan: number = parseInt(el.dataset.focusColSpan || '0');
            if (!rowSpan && colSpan) {
                for (let col = focusCol; col < (focusCol + colSpan); col++) {
                    this.focusMatrix[focusRow][col] = el;
                }
            }
            if (rowSpan && !colSpan) {
                for (let row = focusRow; row < (focusRow + rowSpan); row++) {
                    !this.focusMatrix[row] && (this.focusMatrix[row] = []);
                    this.focusMatrix[row][focusCol] = el;
                }
            }
            if (rowSpan && colSpan) {
                for (let row = focusRow; row < (focusRow + rowSpan); row++) {
                    for (let col = focusCol; col < (focusCol + colSpan); col++) {
                        !this.focusMatrix[row] && (this.focusMatrix[row] = []);
                        this.focusMatrix[row][col] = el;
                    }
                }
            }
            !this.focusMatrix[focusRow] && (this.focusMatrix[focusRow] = []);
            this.focusMatrix[focusRow][focusCol] = el;
        }

        this.initFocus(row, col);
    }

    public initFocus(rowNumber?: number, colNumber?: number) {
        if (typeof rowNumber !== 'number' && typeof colNumber !== 'number' && this.focusMatrix.length) {
            rowNumber = this.focusMatrix.findIndex((row) => {
                return !!row && row.length > 0;
            });
            if (this.focusMatrix[rowNumber]) {
                colNumber = this.focusMatrix[rowNumber].findIndex((col) => {
                    return !!col;
                });
            }
        }
        return this.setFocus(rowNumber, colNumber);
    }

    public setFocus(row: number, col: number) {
        if (!this.focusMatrix.length || !this.focusMatrix[row]) {
            return false;
        }
        const element = <HTMLElement> this.focusMatrix[row][col];
        if (element && element.focus) {
            // focus() only works with displayed EL, some cases we have to wait util it displayed
            const executeFocus = (count) => {
                if (element.clientHeight > 0 || element.clientWidth > 0) {
                    element.tabIndex = -1;
                    element.focus();
                    if (row !== this.pointer.row) {
                        this.focusHistoryOfRow[this.pointer.row] = this.pointer.col;
                    }
                    this.pointer.col = col;
                    this.pointer.row = row;
                } else if (count < 3) {
                    setTimeout(executeFocus.bind(++count), 100);
                }
            };
            this.unfocusElement(this.currentFocusEl);
            this.currentFocusEl = element;
            executeFocus(0);
        }
        return element;
    }

    private unfocusElement(element: HTMLElement) {
        if (element) {
            element.blur();
            element.removeAttribute('tabindex');
        }
    }

    private moveFocusCol(isLeft = true, row?: number) {
        let col = this.pointer.col;
        row = typeof row === 'number' ? row : this.pointer.row;

        const max = this.focusMatrix[row] ? this.focusMatrix[row].length : 0;

        if (isLeft) {
            do {
                col >= 0 && col--;
            } while (col >= 0 && this.focusMatrix[row] && (this.focusMatrix[row][col] === this.currentFocusEl));
        } else {
            do {
                (col < max) && col++;
            }
            while (col < max && this.focusMatrix[row] && this.focusMatrix[row][col] === this.currentFocusEl);
        }
        return this.setFocus(row, col);
    }

    private moveFocusRow(isUp = true) {
        let col = this.pointer.col;
        let row = this.pointer.row;

        const max = this.focusMatrix ? this.focusMatrix.length : 0;

        if (isUp) {
            do {
                row >= 0 && row--;
            }
            while (row >= 0 && this.focusMatrix[row] && this.focusMatrix[row][col] === this.currentFocusEl);
        } else {
            do {
                (row < max) && row++;
            }
            while (row < max && this.focusMatrix[row] && this.focusMatrix[row][col] === this.currentFocusEl);
        }
        if (this.focusMatrix[row] && this.focusMatrix[row][this.focusHistoryOfRow[row]]) {
            col = this.focusHistoryOfRow[row];
        }
        if (this.focusMatrix[row] && !this.focusMatrix[row][col]) {
            return this.left(row);
        } else {
            return this.setFocus(row, col);
        }
    }

    public left(row?: number) {
        return this.moveFocusCol(true, row);
    }

    public right(row?: number) {
        return this.moveFocusCol(false, row);
    }

    public up() {
        return this.moveFocusRow(true);
    }

    public down() {
        return this.moveFocusRow(false);
    }

    private isNoFocus() {
        return this.focusMatrix.length === 0;
    }

    public resetFocus() {
        this.focusMatrix = [[]];
        this.focusHistoryOfRow = [];
        this.unfocusElement(this.currentFocusEl);
    }

}
