import {Injectable} from '@angular/core';
import {BroadcasterService} from './broadcaster.service';
import { GuideModel } from '../../models/guide.model';

@Injectable()
export class GuideService extends BroadcasterService {

    public showHideGuide(buttons: Array<GuideModel> = null) {
        if (buttons) {
            this.broadcast('showGuideButtons', buttons);
        }
    }
}
