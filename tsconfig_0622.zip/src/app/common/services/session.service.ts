import {Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {LoginService} from '../../services/login.service';
import { map, retry, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { ToJsonService } from './to-json.service';
import { constants } from '../constants/constants';

@Injectable()
export class SessionService {

    constructor(private _httpClient: HttpClient, private _toJsonService: ToJsonService, private _loginService: LoginService) {
    }

    public getSession(sessionStr: string, deviceId: string) {
        return this._httpClient.get(this._loginService.userInfo.sessionURL, {
            headers: { session: sessionStr },
            params: { device: deviceId },
            responseType: 'text', 
            withCredentials: true })
        .pipe(map((res) => {
            return this._toJsonService.getJson(res);
        }),
            retry(constants.RETRY_TIMES),
            catchError(err => {
            return throwError(err);
        })).toPromise();
    }
}
