import {Injectable} from '@angular/core';
import {ConfigEnvModel} from '../models/config.env.model';
import { HttpClient } from '@angular/common/http';
import { map, retry, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { ToJsonService } from './to-json.service';
import { constants } from '../constants/constants';

@Injectable()
export class EnvironmentService {

    public environments = [
        {
            name: 'CE2',
            configUrl: 'http://ce-nfl2.dtveng.com/supercast_samsungtvtizen_config.xml'
        },
        {
            name: 'EE1',
            configUrl: 'https://nflhe-funct.dtveng.com/supercast_samsungtvtizen_config.xml'
        },
        {
            name: 'E2E',
            configUrl: 'https://nflhe-funct-pop2.dtveng.com/supercast_samsungtvtizen_config.xml'
        },
        {
            name: 'PRODUCTION',
            configUrl: 'https://nfl.directv.com/supercast_samsungtvtizen_config.xml'
        }
    ];

    public config: ConfigEnvModel;
    public currentEnvironment: { name, configUrl } = {name: '', configUrl: ''};

    public get isDev(): boolean {
        return this.currentEnvironment.name !== this.environments[3].name;
    }

    constructor(private _httpClient: HttpClient, private _toJsonService: ToJsonService) {
        if (localStorage.getItem(constants.SELECTED_ENV) === null) {
            localStorage.setItem(constants.SELECTED_ENV, this.environments[3].name);
        }
    }

    public getCurrentEnvName() {
        return localStorage.getItem(constants.SELECTED_ENV);
    }

    public setEnvironment(name: string) {
        const env = this.environments.find((item) => {
            return item.name === name;
        });
        localStorage.setItem(constants.SELECTED_ENV, name);
        return this.getEnvironmentConfigs(env);
    }

    private getEnvironmentConfigs(env) {
        return this._httpClient.get(env.configUrl, { responseType: 'text', withCredentials: true })
        .pipe(map((res) => {
            this.config = this._toJsonService.getJson(res);
            this.currentEnvironment.name = env.name;
            this.currentEnvironment.configUrl = env.configUrl;
            localStorage.setItem(constants.SELECTED_ENV, env.name);
            
            return this.config
        }),
        retry(constants.RETRY_TIMES),
        catchError(err => {
            return throwError(err);
        })).toPromise();
    }

}
