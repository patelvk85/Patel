import {NativeService} from './native.service';
import {Injectable} from '@angular/core';

@Injectable()
export class TvInfoService extends NativeService {

    protected objectName: string = 'tvinfo';

    private userAgent: string = undefined;

    public isTizen2016(): boolean {
        this.userAgent = this.userAgent || navigator.userAgent;
        return  this.userAgent.indexOf('Tizen 2.4') > 0;
    }

    public showCaption(show: boolean) {
        this.executeApi('showCaption', [false]);
    }

    public getMenuValue(key) {
        return this.executeApi('getMenuValue', [this.getTvInfoMenuKey(key)]);
    }

    private getTvInfoMenuKey(key) {
        return this.getObj('TvInfoMenuKey', key);
    }

    public registerInAppCaptionControl(isControl) {
        this.executeApi('registerInAppCaptionControl', [isControl]);
    }

    public getClosedCaptionStyles() {
        const textColorId           = this.getMenuValue('CAPTION_FG_COLOR_KEY') || 0;
        const backgroundColorId     = this.getMenuValue('CAPTION_BG_COLOR_KEY') || 0;
        const fontSizeId            = this.getMenuValue('CAPTION_FONT_SIZE_KEY') || 0;
        const fontFamilyId          = this.getMenuValue('CAPTION_FONT_STYLE_KEY') || 0;
        const backgroundOpacityId   = this.getMenuValue('CAPTION_BG_OPACITY_KEY') || 4;
        const windowColorId         = this.getMenuValue('CAPTION_WINDOW_COLOR_KEY') || 0;
        const windowOpacityId       = this.getMenuValue('CAPTION_WINDOW_OPACITY_KEY') || 4;
        const textColors            = ['white', 'white', 'black', 'red', 'green', 'blue', 'yellow', 'magenta', 'cyan'];
        const fontSizes             = ['3.5rem', '4rem', '4.5rem', '5rem', '5.5rem'];
        const fontFamilies          = ['Roboto', 'courier-prime', 'Cardo', 'AnonymousPro', 'Roboto', 'Allerta', 'Italianno', 'JuliusSansOne'];
        const textColor             = textColors[textColorId];
        const fontSize              = fontSizes[fontSizeId];
        const fontFamily            = fontFamilies[fontFamilyId];
        const backgroundColor = this.getRgbaColor(backgroundColorId, backgroundOpacityId);
        const windowColor = this.getRgbaColor(windowColorId, windowOpacityId);

        return {
            textColor,
            backgroundColor,
            fontSize,
            fontFamily,
            windowColor
        };
    }

    private getRgbaColor(colorId, opacityId) {
        const opacityList   = [1, 0.2, 0.5, 0, 0.9, 0.3, 0.9];
        const opacity = opacityList[opacityId];
        const colors = [ `rgba(0, 0, 0, ${opacity})`,
            `rgba(255, 255, 255, ${opacity})`,
            `rgba(0, 0, 0, ${opacity})`,
            `rgba(255, 0, 0, ${opacity})`,
            `rgba(0, 255, 0, ${opacity})`,
            `rgba(0, 0, 255, ${opacity})`,
            `rgba(255, 255, 0, ${opacity})`,
            `rgba(255, 0, 255, ${opacity})`,
            `rgba(0, 255, 255, ${opacity})`];
        return colors[colorId];
    }
}
