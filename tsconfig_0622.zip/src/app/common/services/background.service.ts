import {LoggerService} from './logger.service';

export class BackgroundService {
    /**
     *  TODO Rename to ApplicationService
     */
    private documentHiddenName: string = 'hidden';
    private documentVisibilityEventName: string = 'visibilitychange';
    private isWebkitEnvironment: boolean = false;

    constructor() {
        // Init event document visibility listener
        this.bindEvents();
    }

    // private environments() {
    //   if (document.webkitHidden) {
    //     this.documentHiddenName = 'webkitHidden';
    //     this.documentVisibilityEventName = 'webkitvisibilitychange';
    //   }
    // }

    private visibilityCallback() {
        const timer = new Date().getTime();
        if (document[this.documentHiddenName]) {
            LoggerService.logTrace('Page is now hidden.');
        } else {
            LoggerService.logTrace('Page is now visible.');
            alert('You were away for ' + (new Date().getTime() - timer) / 1000 + ' seconds.');
        }
    }

    private bindEvents() {
        // this.environments();

        document.addEventListener(this.documentVisibilityEventName, this.visibilityCallback, false);
    }
}