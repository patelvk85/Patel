import {Injectable} from '@angular/core';
import {BroadcasterService} from './broadcaster.service';

@Injectable()
export class LoadingService extends BroadcasterService {

    public push(data: string = null) {
        if (data) {
            this.broadcast('push', data);
        } else {
            this.broadcast('push');
        }
    }

    public pop(data: string = null) {
        if (data) {
            this.broadcast('pop', data);
        } else {
            this.broadcast('pop');
        }
    }

    public removeAll() {
        this.broadcast('remove-all');
    }
}
