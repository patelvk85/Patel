import {Injectable} from '@angular/core';
import {NativeService} from './native.service';

@Injectable()
export class AvplayService extends NativeService {

    protected objectName: string = 'avplay';

    public setStreamingProperty(key, value) {
        const state = this.getState();
        return this.executeApi('setStreamingProperty', [key, value]);
    }

    public getStreamingProperty(key) {
        return this.hasAcceptState.call(this, ['READY', 'PLAYING', 'PAUSED']) ? this.executeApi('getStreamingProperty', [key]) : null;
    }

    public getCurrentStreamInfo() {
        return this.hasAcceptState.call(this, ['READY', 'PLAYING', 'PAUSED']) ? this.executeApi('getCurrentStreamInfo') : null;
    }

    public pause() {
        return this.hasAcceptState.call(this, ['PLAYING', 'PAUSED']) ? this.executeApi('pause') : null;
    }

    public stop() {
        return this.executeApi('stop');
    }

    public suspend() {
        return this.executeApi('suspend');
    }

    public restore() {
        return this.executeApi('restore');
    }

    public play() {
        return this.hasAcceptState.call(this, ['READY', 'PLAYING', 'PAUSED']) ? this.executeApi('play') : null;
    }

    public close() {
        return this.executeApi('close');
    }

    public prepare() {
        return this.hasAcceptState.call(this, ['IDLE', 'READY']) ? this.executeApi('prepare') : null;
    }

    public prepareAsync(successCalback: Function = null, errorCallback: Function = null) {
        return this.hasAcceptState.call(this, ['IDLE', 'READY']) ?  this.executeApi('prepareAsync', [successCalback, errorCallback]) : null;
    }

    public open(url) {
        return this.hasAcceptState.call(this, ['NONE', 'IDLE']) ? this.executeApi('open', [url]) : null;
    }

    public getVersion() {
        return this.executeApi('getVersion');
    }

    public getState() {
        return this.executeApi('getState');
    }

    public getDuration() {
        return this.executeApi('getDuration');
    }

    public getCurrentTime() {
        return this.executeApi('getCurrentTime');
    }

    public setDisplayRect(x, y, width, height) {
        return !this.hasAcceptState.call(this, ['NONE']) ? this.executeApi('setDisplayRect', [x, y, width, height]) : null;
    }

    public setBufferingParam(bufferOption, bufferSizeUnit, amount) {
        return this.hasAcceptState.call(this, ['IDLE']) ? this.executeApi('setBufferingParam', [bufferOption, bufferSizeUnit, amount]) : null;
    }

    public setListener(listeners) {
        return this.executeApi('setListener', [listeners]);
    }

    public seekTo(time: number, callback?: Function) {
        return !this.hasAcceptState.call(this, ['NONE']) ? this.executeApi('seekTo', [time, callback, callback]) : null;
    }

    public jumpForward(time: number, callback?: Function) {
        return !this.hasAcceptState.call(this, ['READY', 'PLAYING', 'PAUSED']) ? this.executeApi('jumpForward', [time, callback, callback]) : null;
    }

    public getTotalTrackInfo() {
        return this.hasAcceptState.call(this, ['READY', 'PLAYING', 'PAUSED']) ? this.executeApi('getTotalTrackInfo') : null;
    }

    public getTrackId(): number {
        const totalTrackInfo = this.getTotalTrackInfo();
        let index = null;
        for (let i = 0, length = totalTrackInfo.length; i < length; i++) {
            if (totalTrackInfo[i].type == 'TEXT') {
                index = totalTrackInfo[i].index;
                break;
            }
        }
        return index;
    }

    public setSelectTrack(trackType, trackIndex) {
        return this.hasAcceptState.call(this, ['READY', 'PLAYING', 'PAUSED']) ? this.executeApi('setSelectTrack', [trackType, trackIndex]) : null;
    }

    private hasAcceptState(states): boolean {
        const state = this.getState();
        return states.indexOf(state) > -1;
    }
}
