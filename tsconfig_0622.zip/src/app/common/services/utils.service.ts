import {Injectable} from '@angular/core';

@Injectable()
export class UtilsService {

    constructor() {

    }

    public getQueryStr(object: Object): string {
        let str: string = '';
        if (typeof object === 'object') {
            Object.keys(object).forEach((key, i) => {
                str += (i === 0 ? '' : '&') + key + '=' + encodeURIComponent(object[key]);
            });
        }
        return str;
    }

}
