import {Injectable} from '@angular/core';
import {BroadcasterService} from './broadcaster.service';

@Injectable()
export class KeyboardService extends BroadcasterService {

    private eventQueue: Array<KeyboardEvent> = [];

    constructor() {
        super();
        // Init event listener
        document.addEventListener('keydown', (event: KeyboardEvent) => {
            this.eventQueue.push(event);
            this.eventQueue.length < 2 && this.executeEvent();
        });

        document.addEventListener('keyup', (event: KeyboardEvent) => {
           this.eventQueue.length > 2 && ( this.eventQueue.length = 0);
        });
    }

    private executeEvent() {
        if (this.eventQueue.length) {
            const event = this.eventQueue[0];
            event.stopPropagation();
            event.stopImmediatePropagation();
            requestAnimationFrame(() => {
                this.broadcast('keydown', event);
                setTimeout(() => {
                    this.eventQueue.shift();
                    this.executeEvent();
                }, 150);
            });
        }
    }
}
