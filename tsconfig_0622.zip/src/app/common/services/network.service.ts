import {Injectable} from '@angular/core';
import {NativeService} from './native.service';
import {NetworkConstants} from '../constants';

@Injectable()
export class NetworkService extends NativeService {

    protected objectName: string = 'network';

    public getMACAddress(): string {
        return this.executeApi('getMac');
    }

    public addNetworkStateChangeListener(callback?: Function) {
        return this.executeApi('addNetworkStateChangeListener', [callback]);
    }

    public getActiveConnectionType(): number {
        return this.executeApi('getActiveConnectionType');
    }

    public getNetworkType(): string {
        let networkTypeText = '';
        const type = this.getActiveConnectionType();

        switch(type) {
            case NetworkConstants.DISCONNECTED:
                networkTypeText = NetworkConstants.DISCONNECTED_TEXT;
                break;
            case NetworkConstants.WIFI:
                networkTypeText = NetworkConstants.WIFI_TEXT;
                break;
            case NetworkConstants.CELLULAR:
                networkTypeText = NetworkConstants.CELLULAR_TEXT;
                break;
            case NetworkConstants.ETHERNET:
                networkTypeText = NetworkConstants.ETHERNET_TEXT;
                break;
            default:
                networkTypeText = NetworkConstants.UNKNOWN_TEXT;
                break;
        }

        return networkTypeText;
    }

    public isNetworkDisconnected(callback?: any) {
        window.addEventListener('offline', callback);
    }

}
