import {Injectable} from '@angular/core';
import {BroadcasterService} from './broadcaster.service';

@Injectable()
export class ErrorService extends BroadcasterService {

    private isShowing: boolean;

    public showError(message: string, buttonText?: string) {
        this.broadcast('push-alert', {message, buttonText});
        this.isShowing = true;
    }

    public closeError() {
        this.broadcast('pop-alert');
        this.isShowing = false;
    }

    public showDialog(message: string, agreeText: string, cancelText: string, agreeCallback: any) {
        this.broadcast('push-dialog', {message, agreeText, cancelText, agreeCallback});
    }

    public errorShowing(): boolean {
        return this.isShowing;
    }
}
