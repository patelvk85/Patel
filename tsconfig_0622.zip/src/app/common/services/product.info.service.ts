import {NativeService} from './native.service';
import {Injectable} from '@angular/core';

@Injectable()
export class ProductInfoService extends NativeService {

    protected objectName: string = 'productinfo';

    public getModelCode() {
        return this.executeApi('getModelCode');
    }

    public getFirmwareVersion() {
        return this.executeApi('getFirmware');
    }

    public getDuid() {
        return this.executeApi('getDuid');
    }

    public getRealModel() {
        return this.executeApi('getRealModel');
    }
}
