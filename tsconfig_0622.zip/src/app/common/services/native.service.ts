import {LoggerService} from './logger.service';

export class NativeService {

    protected objectName: string = '';
    protected api: string = 'webapis';

    protected executeApi(api: string, params: Array<any> = []) {
        const pathToFn = api.split('.');
        const fn = pathToFn.pop();
        pathToFn.splice(0, 0, this.objectName);
        const webapis = window[this.api] || {};
        let object = webapis;
        pathToFn.forEach((path) => {
            object = object[path];
        });
        if (object) {
            try {
                return object[fn].apply(object, params);
            } catch (e) {
                LoggerService.logTrace(e);
            }
        } else {
            LoggerService.warnTrace(api);
        }

    }

    protected getObj(name: string, value: any) {
        const pathToObj = name.split('.');
        const obj = pathToObj.pop();
        pathToObj.splice(0, 0, this.objectName);
        const webapis = window[this.api] || {};
        let object = webapis;
        pathToObj.forEach((path) => {
            object = object[path];
        });
        if (object) {
            try {
                return object[obj][value];
            } catch (e) {
                LoggerService.logTrace(e);
            }
        } else {
            LoggerService.warnTrace(obj);
        }
    }
}
