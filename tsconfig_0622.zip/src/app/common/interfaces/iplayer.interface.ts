import {IPlayerEvents} from './iplayer-events.interface';
import {VideoModel} from '../../models/video.model';

export interface IPlayer {

    init(videoElement: HTMLVideoElement): void;

    addListener(listeners: IPlayerEvents): void;

    removeListener(listeners: IPlayerEvents): void;

    loadContent(videos: Array<VideoModel>): void;

    play(): void;

    pause(): void;

    seekTo(time: number): void;

    buffered(): TimeRanges;

    paused(): boolean;

    textTracks(): Array<TextTrack>;

    stop(): void;

    destroy(): void;
}
