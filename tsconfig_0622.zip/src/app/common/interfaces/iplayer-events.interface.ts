export interface IPlayerEvents {

    /**
     * Called when the player has state changed
     * @function
     * @param {string} state - current player state (NONE, IDLE, READY, PAUSE, PLAYING)
     */
    onPlayerStateChange(state: string): void;

    /**
     * Called when the player is loading video metadata or seeking
     * @function
     */
    onBufferingProgress(): void;

    /**
     * Called when the player finish buffering
     * @function
     */
    onBufferingComplete(): void;

    /**
     * Called when the player are in playing state
     * @function
     * @param {number} currentTime - current time
     */
    onTimeUpdate(currentTime: number): void;

    /**
     * Called when player's texttrack was set and subtitle has changed
     * 
     * @param {any} duration - timer for text appears
     * @param {any} subtitles - text track
     * @param {any} $type 
     * @param {any} attriCount 
     * @param {any} attributes 
     */
    onSubtitleChange(duration, subtitles, $type, attriCount, attributes);

    /**
     * Called when the video start seeking
     * @function
     */
    onSeeking?(): void;

    /**
     * Called when the video seek end
     * @function
     */
    onSeekEnd?(): void;

    /**
     * Called when video ended
     * @function
     */
    onEnded(): void;

    /**
     * Called when an error occurs
     * @function
     * @param {string} $type - error type
     * @param {any} data 
     */
    onError($type: string, data): void;
}
