'use strict';

import {Component, ChangeDetectorRef, ViewChild, ElementRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {BaseComponent} from './common/components/base.component';
import {LoginService} from './services/login.service';
import {ApplicationService} from './services/application.service';
import {
    EnvironmentService,
    FocusService,
    KeyboardService,
    LoadingService,
    LoggerService,
    ErrorService,
    NetworkService,
} from './common/services';
import {TrackingService} from './services/tracking.service';
import {TermsAndConditions, ErrorMessages, NetworkConstants} from './common/constants';
import {routerTransition} from './animations/router.animations';
import { VoiceService } from './services/voice.service';

@Component({
    selector: 'nfl-app',
    templateUrl: 'app.component.html',
    animations: [routerTransition],
    styleUrls: ['./app.component.scss']
})
export class AppComponent extends BaseComponent {

    @ViewChild('agreeButton', {static: false})
    private agreeButton: ElementRef;
    private readonly VoiceService = VoiceService;

    keyboardEventBusName = 'app';

    private graphicUrl: string = '';
    private isFirstLaunch: boolean;
    private termsAndConditionsContent: string;
    private isEnvironmentFetched: boolean = false;
    
    private readonly TermsAndConditions = TermsAndConditions;

    constructor(_keyboardService: KeyboardService,
                _focusService: FocusService,
                _changeDetectorRef: ChangeDetectorRef,
                private router: Router,
                private route: ActivatedRoute,
                private _environmentService: EnvironmentService,
                private _loginService: LoginService,
                private _loadingService: LoadingService,
                private _applicationService: ApplicationService,
                private _trackingService: TrackingService,
                private _errorService: ErrorService,
                private _networkService: NetworkService) {
        super(_keyboardService, _focusService, _changeDetectorRef);

        this._networkService.addNetworkStateChangeListener(this.onNetworkStateChange.bind(this));

        this.isFirstLaunch = _applicationService.checkFirstLaunch();
        if (this.isFirstLaunch) {
            // this._loginService.getTermOfUseContent().then(res => this.termsAndConditionsContent = res.toString());
        } else {
            this.appLogin();
            this.appVisibility();
        }
        LoggerService.enableLogging();
    }

    private appLogin(firstLaunch?: boolean) {
        const savedUserCredentials = this._loginService.getSavedUserCredentials();
        const isRememberMe = this._loginService.isRememberMe();

        this._environmentService.setEnvironment(this._environmentService.getCurrentEnvName()).then(config => {
            this.isEnvironmentFetched = true;
            this._trackingService.initTracking();
            firstLaunch ? this._trackingService.appLaunch() : null;
            // if current less than min version app
            if (this._applicationService.isNewUpdateAvailable()) {
                this.router.navigate(['/version'], {relativeTo: this.route});
            } else {
                if (JSON.parse(config.offseason)) {
                    this.graphicUrl = config.offseasonGraphicURL;
                } else if (isRememberMe && savedUserCredentials.username && savedUserCredentials.eToken) {
                    this._loadingService.push();
                    this._loginService.reLogin(savedUserCredentials.username, savedUserCredentials.eToken).then(user => {
                        this._loadingService.pop();
                        this._trackingService.videoKeepAlive();
                        this._trackingService.loginSuccess();
                        this.router.navigate(['/home'], {relativeTo: this.route});
                    }, error => {
                        this._loadingService.pop();
                        this._trackingService.loginError(error.statusCode, error.statusMessage);
                        this.router.navigate(['/login'], {
                            relativeTo: this.route,
                            queryParams: {
                                statusCode: error.statusCode,
                                error: error.statusMessage || error.message
                            }
                        });
                    });
                } else {
                    this.router.navigate(['/login'], {relativeTo: this.route});
                }
            }
        }, error => {
            this._loadingService.pop();
            this.isEnvironmentFetched = false;
            this._errorService.showError(ErrorMessages.APP_SERVER_CONNECTION_FAILURE);
        });
    }

    ngAfterViewInit() {
        super.ngAfterViewInit();
        if (this.isFirstLaunch) {
            this.setFocus('.terms-conditions .focusable', 0, 1);
        } else {
            this.setFocus('.app.focusable');
        }
        if (this.agreeButton) {
            VoiceService.speakMsgAndFocusedElement(TermsAndConditions.DETAILS_VOICE_TEXT, 
                this.agreeButton.nativeElement, this._focusService);
        }
    }

    private onTermsAndConditionsAccepted() {
        this.isFirstLaunch = this._applicationService.checkFirstLaunch(true);
        localStorage.setItem(TermsAndConditions.IS_FIRST_LAUNCH, 'false');
        this.appLogin(true);
        this.appVisibility();
    }

    private onTermsAndConditionsDenied() {
        this._errorService.showError(ErrorMessages.APP_TERMS_AND_CONDITIONS);
    }

    private onBackPressed(event: KeyboardEvent) {
        if (this._errorService.errorShowing()) {
            this._errorService.closeError();
        } else {
            this._applicationService.exitApplication();
            this._trackingService.clearVideoKeepAliveTimeout();
        }
    }

    private appVisibility() {
        this._applicationService.on(this._applicationService.documentVisibilityEventName).subscribe((isHidden) => {
            if (isHidden) {
                if (this._loginService.userInfo && this._loginService.userInfo['logoutURL']) {
                    this._loginService.shallowLogout();
                }
                this._trackingService.clearVideoKeepAliveTimeout();
            } else {
                if (this._applicationService.isNewUpdateAvailable()) {
                    this.router.navigate(['/version'], {relativeTo: this.route});
                } else if (this.graphicUrl) {
                    this.setFocus('.app.focusable');
                } else if (this.isFirstLaunch) {
                    this.setFocus('.terms-conditions .focusable', 0, 1);
                } else {
                    if (!this.isEnvironmentFetched) {
                        return;
                    } else if (this._applicationService.isInAcceptedTime) {
                        this._loginService.silentLogin();
                    } else {
                        this.router.navigate(['/login'], {relativeTo: this.route}).then(() => {
                            this.appLogin();
                        });
                    }
                    this._loginService.userInfo && this._trackingService.videoKeepAlive();
                }
            }
        });
    }

    private onNetworkStateChange(state) {
        if (state == NetworkConstants.STATE_LAN_CABLE_ATTACHED
            || state == NetworkConstants.STATE_GATEWAY_CONNECTED
            || state == NetworkConstants.STATE_WIFI_MODULE_STATE_ATTACHED) {
            if (this._errorService.errorShowing()) {
                this._errorService.closeError();
            }
        } else {
            this._errorService.showError(ErrorMessages.APP_NETWORK_ERROR);
        }
    }

    private getState(outlet) {
        return outlet.activatedRouteData.state;
    }

}
