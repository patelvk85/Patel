import { Injectable } from '@angular/core';
import { EnvironmentService, NetworkService, ProductInfoService } from './common/services';
import { LoginService } from './services/login.service';
import { VideoConstants } from './common/constants';

declare var RaptorHelper: any;
declare var RaptorConstants: any;
declare var tizen: any;

@Injectable()
export class RaptorService {
  private packageInfo = require('../../package.json');

  private _raptorClient: any = {};
  private _raptorHelper: any;
  private _currentAn: string;

  private _currentPS: number;
  private _osVer: string;

  constructor(private _environmentService: EnvironmentService,
    private _loginService: LoginService,
    private _networkService: NetworkService,
    private _productInfoService: ProductInfoService) { }

  public initialize() {
    if (this._environmentService.config.raptorEnabled == "false") { return; }

    const kinesisKeys = {
      accessKeyId: this._loginService.userInfo.nflRaptorAccessKey,
      secretAccessKey: this._loginService.userInfo.nflRaptorSecretKey,
      heartbeatInterval: this._environmentService.config.raptorHeartbeatIntervalSecs,
      streamName: this._loginService.userInfo.nflRaptorStreamName,
      region: this._loginService.userInfo.nflRaptorRegion
    };
    this._raptorHelper = new RaptorHelper(kinesisKeys);

    if (tizen && tizen.systeminfo && !this._osVer) {
      this._osVer = tizen.systeminfo.getCapability('http://tizen.org/feature/platform.version');
    }
  }

  public createSession(assetName, isLive: boolean = false) {
    if (!this._raptorHelper) { return; }

    this._currentAn = assetName;
    if (this._raptorClient[this._currentAn]) {
      this.cleanupSession();
    }

    this._raptorClient[this._currentAn] = this._raptorHelper.createRaptorInstance();

    const contentInfo = {
      an: this._currentAn,
      strmt: isLive ? RaptorConstants.types.stream.LIVE : RaptorConstants.types.stream.VOD,
      vid: this._loginService.userInfo.viewerid,
      cl: isLive ? -1 : 0,
      pt: RaptorConstants.types.platform.NFL_TIZEN,
      ptv: this.packageInfo.version,
      serviceDomain: RaptorConstants.types.serviceDomain.NFL,
      lv: isLive,
      dt: 'TV',
      dmfg: 'Samsung',
      did: this._loginService.deviceId,
      ppid: this._loginService.userInfo.account,
      ct: this._networkService.getNetworkType().toLowerCase(),
      os: 'Tizen',
      osVer: this._osVer,
      dm: this._productInfoService.getRealModel(),
      gameMix: false,
      dl: 'en_US',
      pht: 0,
      br: 0,
      ip: this._loginService.userInfo.ipAddress,
      afps: 0
    };
    this._raptorClient[this._currentAn].setContentInfo(contentInfo);
    this._raptorClient[this._currentAn].report({ ps: RaptorConstants.playerState.PLAYBACK_INIT });
    this._raptorClient[this._currentAn].sendHeartBeat();
  }

  public updateRaptorSession(url: string, getPhtTimeCallback: any) {
    if (!this._raptorClient[this._currentAn]) { return; }
    
    if (getPhtTimeCallback) {
      this._raptorClient[this._currentAn].setPhtCallback(getPhtTimeCallback);
    }
    if (url) {
      this._raptorClient[this._currentAn].report({ url: url });
    }
  }

  public seekStarted() {
    if (this._raptorClient[this._currentAn] && this._currentPS != RaptorConstants.playerState.SEEK_START) {
      this._currentPS = RaptorConstants.playerState.SEEK_START;
      this._raptorClient[this._currentAn].report({ ps: RaptorConstants.playerState.SEEK_START });
    }
  }

  public seekEnded() {
    if (this._raptorClient[this._currentAn] && this._currentPS != RaptorConstants.playerState.SEEK_COMPLETE) {
      this._currentPS = RaptorConstants.playerState.SEEK_COMPLETE;
      this._raptorClient[this._currentAn].report({ ps: RaptorConstants.playerState.SEEK_COMPLETE });
    }
  }

  public setBitRate(bitrate) {
    if (!this._raptorClient[this._currentAn]) { return; }

    if (bitrate || bitrate === 0) {
      const br = Math.round(bitrate);
      this._raptorClient[this._currentAn].report({ br: br });
    }
  }

  public updateFps(fps) {
    if (!this._raptorClient[this._currentAn]) { return; }
    
    this._raptorClient[this._currentAn].report({ afps: Math.round(fps) });
    this._raptorClient[this._currentAn].setContentInfo({ afps: Math.round(fps) });
  }

  public onPlayerStateChange(state: string, currentPosition: number) {
    if (!this._raptorClient[this._currentAn]) { return; }

    this._raptorClient[this._currentAn].setContentInfo({ pht: currentPosition });
    switch (state) {
      case VideoConstants.VIDEO_STOPPED_STATUS:
        this._raptorClient[this._currentAn].report({ ps: RaptorConstants.playerState.STOP });
        break;
      case VideoConstants.VIDEO_PAUSED_STATUS:
        this._raptorClient[this._currentAn].report({ ps: RaptorConstants.playerState.PAUSE });
        break;
      case VideoConstants.VIDEO_PLAYING_STATUS:
        this._raptorClient[this._currentAn].report({ ps: RaptorConstants.playerState.PLAY });
        break;
      case VideoConstants.VIDEO_DESTROYED_STATUS:
        this._raptorClient[this._currentAn].report({ ps: RaptorConstants.playerState.STOP });
        break;
    }
  }

  public reportBufferingState(isStart?: boolean) {
    if (!this._raptorClient[this._currentAn]) { return; }

    this._raptorClient[this._currentAn].report({ ps: isStart ? RaptorConstants.playerState.BUFFER_START : RaptorConstants.playerState.BUFFER_COMPLETE });
  }

  public reportDuration(duration, isLive: boolean = false) {
    if (!this._raptorClient[this._currentAn] || isLive) { return; }

    this._raptorClient[this._currentAn].setContentInfo({ cl: Math.round(duration) });
  }

  public cleanupSession(err?: any) {
    if (this._raptorClient[this._currentAn]) {
      this._raptorClient[this._currentAn].setContentInfo({ pht: 0 });
      if (err) {
        if (err.errorCode == undefined) {
          err.errorCode = this.getErrorCode(err.errorMsg);
        }
        this._raptorClient[this._currentAn].reportPlaybackFailed(err);
      }
      this._raptorClient[this._currentAn].endSession();
      delete this._raptorClient[this._currentAn];
    }
    this._currentPS = undefined;
  }

  private getErrorCode(mess) {
    switch (mess) {
      case "PLAYER_ERROR_INVALID_OPERATION":
        return 3200;
      case "PLAYER_ERROR_INVALID_PARAMETER":
        return 3201;
      case "PLAYER_ERROR_INVALID_STATE":
        return 3202;
      case "PLAYER_ERROR_SEEK_FAILED":
        return 3203;
      case "PLAYER_ERROR_NOT_SUPPORTED_FILE":
        return 3204;
      case "PLAYER_ERROR_INVALID_URI":
        return 3205;
      case "PLAYER_ERROR_NO_SUCH_FILE":
        return 3206;
      case "PLAYER_ERROR_OUT_OF_MEMORY":
        return 3207;
      case "PLAYER_ERROR_FILE_NO_SPACE_ON_DEVICE":
        return 3208;
      case "PLAYER_ERROR_FEATURE_NOT_SUPPORTED_ON_DEVICE":
        return 3209;
      case "PLAYER_ERROR_SOUND_POLICY":
        return 3210;
      case "PLAYER_ERROR_VIDEO_CAPTURE_FAILED":
        return 3211;
      case "PLAYER_ERROR_DRM_EXPIRED":
        return 3212;
      case "PLAYER_ERROR_DRM_NO_LICENSE":
        return 3213;
      case "PLAYER_ERROR_DRM_FUTURE_USE":
        return 3214;
      case "PLAYER_ERROR_DRM_NOT_PERMITTED":
        return 3215;
      case "PLAYER_ERROR_RESOURCE_LIMIT":
        return 3216;
      case "PLAYER_ERROR_PERMISSION_DENIED":
        return 3217;
      case "PLAYER_ERROR_SERVICE_DISCONNECTED":
        return 3218;
      case "PLAYER_ERROR_BUFFER_SPACE":
        return 3219;
      case "PLAYER_ERROR_NOT_SUPPORTED_AUDIO_CODEC":
        return 3220;
      case "PLAYER_ERROR_NOT_SUPPORTED_VIDEO_CODEC":
        return 3221;
      case "PLAYER_ERROR_NOT_SUPPORTED_SUBTITLE":
        return 3222;
      case "PLAYER_ERROR_CONNECTION_FAILED":
        return 3223;
      default:
        return 3001;
    }
  }
}
