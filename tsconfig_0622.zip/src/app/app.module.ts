import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { Routing } from './app.router';
import {
    AvplayService,
    EnvironmentService,
    FocusService,
    KeyboardService,
    LoadingService,
    NetworkService,
    TvInfoService,
    ErrorService,
    ProductInfoService
} from './common/services';
import { LoginService } from './services/login.service';
import { GamechipService } from './services/gamechip.service';
import { SplashService } from './services/splash.service';
import { TrackingService } from './services/tracking.service';
import {
    CarouselComponent,
    HomeComponent,
    LoginComponent,
    SettingsComponent,
    VideoComponent,
    HighlightsComponent,
    AppAlertComponent,
    AppVersionComponent
} from './components';
import { PlayerService } from './services/player.service';
import {
    LoadingComponent,
    ErrorPopupComponent
} from './common/components';
import { VCNSService } from './services/vcns.service';
import { BroadcasterService } from './common/services/broadcaster.service';
import { ApplicationService } from './services/application.service';
import { OsdComponent } from './components/osd/osd.component';
import { SplashComponent } from './components/splash/splash.component';
import { StompRService } from '@stomp/ng2-stompjs';
import { NotificationService } from './services/notification.service';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { GuideComponent } from './components/guide/guide.component';
import { GuideService } from './common/services/guide.service';
import { HttpClientModule } from '@angular/common/http';
import { ToJsonService } from './common/services/to-json.service';
import { UtilsService } from './common/services/utils.service';
import { AppDialogComponent } from './components/app-dialog/app-dialog.component';
import { RaptorService } from './raptor.service';

require('./webapi-simulator');

@NgModule({
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        CommonModule,
        Routing,
        HttpClientModule
    ],
    providers: [
        KeyboardService,
        FocusService,
        UtilsService,
        GamechipService,
        PlayerService,
        LoginService,
        LoadingService,
        EnvironmentService,
        NetworkService,
        ProductInfoService,
        AvplayService,
        TvInfoService,
        VCNSService,
        BroadcasterService,
        ApplicationService,
        RaptorService,
        SplashService,
        TrackingService,
        StompRService,
        NotificationService,
        ErrorService,
        GuideService,
        ToJsonService
    ],
    declarations: [
        AppComponent,
        LoadingComponent,
        ErrorPopupComponent,
        AppAlertComponent,
        AppDialogComponent,
        LoginComponent,
        VideoComponent,
        HomeComponent,
        CarouselComponent,
        SettingsComponent,
        HighlightsComponent,
        OsdComponent,
        SplashComponent,
        AppVersionComponent,
        SpinnerComponent,
        GuideComponent
    ],
    bootstrap: [AppComponent]
})

export class AppModule {
}
