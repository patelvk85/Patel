/**
 * Created by Tuan Nguyen (TuanNA58@fsoft.com.vn) on 3/12/18.
 */

import {LoggerService} from './common/services';

if (!window['webapis']) {

    LoggerService.logTrace('webapis is simulated');

    window['webapis'] = {
        network: {
            getMac() {
                return '7c:64:56:b7:be:56';
            },
            getActiveConnectionType() {
                return 'Wifi';
            }
        }
    };

}
